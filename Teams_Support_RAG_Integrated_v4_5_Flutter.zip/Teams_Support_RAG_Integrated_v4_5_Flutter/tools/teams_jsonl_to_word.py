#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
teams_jsonl_to_word.py

Legge un file JSONL generato da Microsoft Graph/Teams e produce un documento Word (.docx)
che ricrea la sequenza dei messaggi in stile Teams, includendo:
- timestamp in testa a ogni messaggio
- autore
- testo messaggio
- reply a messaggi precedenti, se presenti
- messageReference attachments, cioè le citazioni Teams generate dal "Rispondi"
- reazioni emoji sui messaggi, con conteggio
- eventuali mention già trasformate in testo dal parser

Esempio:
    python teams_jsonl_to_word.py --input messages_final.jsonl --output chat_teams.docx

Esempio con ordine cronologico crescente:
    python teams_jsonl_to_word.py --input messages_final.jsonl --output chat_teams.docx --order asc

Esempio limitando i messaggi:
    python teams_jsonl_to_word.py --input messages_final.jsonl --output chat_teams.docx --max-messages 200
"""

from __future__ import annotations

import argparse
import datetime as dt
import html
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


def strip_html_to_text(value: Optional[str]) -> str:
    if not value:
        return ""
    text = value
    text = re.sub(r"(?is)<(script|style).*?>.*?</\1>", " ", text)
    text = re.sub(r"(?i)<br\s*/?>", "\n", text)
    text = re.sub(r"(?i)</p\s*>", "\n", text)
    text = re.sub(r"(?i)</div\s*>", "\n", text)
    text = re.sub(r"(?s)<[^>]+>", " ", text)
    text = html.unescape(text)
    text = text.replace("\xa0", " ")
    text = re.sub(r"[ \t\r\f\v]+", " ", text)
    text = re.sub(r"\n\s+", "\n", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def parse_ts(value: Optional[str]) -> Optional[dt.datetime]:
    if not value:
        return None
    v = value.strip()
    if not v:
        return None
    try:
        if v.endswith("Z"):
            v = v[:-1] + "+00:00"
        # Teams a volte usa millisecondi con 2 o 3 cifre; fromisoformat li gestisce.
        parsed = dt.datetime.fromisoformat(v)
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=dt.timezone.utc)
        return parsed.astimezone(dt.timezone.utc)
    except Exception:
        return None


def format_ts(value: Optional[str]) -> str:
    d = parse_ts(value)
    if not d:
        return value or ""
    # Formato leggibile italiano nel fuso Europe/Rome con CET/CEST automatico.
    local = d.astimezone(ZoneInfo("Europe/Rome"))
    return local.strftime("%d/%m/%Y %H:%M:%S %Z")


def read_jsonl(path: Path) -> List[Dict[str, Any]]:
    messages: List[Dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as f:
        for no, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                if isinstance(obj, dict):
                    messages.append(obj)
            except Exception as exc:
                print(f"[WARN] Riga JSONL ignorata perché non valida: {no}: {exc}")
    return messages


def get_author(m: Dict[str, Any]) -> str:
    if m.get("author"):
        return str(m["author"])
    user = (((m.get("from") or {}).get("user") or {}).get("displayName"))
    if user:
        return str(user)
    raw_user = (((m.get("raw") or {}).get("from") or {}).get("user") or {}).get("displayName")
    return str(raw_user or "Sconosciuto")


def get_text(m: Dict[str, Any]) -> str:
    for key in ("text", "full_text_with_quote"):
        if m.get(key):
            return str(m[key]).strip()
    body_html = m.get("body_html") or (((m.get("raw") or {}).get("body") or {}).get("content"))
    return strip_html_to_text(body_html)


def extract_message_reference_from_attachment(att: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    if not isinstance(att, dict):
        return None
    if att.get("contentType") != "messageReference":
        return None
    content = att.get("content")
    if not content:
        return None
    try:
        ref = json.loads(content)
        if isinstance(ref, dict):
            return ref
    except Exception:
        return None
    return None


def extract_message_references(m: Dict[str, Any]) -> List[Dict[str, Any]]:
    refs: List[Dict[str, Any]] = []
    for att in m.get("attachments") or []:
        ref = extract_message_reference_from_attachment(att)
        if ref:
            refs.append(ref)
    # a volte gli attachments sono solo dentro raw
    raw = m.get("raw") or {}
    for att in raw.get("attachments") or []:
        ref = extract_message_reference_from_attachment(att)
        if ref and ref not in refs:
            refs.append(ref)
    return refs


def build_id_index(messages: Iterable[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    idx: Dict[str, Dict[str, Any]] = {}
    for m in messages:
        mid = str(m.get("id") or "")
        if mid:
            idx[mid] = m
    return idx


def get_reply_context(m: Dict[str, Any], by_id: Dict[str, Dict[str, Any]]) -> Optional[Dict[str, str]]:
    """
    Priorità:
    1. reply_context già calcolato dal downloader v4
    2. replyToId con messaggio presente nel JSONL
    3. attachments contentType=messageReference, come nell'esempio allegato
    4. quoted_reply se già presente
    """
    rc = m.get("reply_context")
    if isinstance(rc, dict) and (rc.get("text") or rc.get("author") or rc.get("createdDateTime")):
        return {
            "source": str(rc.get("source") or "reply_context"),
            "id": str(rc.get("id") or ""),
            "createdDateTime": str(rc.get("createdDateTime") or ""),
            "author": str(rc.get("author") or "Autore non disponibile"),
            "text": str(rc.get("text") or "").strip(),
        }

    reply_to_id = str(m.get("replyToId") or "")
    if reply_to_id and reply_to_id in by_id:
        parent = by_id[reply_to_id]
        return {
            "source": "replyToId",
            "id": reply_to_id,
            "createdDateTime": str(parent.get("createdDateTime") or ""),
            "author": get_author(parent),
            "text": get_text(parent),
        }

    refs = extract_message_references(m)
    if refs:
        ref = refs[0]
        sender = ref.get("messageSender") or {}
        user = sender.get("user") or {}
        author = user.get("displayName") or "Autore non disponibile"
        message_id = str(ref.get("messageId") or "")
        preview = str(ref.get("messagePreview") or "").strip()

        # Se l'id citato è nel file, arricchisco con il timestamp e testo completo.
        if message_id and message_id in by_id:
            parent = by_id[message_id]
            return {
                "source": "messageReference+lookup",
                "id": message_id,
                "createdDateTime": str(parent.get("createdDateTime") or ""),
                "author": get_author(parent),
                "text": get_text(parent),
            }

        return {
            "source": "messageReference",
            "id": message_id,
            "createdDateTime": "",
            "author": str(author),
            "text": preview,
        }

    quoted = m.get("quoted_reply")
    if isinstance(quoted, dict) and quoted.get("quoted_text"):
        return {
            "source": "quoted_reply_html",
            "id": "",
            "createdDateTime": str(quoted.get("quoted_datetime") or ""),
            "author": str(quoted.get("quoted_author") or "Autore non disponibile"),
            "text": str(quoted.get("quoted_text") or ""),
        }

    return None


def reaction_summary(m: Dict[str, Any]) -> str:
    reactions = m.get("reactions") or []
    if not reactions:
        raw = m.get("raw") or {}
        reactions = raw.get("reactions") or []
    if not reactions:
        return ""
    counter = Counter()
    for r in reactions:
        if not isinstance(r, dict):
            continue
        rt = r.get("reactionType") or r.get("displayName") or "reaction"
        counter[str(rt)] += 1
    if not counter:
        return ""
    return "  ".join(f"{k} x{v}" if v > 1 else f"{k}" for k, v in counter.items())


def mentions_summary(m: Dict[str, Any]) -> str:
    mentions = m.get("mentions") or []
    if not mentions:
        return ""
    vals = []
    for x in mentions:
        if isinstance(x, dict):
            t = x.get("mentionText")
            if t:
                vals.append(str(t))
    if not vals:
        return ""
    return ", ".join(vals)


def set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_border(cell, color="D0D7DE", sz="8") -> None:
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    borders = tc_pr.first_child_found_in("w:tcBorders")
    if borders is None:
        borders = OxmlElement("w:tcBorders")
        tc_pr.append(borders)
    for edge in ("top", "left", "bottom", "right"):
        tag = "w:" + edge
        element = borders.find(qn(tag))
        if element is None:
            element = OxmlElement(tag)
            borders.append(element)
        element.set(qn("w:val"), "single")
        element.set(qn("w:sz"), sz)
        element.set(qn("w:space"), "0")
        element.set(qn("w:color"), color)


def set_table_width_pct(table, pct: int) -> None:
    tbl = table._tbl
    tbl_pr = tbl.tblPr
    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:w"), str(pct * 50))
    tbl_w.set(qn("w:type"), "pct")


def add_small_paragraph(cell, text: str, bold: bool = False, color: Optional[str] = None, size: int = 8):
    p = cell.add_paragraph()
    p.paragraph_format.space_after = Pt(2)
    p.paragraph_format.space_before = Pt(0)
    r = p.add_run(text)
    r.bold = bold
    r.font.size = Pt(size)
    if color:
        r.font.color.rgb = RGBColor.from_string(color)
    return p


def add_multiline_text(cell, text: str, size: int = 9, color: Optional[str] = None, italic: bool = False):
    lines = (text or "").splitlines() or [""]
    for i, line in enumerate(lines):
        p = cell.add_paragraph() if i > 0 else cell.paragraphs[-1] if cell.paragraphs and not cell.paragraphs[-1].text else cell.add_paragraph()
        p.paragraph_format.space_after = Pt(2)
        p.paragraph_format.space_before = Pt(0)
        r = p.add_run(line)
        r.font.size = Pt(size)
        r.italic = italic
        if color:
            r.font.color.rgb = RGBColor.from_string(color)


def setup_document(title: str) -> Document:
    doc = Document()
    sec = doc.sections[0]
    sec.top_margin = Inches(0.55)
    sec.bottom_margin = Inches(0.55)
    sec.left_margin = Inches(0.65)
    sec.right_margin = Inches(0.65)

    styles = doc.styles
    styles["Normal"].font.name = "Aptos"
    styles["Normal"].font.size = Pt(9)

    h = doc.add_heading(title, level=0)
    h.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p = doc.add_paragraph("Sequenza messaggi ricostruita da file JSONL Microsoft Teams")
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.runs[0].font.size = Pt(9)
    p.runs[0].font.color.rgb = RGBColor(90, 90, 90)
    return doc


def add_message_block(doc: Document, m: Dict[str, Any], by_id: Dict[str, Dict[str, Any]], include_ids: bool = False) -> None:
    author = get_author(m)
    ts = format_ts(m.get("createdDateTime"))
    text = get_text(m)
    rc = get_reply_context(m, by_id)
    reactions = reaction_summary(m)
    mentions = mentions_summary(m)

    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    table.autofit = True
    set_table_width_pct(table, 94)
    cell = table.cell(0, 0)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.TOP
    set_cell_shading(cell, "F3F6FA")
    set_cell_border(cell, color="D8DEE9", sz="6")

    # Header: timestamp + autore
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(3)
    r = p.add_run(f"[{ts}]  {author}")
    r.bold = True
    r.font.size = Pt(8)
    r.font.color.rgb = RGBColor(64, 73, 86)

    if include_ids:
        r2 = p.add_run(f"  id={m.get('id', '')}")
        r2.font.size = Pt(7)
        r2.font.color.rgb = RGBColor(128, 128, 128)

    if rc:
        # Reply box
        rt = format_ts(rc.get("createdDateTime")) if rc.get("createdDateTime") else "timestamp non disponibile"
        ra = rc.get("author") or "Autore non disponibile"
        source = rc.get("source") or "reply"
        add_small_paragraph(cell, f"↪ In risposta a [{rt}] {ra} ({source})", bold=True, color="59636E", size=8)

        q_table = cell.add_table(rows=1, cols=1)
        q_cell = q_table.cell(0, 0)
        set_cell_shading(q_cell, "FFFFFF")
        set_cell_border(q_cell, color="B7C4D6", sz="6")
        q_cell.paragraphs[0].paragraph_format.space_after = Pt(2)
        q_text = (rc.get("text") or "").strip()
        if q_text:
            add_multiline_text(q_cell, q_text, size=8, color="4B5563", italic=True)
        else:
            add_multiline_text(q_cell, "Messaggio originale non disponibile nel JSONL; presente solo riferimento.", size=8, color="6B7280", italic=True)

    # Corpo messaggio
    body_p = cell.add_paragraph()
    body_p.paragraph_format.space_before = Pt(3)
    body_p.paragraph_format.space_after = Pt(3)
    if text:
        for idx, line in enumerate(text.splitlines()):
            if idx > 0:
                body_p.add_run().add_break()
            rr = body_p.add_run(line)
            rr.font.size = Pt(9)
            rr.font.color.rgb = RGBColor(32, 39, 50)
    else:
        rr = body_p.add_run("[messaggio vuoto o non testuale]")
        rr.italic = True
        rr.font.size = Pt(9)
        rr.font.color.rgb = RGBColor(120, 120, 120)

    # Footer reazioni/mention
    footer_parts = []
    if reactions:
        footer_parts.append(f"Reazioni: {reactions}")
    if mentions:
        footer_parts.append(f"Mention: {mentions}")
    if footer_parts:
        fp = cell.add_paragraph("   ".join(footer_parts))
        fp.paragraph_format.space_before = Pt(2)
        fp.paragraph_format.space_after = Pt(0)
        fr = fp.runs[0]
        fr.font.size = Pt(8)
        fr.font.color.rgb = RGBColor(90, 90, 90)

    doc.add_paragraph().paragraph_format.space_after = Pt(1)


def write_docx(messages: List[Dict[str, Any]], output: Path, title: str, order: str, include_ids: bool, max_messages: int = 0) -> None:
    by_id = build_id_index(messages)

    # Ordine cronologico.
    messages_sorted = sorted(messages, key=lambda m: parse_ts(m.get("createdDateTime")) or dt.datetime.min.replace(tzinfo=dt.timezone.utc))
    if order == "desc":
        messages_sorted = list(reversed(messages_sorted))
    if max_messages and max_messages > 0:
        messages_sorted = messages_sorted[:max_messages]

    doc = setup_document(title)
    info = doc.add_paragraph()
    info.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = info.add_run(f"Messaggi inclusi: {len(messages_sorted)}")
    run.font.size = Pt(8)
    run.font.color.rgb = RGBColor(100, 100, 100)

    for m in messages_sorted:
        add_message_block(doc, m, by_id, include_ids=include_ids)

    doc.save(output)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Converte un JSONL Teams in documento Word stile Teams.")
    p.add_argument("--input", required=True, help="File JSONL di input, es. messages_final.jsonl")
    p.add_argument("--output", required=True, help="File DOCX di output")
    p.add_argument("--title", default="Export conversazione Microsoft Teams", help="Titolo documento")
    p.add_argument("--order", choices=["asc", "desc"], default="asc", help="Ordine messaggi: asc cronologico o desc inverso")
    p.add_argument("--include-ids", action="store_true", help="Mostra id Graph dei messaggi nel DOCX")
    p.add_argument("--max-messages", type=int, default=0, help="Limita il numero di messaggi scritti; 0 = tutti")
    return p


def main() -> int:
    args = build_parser().parse_args()
    input_path = Path(args.input)
    output_path = Path(args.output)

    if not input_path.exists():
        raise FileNotFoundError(f"File input non trovato: {input_path}")

    messages = read_jsonl(input_path)
    if not messages:
        raise RuntimeError("Nessun messaggio valido trovato nel JSONL")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    write_docx(
        messages=messages,
        output=output_path,
        title=args.title,
        order=args.order,
        include_ids=args.include_ids,
        max_messages=args.max_messages,
    )
    print(f"Creato DOCX: {output_path}")
    print(f"Messaggi letti: {len(messages)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

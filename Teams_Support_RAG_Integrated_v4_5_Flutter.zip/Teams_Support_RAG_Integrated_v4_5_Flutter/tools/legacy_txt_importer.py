#!/usr/bin/env python
# -*- coding: utf-8 -*-
r"""
01_parse_chat_txt_incremental_safe.py

Parser incrementale sicuro per i messaggi Teams TXT.

Perché esiste:
- La versione precedente usava INSERT OR REPLACE INTO messages.
- In SQLite, OR REPLACE equivale a DELETE + INSERT.
- Se il messaggio esiste già ed è referenziato da tabelle figlie, il DELETE fallisce
  con FOREIGN KEY constraint failed.
- Inoltre, in append mensile, se i message_id sono basati su seq che riparte da 1,
  si creano collisioni con i messaggi già presenti.

Questa versione:
- NON cancella nulla se non viene passato --reset.
- In append parte da MAX(seq)+1.
- Evita duplicati con chiave naturale: created_ts + author + text.
- Usa INSERT OR IGNORE, non INSERT OR REPLACE.
- Gestisce formato:
    [05/06/2026 17:45:05 UTC]  Autore
    testo
  e anche formato ISO:
    [2026-06-05T17:45:05.937Z] Autore: testo

Uso:
    python src\01_parse_chat_txt_incremental_safe.py ^
      --config config\config.ini ^
      --input data\chat_2026_06_for_llm_parser.txt

Reset completo, da usare solo se vuoi ricaricare tutto:
    python src\01_parse_chat_txt_incremental_safe.py ^
      --config config\config.ini ^
      --input data\chat_2026_06_for_llm_parser.txt ^
      --reset
"""

from __future__ import annotations

import argparse
import configparser
import hashlib
import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

try:
    from tqdm import tqdm
except Exception:
    tqdm = None


OLD_HEADER_RE = re.compile(
    r"^\[(?P<dt>\d{2}/\d{2}/\d{4})\s+(?P<tm>\d{2}:\d{2}:\d{2})\s+UTC\]\s+(?P<author>.*?)\s*$"
)

ISO_HEADER_RE = re.compile(
    r"^\[(?P<ts>\d{4}-\d{2}-\d{2}T[^\]]+Z)\]\s+(?P<author>.*?):\s*(?P<text>.*)$"
)

REPLY_RE = re.compile(
    r"^[?↪]\s*In risposta a\s+\[(?P<dt>\d{2}/\d{2}/\d{4})\s+(?P<tm>\d{2}:\d{2}:\d{2})\s+UTC\]\s+(?P<author>.*?)\s+\((?P<source>.*?)\)\s*$",
    re.IGNORECASE,
)

REACTIONS_RE = re.compile(r"^Reazioni:\s*(?P<reactions>.*)$", re.IGNORECASE)
MENTIONS_RE = re.compile(r"^Mention:\s*(?P<mentions>.*)$", re.IGNORECASE)
SEP_RE = re.compile(r"^-{20,}$")


def load_config(config_path: Path) -> configparser.ConfigParser:
    cfg = configparser.ConfigParser()
    cfg.read(config_path, encoding="utf-8")
    return cfg


def get_db_path(cfg: configparser.ConfigParser, config_path: Path) -> Path:
    candidates = [
        ("paths", "sqlite_db"),
        ("database", "sqlite_db"),
        ("database", "path"),
        ("sqlite", "db_path"),
        ("sqlite", "path"),
    ]
    for section, key in candidates:
        if cfg.has_option(section, key):
            p = Path(cfg.get(section, key))
            if not p.is_absolute():
                p = config_path.parent.parent / p
            return p

    # default progetto
    return config_path.parent.parent / "data" / "support_db2_chat.sqlite"


def parse_old_dt(dt_s: str, tm_s: str) -> str:
    d = datetime.strptime(f"{dt_s} {tm_s}", "%d/%m/%Y %H:%M:%S")
    d = d.replace(tzinfo=timezone.utc)
    return d.isoformat().replace("+00:00", "Z")


def parse_iso_to_z(ts: str) -> str:
    v = ts.strip()
    if v.endswith("Z"):
        v = v[:-1] + "+00:00"
    d = datetime.fromisoformat(v)
    if d.tzinfo is None:
        d = d.replace(tzinfo=timezone.utc)
    else:
        d = d.astimezone(timezone.utc)
    # normalizzo senza millisecondi per avere coerenza con i vecchi txt
    return d.replace(microsecond=0).isoformat().replace("+00:00", "Z")


def split_blocks(text: str) -> List[List[str]]:
    lines = text.splitlines()
    blocks: List[List[str]] = []
    cur: List[str] = []

    for line in lines:
        if SEP_RE.match(line.strip()):
            continue

        is_header = bool(OLD_HEADER_RE.match(line) or ISO_HEADER_RE.match(line))
        if is_header and cur:
            blocks.append(cur)
            cur = [line]
        else:
            if is_header or cur:
                cur.append(line)
            elif line.strip():
                # riga orfana: la ignoriamo per evitare blocchi non parsabili
                continue

    if cur:
        blocks.append(cur)

    return blocks


def parse_reactions(value: str) -> List[Tuple[str, int, str]]:
    value = (value or "").strip()
    if not value:
        return []

    # Esempi:
    # "?? x2"
    # "??  ??"
    # "👍 x3"
    parts = [p.strip() for p in re.split(r"\s{2,}|\s+\+\s+", value) if p.strip()]
    if not parts:
        parts = [value]

    out = []
    for p in parts:
        m = re.search(r"(.+?)\s*x(\d+)\s*$", p, re.IGNORECASE)
        if m:
            out.append((m.group(1).strip(), int(m.group(2)), p))
        else:
            out.append((p.strip(), 1, p))
    return out


def parse_mentions(value: str) -> List[str]:
    value = (value or "").strip()
    if not value:
        return []
    return [x.strip() for x in value.split(",") if x.strip()]


def natural_hash(created_ts: str, author: str, text: str) -> str:
    h = hashlib.sha1(f"{created_ts}|{author}|{text}".encode("utf-8", errors="replace")).hexdigest()
    return h[:20]


def parse_block(block: List[str], seq: int, source_file: str) -> Dict[str, Any]:
    header = block[0]

    old = OLD_HEADER_RE.match(header)
    iso = ISO_HEADER_RE.match(header)

    if old:
        created_ts = parse_old_dt(old.group("dt"), old.group("tm"))
        author = old.group("author").strip() or "Sconosciuto"
        body_lines = block[1:]
    elif iso:
        created_ts = parse_iso_to_z(iso.group("ts"))
        author = iso.group("author").strip() or "Sconosciuto"
        first_text = iso.group("text").strip()
        body_lines = ([first_text] if first_text else []) + block[1:]
    else:
        raise ValueError(f"Header non riconosciuto: {header}")

    reply_to_author = None
    reply_to_ts = None
    reply_source = None
    reply_preview_lines: List[str] = []
    text_lines: List[str] = []
    reactions: List[Tuple[str, int, str]] = []
    mentions: List[str] = []

    in_reply_preview = False

    for line in body_lines:
        s = line.rstrip()

        rm = REPLY_RE.match(s)
        if rm:
            reply_to_author = rm.group("author").strip()
            reply_to_ts = parse_old_dt(rm.group("dt"), rm.group("tm"))
            reply_source = rm.group("source").strip()
            in_reply_preview = True
            continue

        react_m = REACTIONS_RE.match(s)
        if react_m:
            reactions.extend(parse_reactions(react_m.group("reactions")))
            in_reply_preview = False
            continue

        ment_m = MENTIONS_RE.match(s)
        if ment_m:
            mentions.extend(parse_mentions(ment_m.group("mentions")))
            in_reply_preview = False
            continue

        if in_reply_preview and s.strip():
            # Il formato TXT mette subito sotto al reply il testo originale quotato.
            # Quando arriva una riga non vuota dopo il preview, è ambiguo; nel formato
            # generato finora il primo blocco dopo "In risposta" è la preview, poi segue
            # il testo reale. Per non perdere nulla, salviamo la prima riga come preview
            # e le successive anche nel testo.
            if not reply_preview_lines:
                reply_preview_lines.append(s)
            else:
                text_lines.append(s)
                in_reply_preview = False
            continue

        text_lines.append(s)

    text = "\n".join([x for x in text_lines]).strip()
    if not text:
        text = "[messaggio vuoto o non testuale]"

    created_date = created_ts[:10]
    created_time = created_ts[11:19]
    msg_hash = natural_hash(created_ts, author, text)
    message_id = f"MSG{seq:09d}_{msg_hash}"

    return {
        "message_id": message_id,
        "seq": seq,
        "source_file": source_file,
        "created_ts": created_ts,
        "created_date": created_date,
        "created_time": created_time,
        "author": author,
        "text": text,
        "raw_text": text,
        "raw_block": "\n".join(block),
        "has_text": 0 if text == "[messaggio vuoto o non testuale]" else 1,
        "is_reply": 1 if reply_to_ts or reply_to_author else 0,
        "reply_to_message_id": None,
        "reply_to_author": reply_to_author,
        "reply_to_ts": reply_to_ts,
        "reply_preview": "\n".join(reply_preview_lines).strip(),
        "reply_source": reply_source,
        "reactions": reactions,
        "mentions": mentions,
        "mentions_joined": ", ".join(mentions),
        "reactions_joined": " ".join([r[2] for r in reactions]),
    }


def table_columns(con: sqlite3.Connection, table: str) -> List[str]:
    rows = con.execute(f"PRAGMA table_info({table})").fetchall()
    return [r[1] for r in rows]


def table_exists(con: sqlite3.Connection, table: str) -> bool:
    row = con.execute(
        "SELECT 1 FROM sqlite_master WHERE name = ? AND type IN ('table','view')",
        (table,),
    ).fetchone()
    return row is not None


def insert_dict(con: sqlite3.Connection, table: str, data: Dict[str, Any], ignore: bool = True) -> int:
    if not table_exists(con, table):
        return 0

    cols_existing = table_columns(con, table)
    cols = [c for c in cols_existing if c in data and c.lower() != "id"]

    if not cols:
        return 0

    verb = "INSERT OR IGNORE" if ignore else "INSERT"
    sql = f"{verb} INTO {table} ({', '.join(cols)}) VALUES ({', '.join(['?'] * len(cols))})"
    cur = con.execute(sql, [data[c] for c in cols])
    return cur.rowcount if cur.rowcount is not None else 0


def find_existing_message(con: sqlite3.Connection, created_ts: str, author: str, text: str) -> Optional[str]:
    if not table_exists(con, "messages"):
        return None

    row = con.execute(
        """
        SELECT message_id
        FROM messages
        WHERE created_ts = ?
          AND COALESCE(author, '') = ?
          AND COALESCE(text, '') = ?
        LIMIT 1
        """,
        (created_ts, author, text),
    ).fetchone()
    return row[0] if row else None


def find_reply_parent(con: sqlite3.Connection, reply_to_ts: Optional[str], reply_to_author: Optional[str]) -> Optional[str]:
    if not reply_to_ts or not reply_to_author or not table_exists(con, "messages"):
        return None

    row = con.execute(
        """
        SELECT message_id
        FROM messages
        WHERE created_ts = ?
          AND COALESCE(author, '') = ?
        ORDER BY seq DESC
        LIMIT 1
        """,
        (reply_to_ts, reply_to_author),
    ).fetchone()
    return row[0] if row else None


def max_seq(con: sqlite3.Connection) -> int:
    if not table_exists(con, "messages"):
        return 0
    row = con.execute("SELECT COALESCE(MAX(seq), 0) FROM messages").fetchone()
    return int(row[0] or 0)


def clear_for_reset(con: sqlite3.Connection) -> None:
    # Ordine: prima figlie, poi padre.
    tables = [
        "retrieval_history",
        "qa_history",
        "rag_chunks",
        "event_messages",
        "conversation_events",
        "message_contexts",
        "llm_message_analysis",
        "message_entities",
        "message_replies",
        "message_reactions",
        "message_mentions",
        "messages_fts",
        "messages",
    ]
    for t in tables:
        if not table_exists(con, t):
            continue
        try:
            con.execute(f"DELETE FROM {t}")
        except sqlite3.OperationalError as e:
            print(f"ATTENZIONE: non posso svuotare {t}: {e}")


def refresh_fts(con: sqlite3.Connection) -> None:
    if not table_exists(con, "messages_fts"):
        return

    try:
        con.execute("DELETE FROM messages_fts")
        cols = table_columns(con, "messages_fts")
        if "created_ts" in cols:
            con.execute(
                """
                INSERT INTO messages_fts(message_id, created_ts, author, text)
                SELECT
                    COALESCE(message_id, ''),
                    COALESCE(created_ts, ''),
                    COALESCE(author, ''),
                    COALESCE(text, '')
                FROM messages
                """
            )
        else:
            con.execute(
                """
                INSERT INTO messages_fts(message_id, author, text)
                SELECT
                    COALESCE(message_id, ''),
                    COALESCE(author, ''),
                    COALESCE(text, '')
                FROM messages
                """
            )
    except sqlite3.OperationalError as e:
        print(f"ATTENZIONE: refresh FTS non eseguito: {e}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config/config.ini")
    ap.add_argument("--input", required=True)
    ap.add_argument("--reset", action="store_true")
    args = ap.parse_args()

    config_path = Path(args.config)
    input_path = Path(args.input)

    cfg = load_config(config_path)
    db_path = get_db_path(cfg, config_path)

    if not db_path.exists():
        raise FileNotFoundError(f"Database non trovato: {db_path}")

    text = input_path.read_text(encoding="utf-8", errors="replace")
    blocks = split_blocks(text)

    con = sqlite3.connect(db_path)
    con.execute("PRAGMA foreign_keys = ON")

    try:
        if args.reset:
            print("RESET richiesto: svuotamento tabelle principali.")
            clear_for_reset(con)
            start_seq = 1
        else:
            start_seq = max_seq(con) + 1

        inserted = 0
        skipped = 0
        errors = 0
        seq = start_seq

        iterator = tqdm(blocks, desc="Parsing chat TXT incrementale") if tqdm else blocks

        for block in iterator:
            try:
                m = parse_block(block, seq, input_path.name)

                existing_id = find_existing_message(con, m["created_ts"], m["author"], m["text"])
                if existing_id:
                    skipped += 1
                    continue

                parent_id = find_reply_parent(con, m.get("reply_to_ts"), m.get("reply_to_author"))
                m["reply_to_message_id"] = parent_id

                rowcount = insert_dict(con, "messages", m, ignore=True)
                if rowcount == 0:
                    skipped += 1
                    continue

                message_id = m["message_id"]

                if m.get("is_reply"):
                    insert_dict(con, "message_replies", {
                        "message_id": message_id,
                        "reply_to_message_id": parent_id,
                        "reply_to_author": m.get("reply_to_author"),
                        "reply_to_ts": m.get("reply_to_ts"),
                        "reply_to_text": m.get("reply_preview"),
                        "source": m.get("reply_source") or "txt_reply",
                    }, ignore=True)

                for reaction_type, reaction_count, reaction_raw in m.get("reactions") or []:
                    insert_dict(con, "message_reactions", {
                        "message_id": message_id,
                        "reaction_type": reaction_type,
                        "reaction_count": reaction_count,
                        "reaction_raw": reaction_raw,
                    }, ignore=True)

                for mention in m.get("mentions") or []:
                    insert_dict(con, "message_mentions", {
                        "message_id": message_id,
                        "mention_text": mention,
                        "mentioned_user": mention,
                    }, ignore=True)

                inserted += 1
                seq += 1

            except Exception as e:
                errors += 1
                print(f"ERRORE blocco seq={seq}: {e}")
                print("Header/blocco:", block[0] if block else "<vuoto>")

        refresh_fts(con)
        con.commit()

        print(f"Input: {input_path}")
        print(f"Database: {db_path}")
        print(f"Blocchi letti: {len(blocks)}")
        print(f"Messaggi inseriti: {inserted}")
        print(f"Messaggi saltati perché già presenti: {skipped}")
        print(f"Errori blocco: {errors}")
        print(f"Seq iniziale usata: {start_seq}")
        print(f"Seq finale: {seq - 1}")

    finally:
        con.close()

    return 0


if __name__ == "__main__":
    raise SystemExit(main())

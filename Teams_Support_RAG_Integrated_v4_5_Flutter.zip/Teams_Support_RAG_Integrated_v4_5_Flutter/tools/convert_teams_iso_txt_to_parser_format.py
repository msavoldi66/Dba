#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
convert_teams_iso_txt_to_parser_format.py

Converte righe tipo:
[2026-06-05T17:45:05.937Z] Traficante Michele: buon weekend

nel formato atteso dal parser:
[05/06/2026 17:45:05 UTC]  Traficante Michele
buon weekend
"""

from __future__ import annotations

import argparse
import re
from datetime import datetime, timezone
from pathlib import Path

ISO_HEADER_RE = re.compile(
    r"^\[(?P<ts>\d{4}-\d{2}-\d{2}T[^\]]+Z)\]\s+(?P<author>.*?):\s*(?P<text>.*)$"
)
OLD_HEADER_RE = re.compile(
    r"^\[\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2}:\d{2}\s+UTC\]\s+"
)
SEP_RE = re.compile(r"^-{20,}$")


def iso_to_old_timestamp(value: str) -> str:
    v = value.strip()
    if v.endswith("Z"):
        v = v[:-1] + "+00:00"
    dt = datetime.fromisoformat(v)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    else:
        dt = dt.astimezone(timezone.utc)
    return dt.strftime("%d/%m/%Y %H:%M:%S UTC")


def flush_message(out_lines: list[str], current: dict | None) -> None:
    if not current:
        return

    ts_old = iso_to_old_timestamp(current["ts"])
    author = current["author"].strip() or "Sconosciuto"
    text_lines = current["text_lines"]

    out_lines.append(f"[{ts_old}]  {author}")

    if text_lines:
        for line in text_lines:
            out_lines.append(line.rstrip())
    else:
        out_lines.append("[messaggio vuoto o non testuale]")


def convert_file(input_path: Path, output_path: Path) -> tuple[int, int]:
    raw_lines = input_path.read_text(encoding="utf-8", errors="replace").splitlines()

    out_lines: list[str] = []
    current: dict | None = None
    converted = 0
    passthrough_old = 0

    for line in raw_lines:
        if SEP_RE.match(line.strip()):
            continue

        m = ISO_HEADER_RE.match(line)
        if m:
            flush_message(out_lines, current)
            current = {
                "ts": m.group("ts"),
                "author": m.group("author"),
                "text_lines": [m.group("text").rstrip()] if m.group("text").strip() else [],
            }
            converted += 1
            continue

        if OLD_HEADER_RE.match(line):
            flush_message(out_lines, current)
            current = None
            out_lines.append(line.rstrip())
            passthrough_old += 1
            continue

        if current is not None:
            current["text_lines"].append(line.rstrip())
        else:
            if line.strip():
                out_lines.append(line.rstrip())

    flush_message(out_lines, current)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("\n".join(out_lines) + "\n", encoding="utf-8")

    return converted, passthrough_old


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    args = ap.parse_args()

    converted, passthrough_old = convert_file(Path(args.input), Path(args.output))

    print(f"Messaggi ISO convertiti: {converted}")
    print(f"Header vecchio formato mantenuti: {passthrough_old}")
    print(f"Output scritto in: {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

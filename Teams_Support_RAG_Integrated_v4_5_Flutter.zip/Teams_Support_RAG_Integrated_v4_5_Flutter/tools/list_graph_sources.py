from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path
from typing import Iterable

import requests

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

from common import load_config, resolve_path
from graph_auth import get_access_token


def get_all(url: str, token: str, timeout: int = 60) -> list[dict]:
    """Segue @odata.nextLink fino a completare una collection Graph."""
    out: list[dict] = []
    headers = {'Authorization': f'Bearer {token}', 'Accept': 'application/json'}
    while url:
        response = requests.get(url, headers=headers, timeout=timeout)
        response.raise_for_status()
        data = response.json()
        out.extend(data.get('value') or [])
        url = data.get('@odata.nextLink') or ''
    return out


def compact(value: object) -> str:
    if value is None:
        return ''
    return ' '.join(str(value).replace('\r', ' ').replace('\n', ' ').split())


def print_table(headers: list[str], rows: Iterable[list[object]]) -> None:
    rows_s = [[compact(v) for v in row] for row in rows]
    if not rows_s:
        print('(nessun elemento trovato)')
        return
    widths = [len(h) for h in headers]
    for row in rows_s:
        for idx, value in enumerate(row):
            widths[idx] = max(widths[idx], len(value))
    fmt = ' | '.join(f'{{:<{w}}}' for w in widths)
    print(fmt.format(*headers))
    print('-+-'.join('-' * w for w in widths))
    for row in rows_s:
        print(fmt.format(*row))


def list_chats(base: str, token: str, timeout: int) -> list[dict]:
    return get_all(f'{base}/me/chats?$top=50', token, timeout)


def list_joined_teams(base: str, token: str, timeout: int) -> list[dict]:
    # joinedTeams non supporta query OData per personalizzare la risposta.
    return get_all(f'{base}/me/joinedTeams', token, timeout)


def list_team_channels(base: str, token: str, timeout: int, team_id: str) -> list[dict]:
    return get_all(f'{base}/teams/{team_id}/channels', token, timeout)


def collect_channels_for_teams(
    base: str,
    token: str,
    timeout: int,
    teams: list[dict],
) -> tuple[list[dict], list[tuple[str, str]]]:
    channels: list[dict] = []
    errors: list[tuple[str, str]] = []
    for team in teams:
        team_id = compact(team.get('id'))
        team_name = compact(team.get('displayName')) or '(senza nome)'
        if not team_id:
            continue
        try:
            items = list_team_channels(base, token, timeout, team_id)
        except requests.RequestException as exc:
            errors.append((team_name, f'{type(exc).__name__}: {exc}'))
            continue
        for channel in items:
            channels.append(
                {
                    'team_name': team_name,
                    'team_id': team_id,
                    'team_archived': bool(team.get('isArchived')),
                    'channel_name': compact(channel.get('displayName')) or '(senza nome)',
                    'channel_id': compact(channel.get('id')),
                    'membership_type': compact(channel.get('membershipType')),
                    'channel_archived': bool(channel.get('isArchived')),
                    'description': compact(channel.get('description')),
                    'web_url': compact(channel.get('webUrl')),
                }
            )
    return channels, errors


def export_csv(path: Path, chats: list[dict], teams: list[dict], channels: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    team_by_id = {compact(t.get('id')): t for t in teams}
    fieldnames = [
        'source_type', 'team_name', 'team_id', 'name', 'source_id', 'source_subtype',
        'is_archived', 'description', 'web_url',
    ]
    with path.open('w', newline='', encoding='utf-8-sig') as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames, delimiter=';')
        writer.writeheader()
        for chat in chats:
            writer.writerow({
                'source_type': 'chat',
                'team_name': '',
                'team_id': '',
                'name': compact(chat.get('topic')) or '(senza topic)',
                'source_id': compact(chat.get('id')),
                'source_subtype': compact(chat.get('chatType')),
                'is_archived': '',
                'description': '',
                'web_url': compact(chat.get('webUrl')),
            })
        for team in teams:
            writer.writerow({
                'source_type': 'team',
                'team_name': compact(team.get('displayName')) or '(senza nome)',
                'team_id': compact(team.get('id')),
                'name': compact(team.get('displayName')) or '(senza nome)',
                'source_id': compact(team.get('id')),
                'source_subtype': '',
                'is_archived': bool(team.get('isArchived')),
                'description': compact(team.get('description')),
                'web_url': compact(team.get('webUrl')),
            })
        for channel in channels:
            writer.writerow({
                'source_type': 'channel',
                'team_name': channel['team_name'],
                'team_id': channel['team_id'],
                'name': channel['channel_name'],
                'source_id': channel['channel_id'],
                'source_subtype': channel['membership_type'],
                'is_archived': channel['channel_archived'],
                'description': channel['description'],
                'web_url': channel['web_url'],
            })


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            'Elenca sorgenti Microsoft Teams accessibili via Graph. '
            'Senza opzioni mostra chat + Team + channel.'
        )
    )
    parser.add_argument('--config', default='config/config.ini')
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument('--all', action='store_true', help='Mostra chat, Team e channel (default).')
    modes.add_argument('--chats', action='store_true', help='Mostra solo le chat.')
    modes.add_argument('--teams', action='store_true', help='Mostra solo i Team di /me/joinedTeams.')
    modes.add_argument('--channels', action='store_true', help='Mostra i channel. Senza --team-id usa tutti i Team.')
    parser.add_argument('--team-id', default='', help='Con --channels limita l\'elenco a questo Team ID.')
    parser.add_argument('--csv', default='', help='Esporta anche i risultati in CSV (separatore ;).')
    args = parser.parse_args()

    cfg = load_config(args.config)
    token = get_access_token(cfg)
    base = cfg.get('graph', 'base_url', fallback='https://graph.microsoft.com/v1.0').rstrip('/')
    timeout = cfg.getint('graph', 'timeout_seconds', fallback=60)

    mode_all = args.all or not (args.chats or args.teams or args.channels)
    need_chats = mode_all or args.chats
    need_teams = mode_all or args.teams or args.channels
    need_channels = mode_all or args.channels

    chats: list[dict] = []
    teams: list[dict] = []
    channels: list[dict] = []
    errors: list[tuple[str, str]] = []

    if need_chats:
        chats = list_chats(base, token, timeout)

    if need_teams:
        teams = list_joined_teams(base, token, timeout)

    if need_channels:
        if args.team_id:
            selected = [t for t in teams if compact(t.get('id')).lower() == args.team_id.lower()]
            if not selected:
                # Consente anche un Team accessibile che non compaia in /me/joinedTeams.
                selected = [{'id': args.team_id, 'displayName': '(Team specificato)', 'isArchived': False}]
        else:
            selected = teams
        channels, errors = collect_channels_for_teams(base, token, timeout, selected)

    if need_chats:
        print('\n=== CHAT ===')
        print_table(
            ['TOPIC', 'TIPO', 'CHAT ID'],
            [[c.get('topic') or '(senza topic)', c.get('chatType') or '', c.get('id') or ''] for c in chats],
        )
        print(f'Chat trovate: {len(chats)}')

    if args.teams or mode_all:
        print('\n=== TEAM ===')
        print_table(
            ['TEAM NAME', 'ARCHIVIATO', 'TEAM ID'],
            [[t.get('displayName') or '(senza nome)', 'SI' if t.get('isArchived') else 'NO', t.get('id') or ''] for t in teams],
        )
        print(f'Team trovati: {len(teams)}')

    if need_channels:
        print('\n=== CHANNEL ===')
        print_table(
            ['TEAM NAME', 'CHANNEL NAME', 'TIPO', 'TEAM ID', 'CHANNEL ID'],
            [[
                c['team_name'], c['channel_name'], c['membership_type'], c['team_id'], c['channel_id']
            ] for c in channels],
        )
        print(f'Channel trovati: {len(channels)}')
        if errors:
            print('\n[WARN] Alcuni Team non sono stati interrogati:')
            for team_name, error in errors:
                print(f'  - {team_name}: {error}')
            print('Il token potrebbe non avere i permessi necessari oppure il Team potrebbe non essere accessibile.')

    if args.csv:
        csv_path = resolve_path(args.csv)
        export_csv(csv_path, chats, teams, channels)
        print(f'\nCSV scritto: {csv_path}')

    return 0


if __name__ == '__main__':
    raise SystemExit(main())

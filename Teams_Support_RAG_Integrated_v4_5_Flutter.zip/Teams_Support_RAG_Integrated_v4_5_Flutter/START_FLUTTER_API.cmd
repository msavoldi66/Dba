@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "PY=.venv\Scripts\python.exe"
if not exist "%PY%" (
  echo [SETUP] Ambiente Python assente. Eseguo SETUP_ONLY.cmd...
  call SETUP_ONLY.cmd
  if errorlevel 1 exit /b 1
)

powershell -NoProfile -Command "try { $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 http://127.0.0.1:8765/api/health; if($r.StatusCode -eq 200){exit 0}else{exit 1} } catch { exit 1 }" >nul 2>nul
if not errorlevel 1 (
  echo [OK] Flutter API gia' attiva su http://127.0.0.1:8765
  exit /b 0
)

echo [SETUP] Verifico/migro lo schema SQLite per la GUI...
"%PY%" src\00_init_db.py --config config\config.ini >nul
if errorlevel 1 exit /b 1

echo [START] Avvio API locale Flutter/FastAPI...
start "Support DB2 Teams RAG API" /min "%PY%" src\flutter_api_server.py --host 127.0.0.1 --port 8765

set /a N=0
:wait_api
set /a N+=1
powershell -NoProfile -Command "try { $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 http://127.0.0.1:8765/api/health; if($r.StatusCode -eq 200){exit 0}else{exit 1} } catch { exit 1 }" >nul 2>nul
if not errorlevel 1 (
  echo [OK] API pronta.
  exit /b 0
)
if %N% GEQ 20 (
  echo [ERRORE] API non disponibile dopo 20 tentativi.
  exit /b 1
)
timeout /t 1 /nobreak >nul
goto :wait_api

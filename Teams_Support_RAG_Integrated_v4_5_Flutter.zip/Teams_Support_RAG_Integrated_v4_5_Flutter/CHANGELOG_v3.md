# Changelog v3.0.0

- Microsoft Graph access token fornito esclusivamente tramite `graph_access_token.txt`.
- Rimossi MSAL e Device Code Flow dalla pipeline attiva.
- Rimossa la dipendenza `msal` da `requirements.txt`.
- Rimossi dalla configurazione attiva `tenant_id`, `client_id`, `authority`, `auth_mode`, `access_token_env` e scope MSAL.
- `RUN_ALL.cmd` usa la chat `19:meeting_NTc0OTlmZDAtZTUzMy00ZTBiLWI3MWItMjM4YmQ4ZjExZDZm@thread.v2`.
- Aggiunto `--chat-id` a `run_pipeline.py` e `teams_graph_collector.py`.
- Il valore CLI prevale su `config.ini`.
- `LIST_TEAMS_SOURCES.cmd` usa lo stesso token manuale.
- Token file distribuito vuoto e mai valorizzato nel pacchetto.

@echo off
setlocal EnableExtensions
cd /d "%~dp0"
call SETUP_FLUTTER_WINDOWS.cmd
if errorlevel 1 exit /b 1
pushd flutter_app
echo.
echo [BUILD] Compilo applicazione Windows Release...
flutter build windows --release
if errorlevel 1 (popd & exit /b 1)
popd
echo.
echo [OK] Build completata.
echo EXE: flutter_app\build\windows\x64\runner\Release\support_db2_teams_rag.exe
endlocal

# Changelog v4.5 — Flutter Windows

- Streamlit sostituito come UI predefinita da Flutter Windows.
- Interfaccia Fluent UI ottimizzata per desktop.
- Nuovo backend locale `src/flutter_api_server.py` basato su FastAPI.
- Dashboard grafica con KPI, grafico sorgenti, ultimi eventi e messaggi.
- Assistente RAG con fonti, contesto e chunk visualizzabili.
- Ricerca messaggi con filtri multipli e popup dettagliato.
- Vista eventi/timeline con drill-down.
- Vista entità tecniche.
- Vista sorgenti Teams.
- Cronologia Q&A.
- Pagina Pipeline & Sistema con log live e comandi operativi.
- API bindata a `127.0.0.1`.
- Token Graph e chiave DeepInfra non sono mai esposti alla GUI.
- Aggiunti setup/build/launcher Windows Flutter.
- `RUN_ALL.cmd` avvia la GUI Flutter al termine della pipeline.
- Vecchia Streamlit conservata solo sotto `legacy/`.
- Rimossi `streamlit` e `pandas` dalle dipendenze runtime Python della GUI; aggiunti FastAPI/Uvicorn.

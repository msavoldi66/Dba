# Changelog v4.0.0

## Incrementalita Teams

- introdotto watermark persistente per source signature in `state/teams_watermark.json`;
- introdotto `overlap_hours`, default 24;
- primo caricamento storico basato su `createdDateTime desc` e `from_datetime`;
- run successivi basati su `lastModifiedDateTime desc` con filtro temporale Graph;
- intercettazione di nuovi messaggi, edit e variazioni reaction;
- finestra incrementale chiusa all'istante di inizio run per evitare buchi tra esecuzioni;
- `messages_current_run.jsonl` come journal del run/resume;
- `messages_final.jsonl` FULL al primo run e DELTA nei run successivi.

## Affidabilita

- commit watermark a due fasi;
- il collector produce un watermark pendente;
- il watermark viene confermato solo dopo il successo della pipeline core fino ai chunk RAG;
- in caso di errore downstream il watermark non avanza;
- resume `@odata.nextLink` mantiene la stessa finestra del run interrotto;
- `--restart-download` ignora il nextLink senza cancellare il watermark;
- `--reset-watermark` forza un nuovo full scan;
- `--no-download` permette di riprocessare un delta gia acquisito;
- `--no-watermark-commit` disponibile per diagnosi.

## Test

Aggiunto `tests/test_incremental_watermark.py` con simulazione offline di full scan, overlap, update messaggio, pending watermark e commit.

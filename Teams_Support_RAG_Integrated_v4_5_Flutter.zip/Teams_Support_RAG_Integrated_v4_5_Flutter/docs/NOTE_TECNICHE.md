# Note tecniche v4.4

## Autenticazione Graph

La pipeline attiva non implementa OAuth automatico. `src/graph_auth.py` legge e valida esclusivamente `graph_access_token.txt`.

## Modello del watermark

Il watermark non rappresenta l'ID dell'ultimo messaggio: rappresenta il **limite superiore temporale di un run Graph completato e processato con successo**.

Questo consente di interrogare i run successivi tramite `lastModifiedDateTime`, che e piu adatto di `createdDateTime` per intercettare anche edit e reaction.

Per ogni source signature il file `state/teams_watermark.json` memorizza almeno:

- `watermark_utc`;
- data del commit;
- tipo dell'ultima scansione;
- effective since;
- overlap utilizzato;
- ultimo ID osservato;
- ultimo created/modified osservato.

## Finestra incrementale

Per una chat:

```text
since = committed_watermark - overlap_hours
until = run_started_at
```

La richiesta Graph usa ordinamento e filtro sullo stesso campo `lastModifiedDateTime`.

Il limite storico `from_datetime` continua a essere applicato al `createdDateTime`, in modo che una modifica odierna a un messaggio precedente al perimetro storico non venga introdotta accidentalmente nel database.

## Commit a due fasi

`teams_graph_collector.py` termina impostando `pending_watermark_utc`, senza modificare il watermark committato.

`run_pipeline.py` conferma il pending watermark soltanto dopo gli step 01B-06. Questo evita il classico failure mode:

```text
download OK -> watermark avanzato -> import DB KO -> messaggi saltati al run successivo
```

Nella v4 questo scenario diventa:

```text
download OK -> pending watermark -> import DB KO -> watermark invariato
```

## File di stato

`download_state.json` e lo stato transazionale del run corrente e contiene anche `next_link` per il resume.

`messages_checkpoint.jsonl` e lo storico append-only delle versioni Graph effettivamente cambiate.

`messages_current_run.jsonl` contiene invece tutti i messaggi restituiti da Graph nel run corrente e sopravvive al resume. Serve per produrre un `messages_final.jsonl` esattamente corrispondente al run, senza includere record storici solo perche ricadono temporalmente nell'overlap.

## Primo run vs run incrementale

Primo run:

```text
orderby createdDateTime desc
stop quando createdDateTime < from_datetime
```

Run successivi:

```text
orderby lastModifiedDateTime desc
filter lastModifiedDateTime > watermark-overlap
   and lastModifiedDateTime < run_started_at
```

## Chat preconfigurata

```text
19:meeting_NTc0OTlmZDAtZTUzMy00ZTBiLWI3MWItMjM4YmQ4ZjExZDZm@thread.v2
```

`RUN_ALL.cmd` la passa esplicitamente con `--chat-id`, che ha precedenza sul valore del file INI.


## Multi-source v4.3

Le sorgenti operative sono parametrizzate in `config/teams_sources.csv`. Ogni sorgente usa checkpoint e stato Graph separati sotto `data/teams_download/sources/`; l'aggregato del run resta `data/teams_download/messages_final.jsonl`. I watermark sono memorizzati per `source_signature` nello stesso `state/teams_watermark.json`.

La pipeline salva `source_name` in SQLite e costruisce contesti/eventi/finestre temporali RAG senza mescolare chat differenti.


## V4.4 - timezone Europe/Rome

I timestamp restituiti da Microsoft Graph restano UTC nei JSONL e nei watermark. In SQLite la v4.4 salva una coppia locale/UTC per i campi temporali dei messaggi. Il fuso e configurato in `[time] local_timezone` e usa `zoneinfo` + `tzdata`, quindi applica automaticamente CET/CEST. Gli ordinamenti interni preferiscono i campi `*_utc`, mentre Streamlit, report e contesti mostrano i campi locali.

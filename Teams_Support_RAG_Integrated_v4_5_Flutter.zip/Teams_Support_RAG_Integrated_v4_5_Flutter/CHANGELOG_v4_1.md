# Changelog v4.1.0

## Correzione migrazione SQLite legacy

La v4.0 poteva fallire all'avvio con:

```text
sqlite3.OperationalError: no such column: source_signature
```

quando `data/support_db2_chat.sqlite` proveniva dalle versioni precedenti del progetto.

Causa: gli indici Graph (`idx_messages_graph`, `idx_messages_modified`) venivano creati nel blocco schema prima che `ensure_columns()` aggiungesse le nuove colonne alla tabella `messages` gia esistente.

Correzione:

1. creazione delle tabelle mancanti;
2. migrazione delle colonne tramite `ALTER TABLE`;
3. solo successivamente creazione degli indici;
4. ricostruzione FTS5;
5. `PRAGMA user_version=3`.

La migrazione e' in-place e non richiede la cancellazione del database precedente.

## Test di compatibilita

La correzione e' stata verificata su una copia reale di un database legacy del progetto:

- 15.142 messaggi iniziali preservati;
- nuove colonne Graph aggiunte correttamente;
- FTS5 ricostruita con 15.142 documenti;
- indice `idx_messages_graph` creato dopo la migrazione;
- import di un nuovo messaggio Graph riuscito;
- resequencing compatibile con il vecchio vincolo `UNIQUE` su `messages.seq`.

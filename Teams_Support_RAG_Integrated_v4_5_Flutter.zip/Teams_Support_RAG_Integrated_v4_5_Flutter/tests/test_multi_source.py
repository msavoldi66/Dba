from __future__ import annotations

import datetime as dt
import json
import sys
import tempfile
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

import teams_graph_collector as collector
import teams_multi_source as multi
from common import load_config


def raw(mid: str, text: str) -> dict:
    return {
        'id': mid,
        'createdDateTime': '2026-08-27T09:00:00Z',
        'lastModifiedDateTime': '2026-08-27T09:00:00Z',
        'etag': f'e-{mid}',
        'body': {'contentType': 'html', 'content': f'<p>{text}</p>'},
        'from': {'user': {'displayName': 'Tester'}},
        'reactions': [], 'mentions': [], 'attachments': [],
    }


def main() -> None:
    with tempfile.TemporaryDirectory() as td:
        t = Path(td)
        token = t / 'graph_access_token.txt'
        token.write_text('dummy-token', encoding='utf-8')
        sources = t / 'teams_sources.csv'
        sources.write_text(
            'enabled,source_name,mode,chat_id,team_id,channel_id,from_datetime,overlap_hours\n'
            '1,Prima chat,chat,chat-A,,,2026-08-01T00:00:00Z,24\n'
            '1,Seconda chat,chat,chat-B,,,2026-08-01T00:00:00Z,12\n',
            encoding='utf-8'
        )
        cfgp = t / 'config.ini'
        cfgp.write_text(f'''[paths]
sqlite_db = {t / 'db.sqlite'}
teams_out_dir = {t / 'download'}
teams_jsonl = {t / 'download' / 'messages_final.jsonl'}
teams_sources_file = {sources}
teams_sources_out_dir = {t / 'download' / 'sources'}
[graph]
base_url = https://graph.microsoft.com/v1.0
token_file = {token}
timeout_seconds = 5
max_retries = 1
verify_ssl = true
page_size = 50
[teams]
enabled = true
multi_source_enabled = true
mode = chat
chat_id =
from_datetime = 2026-08-01T00:00:00Z
to_datetime =
resume = true
incremental_enabled = true
watermark_file = {t / 'state' / 'watermark.json'}
overlap_hours = 24
sleep_between_pages = 0
max_pages = 0
include_channel_replies = true
''', encoding='utf-8')

        cfg = load_config(cfgp)
        srcs = multi.load_sources(cfg)
        assert len(srcs) == 2
        assert srcs[0].signature != srcs[1].signature
        assert multi.source_dir(cfg, srcs[0]) != multi.source_dir(cfg, srcs[1])

        collector.get_access_token = lambda cfg: 'dummy-token'
        collector.utc_now_dt = lambda: dt.datetime(2026, 8, 27, 10, 0, 0, tzinfo=dt.timezone.utc)

        def fake_graph(url, token_value, timeout, retries, verify_ssl):
            if 'chat-A' in url:
                return {'value': [raw('A1', 'messaggio A')]}
            if 'chat-B' in url:
                return {'value': [raw('B1', 'messaggio B')]}
            raise AssertionError(url)

        collector.graph_get_json = fake_graph
        assert multi.download_all(str(cfgp), cfg, srcs, False, False) == 0

        agg = Path(cfg['paths']['teams_jsonl']).read_text(encoding='utf-8').strip().splitlines()
        assert len(agg) == 2
        objs = [json.loads(x) for x in agg]
        assert {o['source_name'] for o in objs} == {'Prima chat', 'Seconda chat'}
        assert (multi.source_dir(cfg, srcs[0]) / 'download_state.json').exists()
        assert (multi.source_dir(cfg, srcs[1]) / 'download_state.json').exists()

        # Verifica anche import SQLite e isolamento dei contesti tra sorgenti.
        for cmd in [
            [sys.executable, str(ROOT / 'src' / '00_init_db.py'), '--config', str(cfgp)],
            [sys.executable, str(ROOT / 'src' / '01_import_graph_jsonl.py'), '--config', str(cfgp)],
            [sys.executable, str(ROOT / 'src' / '03_build_context_windows.py'), '--config', str(cfgp), '--before', '1', '--after', '1'],
        ]:
            cp = subprocess.run(cmd, cwd=ROOT)
            assert cp.returncode == 0
        multi.sync_registry(cfg, srcs)
        import sqlite3
        con = sqlite3.connect(t / 'db.sqlite')
        assert con.execute('select count(*) from messages').fetchone()[0] == 2
        assert con.execute('select count(*) from teams_sources').fetchone()[0] == 2
        for prev_ids, next_ids in con.execute('select previous_ids,next_ids from message_contexts'):
            assert json.loads(prev_ids) == []
            assert json.loads(next_ids) == []
        con.close()

        assert multi.commit_all(str(cfgp), cfg, srcs) == 0
        wm = json.loads((t / 'state' / 'watermark.json').read_text(encoding='utf-8'))
        assert len(wm['sources']) == 2

    print('MULTI SOURCE TEST OK')


if __name__ == '__main__':
    main()

from __future__ import annotations
import json, subprocess, sys, tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
PY=sys.executable

def run(*args):
    cp=subprocess.run([PY,*args],cwd=ROOT)
    if cp.returncode: raise SystemExit(cp.returncode)

with tempfile.TemporaryDirectory() as td:
    t=Path(td); data=t/'messages.jsonl'; db=t/'test.sqlite'; cfg=t/'config.ini'
    msgs=[
      {'id':'1','createdDateTime':'2026-08-26T08:00:00Z','lastModifiedDateTime':'2026-08-26T08:00:00Z','etag':'1','author':'A','text':'INC024759656 abend J0084029 DB2F SQLCODE -911','source_mode':'chat','source_signature':'chat:test','chatId':'test','reactions':[],'mentions':[],'attachments':[],'raw':{}},
      {'id':'2','createdDateTime':'2026-08-26T08:02:00Z','lastModifiedDateTime':'2026-08-26T08:02:00Z','etag':'1','author':'B','text':'verifico','source_mode':'chat','source_signature':'chat:test','chatId':'test','replyToId':'1','is_reply':True,'reply_context':{'source':'replyToId','id':'1','createdDateTime':'2026-08-26T08:00:00Z','author':'A','text':'INC024759656 abend J0084029 DB2F SQLCODE -911'},'reactions':[],'mentions':[],'attachments':[],'raw':{}}
    ]
    data.write_text('\n'.join(json.dumps(x) for x in msgs)+'\n',encoding='utf-8')
    cfg.write_text(f'''[paths]\nsqlite_db = {db}\nteams_jsonl = {data}\n[llm]\nenabled = false\napi_key_env = DEEPINFRA_API_KEY\nbase_url = https://api.deepinfra.com/v1/openai\nchat_model = test\nembedding_model = test\nmax_messages_per_run = 10\nonly_operational = false\noperational_min_score = 40\n[qdrant]\nenabled = false\nurl = http://localhost:6333\ncollection = test\n[rag]\ncontext_before = 2\ncontext_after = 2\nchunk_window_minutes = 15\n[events]\nmax_gap_minutes = 360\n''',encoding='utf-8')
    run('src/00_init_db.py','--config',str(cfg)); run('src/01_import_graph_jsonl.py','--config',str(cfg))
    run('src/02_extract_entities.py','--config',str(cfg)); run('src/03_build_context_windows.py','--config',str(cfg))
    run('src/04_llm_enrich_messages.py','--config',str(cfg),'--local-only'); run('src/05_group_events.py','--config',str(cfg)); run('src/06_build_rag_chunks.py','--config',str(cfg))
    import sqlite3
    con=sqlite3.connect(db)
    assert con.execute('select count(*) from messages').fetchone()[0]==2
    assert con.execute('select count(*) from message_replies').fetchone()[0]==1
    assert con.execute("select count(*) from messages_fts where messages_fts match 'INC024759656'").fetchone()[0]>=1
print('SELF TEST OK')

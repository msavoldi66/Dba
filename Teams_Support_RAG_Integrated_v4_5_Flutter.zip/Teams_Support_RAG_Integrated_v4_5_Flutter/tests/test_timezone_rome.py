from __future__ import annotations

import json
import sqlite3
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PY = sys.executable


def run(*args):
    cp = subprocess.run([PY, *args], cwd=ROOT)
    assert cp.returncode == 0


def main() -> None:
    with tempfile.TemporaryDirectory() as td:
        t = Path(td)
        db = t / 'test.sqlite'
        data = t / 'messages.jsonl'
        cfg = t / 'config.ini'
        data.write_text('\n'.join([
            json.dumps({'id':'winter','createdDateTime':'2026-01-15T08:00:00Z','lastModifiedDateTime':'2026-01-15T08:30:00Z','author':'A','text':'winter','source_mode':'chat','source_signature':'chat:test','chatId':'test','reactions':[],'mentions':[],'attachments':[],'raw':{}}),
            json.dumps({'id':'summer','createdDateTime':'2026-08-15T08:00:00Z','lastModifiedDateTime':'2026-08-15T08:30:00Z','author':'B','text':'summer','source_mode':'chat','source_signature':'chat:test','chatId':'test','reactions':[],'mentions':[],'attachments':[],'raw':{}}),
        ])+'\n', encoding='utf-8')
        cfg.write_text(f'''[paths]\nsqlite_db = {db}\nteams_jsonl = {data}\n[time]\nlocal_timezone = Europe/Rome\n''', encoding='utf-8')
        run('src/00_init_db.py','--config',str(cfg))
        run('src/01_import_graph_jsonl.py','--config',str(cfg))
        con = sqlite3.connect(db)
        con.row_factory = sqlite3.Row
        w = con.execute("select * from messages where graph_message_id='winter'").fetchone()
        s = con.execute("select * from messages where graph_message_id='summer'").fetchone()
        assert w['created_ts'] == '2026-01-15T09:00:00+01:00', w['created_ts']
        assert w['created_ts_utc'] == '2026-01-15T08:00:00Z'
        assert s['created_ts'] == '2026-08-15T10:00:00+02:00', s['created_ts']
        assert s['created_ts_utc'] == '2026-08-15T08:00:00Z'
        assert s['created_time'] == '10:00:00'
        con.close()

        # Idempotenza dello step 00: non deve aggiungere nuovamente l'offset.
        run('src/00_init_db.py','--config',str(cfg))
        con = sqlite3.connect(db)
        value = con.execute("select created_ts from messages where graph_message_id='summer'").fetchone()[0]
        assert value == '2026-08-15T10:00:00+02:00', value
        con.close()

    print('TIMEZONE EUROPE/ROME TEST OK')


if __name__ == '__main__':
    main()

from __future__ import annotations

import configparser
import datetime as dt
import json
import tempfile
from pathlib import Path

import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

import teams_graph_collector as c


def raw_message(mid: str, created: str, modified: str, etag: str, text: str) -> dict:
    return {
        'id': mid,
        'createdDateTime': created,
        'lastModifiedDateTime': modified,
        'etag': etag,
        'body': {'contentType': 'html', 'content': f'<p>{text}</p>'},
        'from': {'user': {'displayName': 'Tester'}},
        'reactions': [], 'mentions': [], 'attachments': [],
    }


def main() -> None:
    with tempfile.TemporaryDirectory() as td:
        t = Path(td)
        out = t / 'download'
        wm = t / 'state' / 'watermark.json'
        token = t / 'graph_access_token.txt'
        token.write_text('dummy-token', encoding='utf-8')
        cfgp = t / 'config.ini'
        cfgp.write_text(f'''[paths]
teams_out_dir = {out}
teams_jsonl = {out / 'messages_final.jsonl'}
sqlite_db = {t / 'db.sqlite'}
[graph]
base_url = https://graph.microsoft.com/v1.0
token_file = {token}
timeout_seconds = 5
max_retries = 1
verify_ssl = true
page_size = 50
[teams]
enabled = true
mode = chat
chat_id = test-chat
from_datetime = 2026-08-01T00:00:00Z
to_datetime =
resume = true
incremental_enabled = true
watermark_file = {wm}
overlap_hours = 24
sleep_between_pages = 0
max_pages = 0
include_channel_replies = true
''', encoding='utf-8')

        # Nessuna rete reale / nessun auth reale.
        c.get_access_token = lambda cfg: 'dummy-token'
        captured_urls = []
        responses = []

        def fake_graph(url, token_value, timeout, retries, verify_ssl):
            captured_urls.append(url)
            return responses.pop(0)

        c.graph_get_json = fake_graph

        # RUN 1: full scan storico. Il messaggio del 31/07 serve a verificare il limite from_datetime.
        c.utc_now_dt = lambda: dt.datetime(2026, 8, 26, 10, 0, 0, tzinfo=dt.timezone.utc)
        responses.append({'value': [
            raw_message('2', '2026-08-26T08:00:00Z', '2026-08-26T08:00:00Z', 'e2', 'nuovo'),
            raw_message('1', '2026-08-25T08:00:00Z', '2026-08-25T08:00:00Z', 'e1', 'iniziale'),
            raw_message('old', '2026-07-31T08:00:00Z', '2026-07-31T08:00:00Z', 'eo', 'fuori perimetro'),
        ]})
        assert c.run(str(cfgp)) == 0
        assert '$orderby=createdDateTime%20desc' in captured_urls[-1]
        state = json.loads((out / 'download_state.json').read_text(encoding='utf-8'))
        assert state['completed'] is True
        assert state['watermark_committed'] is False
        assert state['pending_watermark_utc'] == '2026-08-26T10:00:00Z'
        assert not wm.exists(), 'Il watermark non deve avanzare prima del commit della pipeline core'
        full_lines = (out / 'messages_final.jsonl').read_text(encoding='utf-8').strip().splitlines()
        assert len(full_lines) == 2

        assert c.commit_pending_watermark(str(cfgp), 'test-chat') == 0
        store = json.loads(wm.read_text(encoding='utf-8'))
        assert store['sources']['chat:test-chat']['watermark_utc'] == '2026-08-26T10:00:00Z'

        # RUN 2: incremental. Simula una modifica/reaction su un messaggio creato ieri.
        c.utc_now_dt = lambda: dt.datetime(2026, 8, 26, 12, 0, 0, tzinfo=dt.timezone.utc)
        responses.append({'value': [
            raw_message('1', '2026-08-25T08:00:00Z', '2026-08-26T09:30:00Z', 'e1-mod', 'modificato/reaction'),
        ]})
        assert c.run(str(cfgp)) == 0
        incr_url = captured_urls[-1]
        assert '$orderby=lastModifiedDateTime%20desc' in incr_url
        assert '$filter=' in incr_url
        state = json.loads((out / 'download_state.json').read_text(encoding='utf-8'))
        assert state['scan_mode'] == 'incremental'
        assert state['effective_since'] == '2026-08-25T10:00:00Z', state['effective_since']
        assert state['pending_watermark_utc'] == '2026-08-26T12:00:00Z'
        # Watermark ancora vecchio finché la pipeline core non fa commit.
        store = json.loads(wm.read_text(encoding='utf-8'))
        assert store['sources']['chat:test-chat']['watermark_utc'] == '2026-08-26T10:00:00Z'
        delta_lines = (out / 'messages_final.jsonl').read_text(encoding='utf-8').strip().splitlines()
        assert len(delta_lines) == 1
        assert json.loads(delta_lines[0])['etag'] == 'e1-mod'

        assert c.commit_pending_watermark(str(cfgp), 'test-chat') == 0
        store = json.loads(wm.read_text(encoding='utf-8'))
        assert store['sources']['chat:test-chat']['watermark_utc'] == '2026-08-26T12:00:00Z'

        # Reset: il run successivo deve tornare full.
        c.reset_source_watermark(configparser.ConfigParser(), 'x') if False else None

    print('INCREMENTAL WATERMARK TEST OK')


if __name__ == '__main__':
    main()

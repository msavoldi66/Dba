# Teams Support RAG v4.5 — Flutter Windows

Questa release sostituisce l'interfaccia Streamlit con una vera applicazione desktop Flutter per Windows, mantenendo invariata la pipeline Python, SQLite, DeepInfra e Qdrant.

## Architettura

```text
Microsoft Teams / Graph
        ↓
Pipeline Python v4.4
        ↓
SQLite + FTS5 + LLM + Eventi + RAG chunks + Qdrant
        ↓
FastAPI locale 127.0.0.1:8765
        ↓
Flutter Windows / Fluent UI
```

La GUI **non apre direttamente SQLite**: tutte le letture e le operazioni passano dall'API locale. Questo evita di duplicare la logica RAG in Dart e riduce il rischio di lock concorrenti sul database.

## Pagine della GUI

### Dashboard
- numero messaggi, analisi LLM, eventi, entità e chunk RAG;
- chunk ancora da embeddare;
- stato Qdrant;
- grafico messaggi per sorgente Teams;
- ultimi eventi;
- ultimi messaggi;
- apertura del dettaglio con popup.

### Assistente RAG
- domanda libera;
- regolazione Top K e score threshold;
- risposta generata dallo stesso `08_rag_query_engine.py` usato dal progetto;
- visualizzazione termini tecnici riconosciuti;
- fonti SQLite/FTS;
- messaggi di contesto prima/dopo;
- chunk Qdrant/RAG;
- popup sul messaggio sorgente.

### Messaggi
Filtri per:
- testo / INC / PTASK / JOB / subsystem / entità;
- autore;
- sorgente Teams;
- intervallo date;
- operational score;
- solo messaggi operativi.

Il popup dettaglio mostra testo, reply, reaction, entità estratte, analisi LLM, eventi associati e contesto.

### Eventi
Timeline degli eventi generati dalla pipeline, con filtri e popup contenente tutti i messaggi dell'evento.

### Entità
Vista a card delle entità estratte con tipo, valore, numero di messaggi e occorrenze.

### Sorgenti Teams
Visualizza le righe di `teams_sources`, chat/channel ID, stato, overlap e numero messaggi.

### Cronologia Q&A
Storico delle domande RAG memorizzate in `qa_history` con popup della risposta.

### Pipeline & Sistema
- stato SQLite, Qdrant, token Graph e chiave DeepInfra;
- watermark;
- path database e progetto;
- log pipeline live;
- pulsante **Incrementale completa**;
- rielaborazione senza download;
- esecuzione senza LLM;
- esecuzione senza Qdrant;
- restart download;
- reset watermark con popup di conferma;
- stop della pipeline.

## Requisiti Windows per Flutter

La pipeline Python continua a funzionare anche senza Flutter. Per compilare la GUI Windows servono:

1. Flutter SDK stable nel `PATH`;
2. Visual Studio (non solo VS Code);
3. workload Visual Studio **Desktop development with C++**;
4. `flutter doctor -v` senza errori nella sezione Windows.

Documentazione ufficiale Flutter:
https://docs.flutter.dev/platform-integration/windows/setup

## Prima installazione

### 1. Configura Python

```bat
SETUP_ONLY.cmd
```

### 2. Configura Flutter Windows

```bat
SETUP_FLUTTER_WINDOWS.cmd
```

Questo comando:
- verifica `flutter` nel PATH;
- abilita Windows desktop;
- genera automaticamente il runner `windows/` se manca;
- esegue `flutter pub get`;
- mostra `flutter doctor -v`.

### 3. Compila l'EXE Release

```bat
BUILD_FLUTTER_WINDOWS.cmd
```

Output previsto:

```text
flutter_app\build\windows\x64\runner\Release\support_db2_teams_rag.exe
```

## Avvio

### Pipeline completa + Flutter

```bat
RUN_ALL.cmd
```

Alla fine della pipeline viene avviata automaticamente la GUI Flutter.

### Solo interfaccia

```bat
RUN_UI_ONLY.cmd
```

Questo avvia prima l'API FastAPI se non è già attiva e poi l'app Flutter.

### Solo API

```bat
START_FLUTTER_API.cmd
```

Health check:

```text
http://127.0.0.1:8765/api/health
```

L'API è bindata esclusivamente a `127.0.0.1` e quindi non viene esposta sulla LAN.

## Componenti aggiunti

```text
src/flutter_api_server.py
flutter_app/
SETUP_FLUTTER_WINDOWS.cmd
BUILD_FLUTTER_WINDOWS.cmd
START_FLUTTER_API.cmd
RUN_FLUTTER_APP.cmd
RUN_UI_ONLY.cmd
```

La vecchia UI Streamlit è stata spostata in:

```text
legacy/09_streamlit_app_v4_4.py
```

e non è più una dipendenza runtime.

## Pacchetti Flutter

- `fluent_ui`: controlli Fluent/Windows;
- `window_manager`: dimensioni e gestione finestra desktop;
- `http`: comunicazione con FastAPI;
- `fl_chart`: grafici dashboard;
- `intl`: formattazione italiana.

## API locale

Endpoint principali:

```text
GET  /api/health
GET  /api/dashboard
GET  /api/sources
GET  /api/messages
GET  /api/messages/{message_id}
GET  /api/events
GET  /api/events/{event_id}
GET  /api/entities
GET  /api/history
POST /api/rag/ask
GET  /api/system/status
POST /api/pipeline/start
GET  /api/pipeline/status
POST /api/pipeline/stop
```

## Sicurezza

- l'API locale ascolta su `127.0.0.1`;
- nessun token Graph viene passato a Flutter;
- Flutter non legge `.env`;
- Flutter non legge `graph_access_token.txt`;
- le credenziali restano esclusivamente nel processo Python;
- non inserire token o API key nel sorgente Dart.

## Timezone

Resta valida la gestione v4.4:

```ini
[time]
local_timezone = Europe/Rome
```

La GUI usa i timestamp locali già convertiti CET/CEST nel database.

## Database esistente

Puoi copiare il tuo database esistente in:

```text
data\support_db2_chat.sqlite
```

La migrazione schema resta quella già introdotta nelle versioni v4.1-v4.4.

## Nota build

Il pacchetto contiene tutto il sorgente Flutter e gli script di bootstrap. Il runner Windows nativo viene generato sulla workstation tramite `flutter create --platforms=windows ...`, così usa la versione corretta del template per il Flutter SDK effettivamente installato.

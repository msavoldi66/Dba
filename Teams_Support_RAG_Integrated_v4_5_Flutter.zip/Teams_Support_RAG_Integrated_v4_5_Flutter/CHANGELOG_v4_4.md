# Changelog v4.4

## Timezone Europe/Rome

- Aggiunta sezione `[time]` con `local_timezone = Europe/Rome`.
- I timestamp Graph restano UTC nei JSONL tecnici e nei campi `*_utc`.
- `messages.created_ts`, `last_modified_ts`, `deleted_ts`, `reply_to_ts` vengono salvati in ora locale Roma.
- `message_replies` e `message_reactions` conservano sia timestamp locale sia UTC.
- Eventi e chunk RAG usano timestamp locali per visualizzazione e UTC per ordinamento tecnico.
- Migrazione automatica/idempotente dei database v4.3 e precedenti tramite `PRAGMA user_version=4`.
- `created_date` e `created_time` vengono rigenerati dal timestamp locale.
- Export TXT del collector e DOCX mostrano ora CET/CEST.
- Aggiunta dipendenza `tzdata` per garantire `Europe/Rome` anche su Windows.
- Aggiunto test `tests/test_timezone_rome.py` per UTC+1 in inverno, UTC+2 in estate e idempotenza.

Nota: non viene applicato un +2 fisso, perche Roma e UTC+1 in inverno e UTC+2 durante l'ora legale.

@echo off
setlocal EnableExtensions
cd /d "%~dp0"
call START_FLUTTER_API.cmd
if errorlevel 1 exit /b 1

set "EXE=flutter_app\build\windows\x64\runner\Release\support_db2_teams_rag.exe"
if exist "%EXE%" (
  echo [START] Avvio applicazione Flutter Windows Release...
  start "Support DB2 Teams RAG" "%EXE%"
  exit /b 0
)

where flutter >nul 2>nul
if errorlevel 1 (
  echo [ERRORE] Build Flutter non presente e Flutter SDK non trovato.
  echo Esegui BUILD_FLUTTER_WINDOWS.cmd su una workstation con Flutter configurato.
  exit /b 1
)

call SETUP_FLUTTER_WINDOWS.cmd
if errorlevel 1 exit /b 1
pushd flutter_app
echo [START] Nessuna build Release presente: avvio in modalita' development.
flutter run -d windows
set RC=%ERRORLEVEL%
popd
exit /b %RC%

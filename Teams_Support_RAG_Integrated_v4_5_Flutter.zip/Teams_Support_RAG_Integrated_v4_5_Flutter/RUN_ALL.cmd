@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set PYTHONUTF8=1

set "VENV=.venv"
set "PY=%VENV%\Scripts\python.exe"

if not exist "%PY%" (
  echo [SETUP] Creo ambiente virtuale Python...
  where py >nul 2>nul
  if errorlevel 1 (
    python -m venv "%VENV%"
  ) else (
    py -3 -m venv "%VENV%"
  )
  if errorlevel 1 goto :error

  echo [SETUP] Installo le dipendenze Python...
  "%PY%" -m pip install --upgrade pip
  if errorlevel 1 goto :error
  "%PY%" -m pip install -r requirements.txt
  if errorlevel 1 goto :error
)

rem Garantisce timezone IANA Europe/Rome anche con venv riusata.
"%PY%" -c "from zoneinfo import ZoneInfo; ZoneInfo('Europe/Rome')" >nul 2>nul
if errorlevel 1 (
  echo [SETUP] Installo/aggiorno tzdata...
  "%PY%" -m pip install "tzdata>=2025.2"
  if errorlevel 1 goto :error
)

rem Verifica FastAPI per GUI Flutter anche su venv provenienti dalle vecchie versioni.
"%PY%" -c "import fastapi,uvicorn" >nul 2>nul
if errorlevel 1 (
  echo [SETUP] Aggiorno dipendenze GUI Flutter/FastAPI...
  "%PY%" -m pip install -r requirements.txt
  if errorlevel 1 goto :error
)

if not exist "config\config.ini" copy /Y "config\config.ini.example" "config\config.ini" >nul
if not exist "config\teams_sources.csv" copy /Y "config\teams_sources.csv.example" "config\teams_sources.csv" >nul
if not exist ".env" (
  copy /Y ".env.example" ".env" >nul
  echo [CONFIG] Creato .env da .env.example. Inserire DEEPINFRA_API_KEY se si usa LLM/Qdrant.
)
if not exist "graph_access_token.txt" type nul > "graph_access_token.txt"
for %%A in ("graph_access_token.txt") do if %%~zA EQU 0 (
  echo.
  echo [CONFIG] graph_access_token.txt e' vuoto.
  echo Incolla il Microsoft Graph access token su una sola riga, senza prefisso Bearer.
  echo Poi riesegui RUN_ALL.cmd.
  goto :error
)

echo.
echo ====================================================================================
echo   TEAMS SUPPORT RAG V4.5 - FLUTTER WINDOWS
 echo ====================================================================================
echo Backend UI  : FastAPI locale 127.0.0.1:8765
echo Frontend    : Flutter Windows / Fluent UI
echo Token Graph : graph_access_token.txt ^(manuale^)
echo Sorgenti    : config\teams_sources.csv
echo Watermark   : separato per sorgente + overlap configurabile
echo Timezone    : Europe/Rome CET/CEST
echo ====================================================================================
"%PY%" src\teams_multi_source.py --config config\config.ini --list
if errorlevel 1 goto :error

echo.
"%PY%" src\run_pipeline.py --config config\config.ini --no-streamlit %*
if errorlevel 1 goto :error

echo.
echo [OK] Pipeline terminata correttamente.
call RUN_FLUTTER_APP.cmd
if errorlevel 1 (
  echo [WARN] Pipeline OK, ma GUI Flutter non avviata. Puoi usare RUN_UI_ONLY.cmd dopo aver configurato Flutter.
)
goto :end

:error
echo.
echo [ERRORE] Esecuzione interrotta. Controlla il messaggio precedente.
exit /b 1

:end
endlocal

from __future__ import annotations

import argparse
import json
import os
import re
from typing import Any, Dict

import requests
from tqdm import tqdm

from common import load_config, connect_db, json_dumps

SYSTEM_PROMPT = '''Sei un analista operativo DBA DB2 for z/OS. Analizza il messaggio Teams e il suo contesto.
Rispondi esclusivamente con un oggetto JSON valido, senza markdown, con i campi:
is_operational, category, subcategory, short_summary, operational_summary, problem_detected,
proposed_action, decision_taken, urgency, status, sentiment, requires_followup,
people_involved, systems_involved, keywords.
Categorie preferite: SALUTO, PRESENZA_ASSENZA, RICHIESTA_AIUTO, CHIARIMENTO_TECNICO,
INCIDENT, PTASK, UDC_CHANGE, JOB_ABEND, DB2_OPERATION, FIDEURAM, PARMUTIL,
REPLICA, DOCUMENTAZIONE, DECISIONE_OPERATIVA, RUMORE_NON_OPERATIVO.'''


def heuristic(row, entities):
    text = (row['text'] or '').lower()
    cats = [e['entity_type'] for e in entities]
    vals = [e['entity_value'] for e in entities]
    is_op = row['operational_score'] >= 40
    category = 'RUMORE_NON_OPERATIVO'
    if any(c == 'INCIDENT' for c in cats) or 'incident' in text: category = 'INCIDENT'
    elif any(c == 'PTASK' for c in cats) or 'ptask' in text: category = 'PTASK'
    elif any(c.startswith('UDC') for c in cats) or 'udc' in text: category = 'UDC_CHANGE'
    elif 'abend' in text: category = 'JOB_ABEND'
    elif 'job' in text or is_op: category = 'DB2_OPERATION' if 'job' in text else 'CHIARIMENTO_TECNICO'
    elif 'fideuram' in text: category = 'FIDEURAM'
    elif 'parmutil' in text: category = 'PARMUTIL'
    return {
        'is_operational': bool(is_op), 'category': category,
        'subcategory': ','.join(sorted(set(cats)))[:200], 'short_summary': (row['text'] or '')[:240],
        'operational_summary': (row['text'] or '')[:1000], 'problem_detected': '', 'proposed_action': '',
        'decision_taken': '', 'urgency': 'alta' if any(x in text for x in ['urgente','abend','riaperto']) else 'normale',
        'status': 'aperto' if any(x in text for x in ['guardiamo','dubbio','chied','riaperto']) else 'non_determinato',
        'sentiment': 'neutro', 'requires_followup': bool(any(x in text for x in ['chied','guardiamo','verific','riaperto','sospeso'])),
        'people_involved': [], 'systems_involved': vals, 'keywords': vals,
    }


def extract_json_object(content: str) -> Dict[str, Any]:
    s = (content or '').strip()
    s = re.sub(r'^```(?:json)?\s*', '', s, flags=re.I)
    s = re.sub(r'\s*```$', '', s)
    try:
        obj = json.loads(s)
        if isinstance(obj, dict): return obj
    except Exception:
        pass
    # Estrazione tollerante del primo oggetto JSON bilanciato.
    start = s.find('{')
    if start < 0: raise ValueError('Nessun oggetto JSON nella risposta LLM')
    depth = 0; in_string = False; escape = False
    for i, ch in enumerate(s[start:], start):
        if in_string:
            if escape: escape = False
            elif ch == '\\': escape = True
            elif ch == '"': in_string = False
            continue
        if ch == '"': in_string = True
        elif ch == '{': depth += 1
        elif ch == '}':
            depth -= 1
            if depth == 0:
                obj = json.loads(s[start:i+1])
                if isinstance(obj, dict): return obj
    raise ValueError('JSON LLM incompleto/non valido')


def request_llm(cfg, messages, response_format=True) -> str:
    api_key = os.environ.get(cfg['llm'].get('api_key_env', 'DEEPINFRA_API_KEY'), '')
    if not api_key: raise RuntimeError('API key LLM non impostata')
    url = cfg['llm'].get('base_url').rstrip('/') + '/chat/completions'
    payload = {'model': cfg['llm'].get('chat_model'), 'messages': messages, 'temperature': 0, 'max_tokens': 700}
    if response_format:
        payload['response_format'] = {'type': 'json_object'}
    r = requests.post(url, headers={'Authorization': f'Bearer {api_key}', 'Content-Type':'application/json'}, json=payload, timeout=120)
    # Alcuni endpoint OpenAI-compatible non implementano response_format.
    if r.status_code >= 400 and response_format:
        return request_llm(cfg, messages, response_format=False)
    r.raise_for_status()
    return r.json()['choices'][0]['message']['content']


def call_llm(cfg, context_text):
    messages = [{'role':'system','content':SYSTEM_PROMPT}, {'role':'user','content':context_text}]
    content = request_llm(cfg, messages)
    try:
        return extract_json_object(content)
    except Exception as first:
        if not cfg.getboolean('llm', 'json_repair_retry', fallback=True): raise
        repair = messages + [{'role':'assistant','content':content},
            {'role':'user','content':'La risposta precedente non era JSON valido. Restituisci soltanto lo stesso contenuto corretto come singolo oggetto JSON valido.'}]
        repaired = request_llm(cfg, repair)
        try: return extract_json_object(repaired)
        except Exception as second: raise RuntimeError(f'JSON LLM non valido dopo repair: {first}; {second}')


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', default='config/config.ini')
    ap.add_argument('--only-operational', action='store_true')
    ap.add_argument('--force', action='store_true'); ap.add_argument('--local-only', action='store_true')
    args = ap.parse_args()
    cfg = load_config(args.config); con = connect_db(cfg['paths']['sqlite_db'])
    enabled = cfg.getboolean('llm', 'enabled', fallback=False) and not args.local_only
    limit = cfg.getint('llm', 'max_messages_per_run', fallback=100)
    min_score = cfg.getint('llm', 'operational_min_score', fallback=40)
    only_op = args.only_operational or cfg.getboolean('llm', 'only_operational', fallback=False)
    where = 'WHERE m.has_text=1'
    if only_op: where += f' AND m.operational_score >= {int(min_score)}'
    if not args.force: where += ' AND NOT EXISTS (SELECT 1 FROM llm_message_analysis a WHERE a.message_id=m.message_id)'
    rows = con.execute(f'''SELECT m.*, c.context_text FROM messages m LEFT JOIN message_contexts c ON c.message_id=m.message_id
                           {where} ORDER BY COALESCE(NULLIF(m.created_ts_utc,''), m.created_ts), m.seq LIMIT ?''', (limit,)).fetchall()
    fallbacks = 0
    for row in tqdm(rows, desc='LLM/heuristic enrichment'):
        ents = con.execute('SELECT entity_type, entity_value FROM message_entities WHERE message_id=?', (row['message_id'],)).fetchall()
        if enabled:
            try:
                data = call_llm(cfg, row['context_text'] or row['text'] or ''); model = cfg['llm'].get('chat_model')
            except Exception as e:
                data = heuristic(row, ents); data['llm_error'] = str(e); model = 'heuristic_fallback'; fallbacks += 1
        else:
            data = heuristic(row, ents); model = 'heuristic_local'
        con.execute('''INSERT INTO llm_message_analysis(message_id,is_operational,category,subcategory,short_summary,operational_summary,
            problem_detected,proposed_action,decision_taken,urgency,status,sentiment,requires_followup,
            people_involved,systems_involved,keywords,llm_model,llm_raw_json) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''', (
            row['message_id'], int(bool(data.get('is_operational'))), data.get('category'), data.get('subcategory'), data.get('short_summary'),
            data.get('operational_summary'), data.get('problem_detected'), data.get('proposed_action'), data.get('decision_taken'),
            data.get('urgency'), data.get('status'), data.get('sentiment'), int(bool(data.get('requires_followup'))),
            json_dumps(data.get('people_involved', [])), json_dumps(data.get('systems_involved', [])), json_dumps(data.get('keywords', [])), model, json_dumps(data)))
    con.commit()
    print(f'Messaggi arricchiti: {len(rows)}; fallback euristici: {fallbacks}')
    return 0


if __name__ == '__main__': raise SystemExit(main())

from __future__ import annotations

import argparse
import os
import subprocess
import sys
import time
from pathlib import Path

from common import load_config, resolve_path, connect_db, now_utc

ROOT = Path(__file__).resolve().parents[1]


def run_step(cfg, name: str, args: list[str], optional: bool = False) -> bool:
    print('\n' + '=' * 92)
    print(f'[{now_utc()}] STEP: {name}')
    print('=' * 92, flush=True)
    started = time.time()
    cp = subprocess.run([sys.executable, *args], cwd=ROOT)
    elapsed = round(time.time() - started, 1)
    try:
        con = connect_db(cfg['paths']['sqlite_db'])
        con.execute('INSERT INTO run_log(step_name,status,details) VALUES (?,?,?)',
                    (name, 'OK' if cp.returncode == 0 else 'ERROR', f'rc={cp.returncode}; elapsed={elapsed}s'))
        con.commit()
        con.close()
    except Exception:
        pass
    if cp.returncode != 0:
        if optional and cfg.getboolean('pipeline', 'continue_on_optional_error', fallback=True):
            print(f'[WARN] Step opzionale {name} fallito (rc={cp.returncode}); continuo.')
            return False
        raise RuntimeError(f'Step {name} fallito con rc={cp.returncode}')
    print(f'[OK] {name} completato in {elapsed}s')
    return True


def main() -> int:
    ap = argparse.ArgumentParser(description='Pipeline unica Teams -> Graph -> SQLite -> RAG (GUI Flutter separata)')
    ap.add_argument('--config', default='config/config.ini')
    ap.add_argument('--chat-id', default='', help='Override legacy per eseguire una singola chat')
    ap.add_argument('--sources-file', default='', help='Override della tabella CSV multi-sorgente')
    ap.add_argument('--no-download', action='store_true', help='Usa il JSONL già presente')
    ap.add_argument('--restart-download', action='store_true', help='Ignora nextLink salvato, ma mantiene il watermark incrementale')
    ap.add_argument('--reset-watermark', action='store_true', help='Cancella il watermark della chat e forza un nuovo full scan')
    ap.add_argument('--no-watermark-commit', action='store_true', help='Non confermare il watermark pendente al termine della pipeline core')
    ap.add_argument('--no-llm', action='store_true')
    ap.add_argument('--no-qdrant', action='store_true')
    ap.add_argument('--recreate-qdrant', action='store_true')
    ap.add_argument('--no-streamlit', action='store_true')
    args = ap.parse_args()
    cfg = load_config(args.config)

    run_step(cfg, '00 - Init/migrazione SQLite + FTS', ['src/00_init_db.py', '--config', args.config])

    multi_source = cfg.getboolean('teams', 'multi_source_enabled', fallback=False) and not args.chat_id

    if cfg.getboolean('teams', 'enabled', fallback=True) and not args.no_download:
        if multi_source:
            cargs = ['src/teams_multi_source.py', '--config', args.config, '--download']
            if args.sources_file:
                cargs += ['--sources-file', args.sources_file]
            if args.restart_download:
                cargs.append('--restart')
            if args.reset_watermark:
                cargs.append('--reset-watermarks')
            run_step(cfg, '01A - Download Microsoft Teams multi-sorgente via Graph', cargs)
        else:
            cargs = ['src/teams_graph_collector.py', '--config', args.config]
            if args.chat_id:
                cargs += ['--chat-id', args.chat_id]
            if args.restart_download:
                cargs.append('--restart')
            if args.reset_watermark:
                cargs.append('--reset-watermark')
            run_step(cfg, '01A - Download Microsoft Teams via Graph (watermark incrementale)', cargs)

    jsonl = resolve_path(cfg.get('paths', 'teams_jsonl', fallback='data/teams_download/messages_final.jsonl'))
    if not jsonl.exists():
        raise FileNotFoundError(
            f'JSONL da importare non trovato: {jsonl}. '
            'Esegui il download o usa --no-download solo con un JSONL esistente.'
        )

    run_step(cfg, '01B - Import JSONL Graph in SQLite', ['src/01_import_graph_jsonl.py', '--config', args.config])
    run_step(cfg, '02 - Estrazione entità operative', ['src/02_extract_entities.py', '--config', args.config])
    run_step(cfg, '03 - Costruzione contesti', ['src/03_build_context_windows.py', '--config', args.config])

    if cfg.getboolean('llm', 'enabled', fallback=False) and not args.no_llm:
        run_step(cfg, '04 - Arricchimento LLM', ['src/04_llm_enrich_messages.py', '--config', args.config], optional=True)
    else:
        run_step(cfg, '04 - Arricchimento euristico locale',
                 ['src/04_llm_enrich_messages.py', '--config', args.config, '--local-only'], optional=True)

    run_step(cfg, '05 - Raggruppamento eventi temporali', ['src/05_group_events.py', '--config', args.config])
    run_step(cfg, '06 - Costruzione/aggiornamento chunk RAG', ['src/06_build_rag_chunks.py', '--config', args.config])

    # V4: il watermark viene confermato SOLO dopo il successo della pipeline core.
    # Se import/entità/contesti/eventi/chunk falliscono, il watermark non avanza e il run successivo
    # riparte dalla vecchia finestra senza rischio di saltare messaggi.
    if not args.no_watermark_commit:
        if multi_source:
            wargs = ['src/teams_multi_source.py', '--config', args.config, '--commit-watermarks']
            if args.sources_file:
                wargs += ['--sources-file', args.sources_file]
            run_step(cfg, '06B - Commit watermark Teams multi-sorgente', wargs)
        else:
            wargs = ['src/teams_graph_collector.py', '--config', args.config, '--commit-watermark']
            if args.chat_id:
                wargs += ['--chat-id', args.chat_id]
            run_step(cfg, '06B - Commit watermark Teams', wargs)

    if cfg.getboolean('qdrant', 'enabled', fallback=True) and not args.no_qdrant:
        qargs = ['src/07_embed_qdrant.py', '--config', args.config]
        if args.recreate_qdrant:
            qargs.append('--recreate-collection')
        required = cfg.getboolean('qdrant', 'required', fallback=False)
        run_step(cfg, '07 - Embedding + Qdrant', qargs, optional=not required)

    if cfg.getboolean('pipeline', 'generate_word_export', fallback=False):
        out = resolve_path(cfg.get('paths', 'export_dir', fallback='exports'))
        out.mkdir(parents=True, exist_ok=True)
        run_step(
            cfg,
            '08 - Export Word messaggi',
            ['tools/teams_jsonl_to_word.py', '--input', str(jsonl), '--output', str(out / 'Teams_messages.docx'), '--order', 'asc'],
            optional=True,
        )

    print('\n' + '=' * 92)
    print('PIPELINE COMPLETATA')
    print(f'Database : {resolve_path(cfg["paths"]["sqlite_db"])}')
    print(f'JSONL    : {jsonl}')
    print(f'Watermark: {resolve_path(cfg.get("teams", "watermark_file", fallback="state/teams_watermark.json"))}')
    print('=' * 92)

    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f'\n[ERRORE PIPELINE] {exc}', file=sys.stderr)
        raise SystemExit(1)

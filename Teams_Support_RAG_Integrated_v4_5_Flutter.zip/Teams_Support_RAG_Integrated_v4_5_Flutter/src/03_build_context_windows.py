from __future__ import annotations

import argparse
from collections import defaultdict
from common import load_config, connect_db, json_dumps


def fmt_msg(r):
    return f"[{r['created_ts']}] {r['author']}: {r['text'] or '[vuoto]'}"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', default='config/config.ini')
    ap.add_argument('--before', type=int)
    ap.add_argument('--after', type=int)
    args = ap.parse_args()
    cfg = load_config(args.config)
    before = args.before if args.before is not None else cfg.getint('rag', 'context_before')
    after = args.after if args.after is not None else cfg.getint('rag', 'context_after')
    con = connect_db(cfg['paths']['sqlite_db'])
    con.execute('DELETE FROM message_contexts')
    rows = con.execute("SELECT * FROM messages ORDER BY source_signature, COALESCE(NULLIF(created_ts_utc,''), created_ts), seq, message_id").fetchall()
    by_id = {r['message_id']: r for r in rows}
    by_source = defaultdict(list)
    for row in rows:
        by_source[row['source_signature'] or 'legacy'].append(row)
    position = {}
    for sig, srows in by_source.items():
        for idx, row in enumerate(srows):
            position[row['message_id']] = (sig, idx)
    # link replies by ts+author approximate
    for rep in con.execute('SELECT id, message_id, reply_to_ts, reply_to_ts_utc, reply_to_author FROM message_replies WHERE reply_to_message_id IS NULL').fetchall():
        parent = None
        rep_src = con.execute('SELECT source_signature FROM messages WHERE message_id=?', (rep['message_id'],)).fetchone()
        candidates = by_source.get((rep_src['source_signature'] if rep_src else '') or 'legacy', [])
        for r in candidates:
            if (r['created_ts_utc'] or r['created_ts']) == (rep['reply_to_ts_utc'] or rep['reply_to_ts']) and (rep['reply_to_author'] or '').lower() in (r['author'] or '').lower():
                parent = r['message_id']; break
        if parent:
            con.execute('UPDATE message_replies SET reply_to_message_id=? WHERE id=?', (parent, rep['id']))
            con.execute('UPDATE messages SET reply_to_message_id=? WHERE message_id=?', (parent, rep['message_id']))
    con.commit()

    children = defaultdict(list)
    for r in con.execute('SELECT message_id, reply_to_message_id FROM messages WHERE reply_to_message_id IS NOT NULL').fetchall():
        children[r['reply_to_message_id']].append(r['message_id'])

    ent_to_ids = defaultdict(list)
    for er in con.execute('''SELECT e.message_id, e.entity_type, e.entity_value, m.source_signature
                             FROM message_entities e JOIN messages m ON m.message_id=e.message_id''').fetchall():
        ent_to_ids[(er['source_signature'] or 'legacy', er['entity_type'], er['entity_value'].upper())].append(er['message_id'])

    count = 0
    for r in rows:
        sig, i = position[r['message_id']]
        srows = by_source[sig]
        prev_rows = srows[max(0, i-before):i]
        next_rows = srows[i+1:i+1+after]
        ent_rows = con.execute('SELECT entity_type, entity_value FROM message_entities WHERE message_id=?', (r['message_id'],)).fetchall()
        same = []
        for e in ent_rows:
            same.extend(ent_to_ids.get((r['source_signature'] or 'legacy', e['entity_type'], e['entity_value'].upper()), []))
        same = [x for x in dict.fromkeys(same) if x != r['message_id']][:20]
        parent_id = r['reply_to_message_id']
        parent = by_id.get(parent_id) if parent_id else None
        parts = []
        if parent:
            parts.append('MESSAGGIO A CUI RISPONDE:\n' + fmt_msg(parent))
        if prev_rows:
            parts.append('MESSAGGI PRECEDENTI:\n' + '\n'.join(fmt_msg(x) for x in prev_rows))
        parts.append('MESSAGGIO CORRENTE:\n' + fmt_msg(r))
        if next_rows:
            parts.append('MESSAGGI SUCCESSIVI:\n' + '\n'.join(fmt_msg(x) for x in next_rows))
        if ent_rows:
            parts.append('ENTITÀ:\n' + ', '.join(f"{e['entity_type']}={e['entity_value']}" for e in ent_rows))
        context_text = '\n\n'.join(parts)
        con.execute('''INSERT OR REPLACE INTO message_contexts(message_id, context_text, previous_ids, next_ids, reply_parent_id, reply_children_ids, same_entity_ids)
                       VALUES (?, ?, ?, ?, ?, ?, ?)''', (r['message_id'], context_text, json_dumps([x['message_id'] for x in prev_rows]), json_dumps([x['message_id'] for x in next_rows]), parent_id, json_dumps(children.get(r['message_id'], [])), json_dumps(same)))
        count += 1
    con.commit()
    print(f'Contesti creati: {count}')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())

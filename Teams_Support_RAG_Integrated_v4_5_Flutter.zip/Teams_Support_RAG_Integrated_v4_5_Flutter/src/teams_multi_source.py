from __future__ import annotations

import argparse
import csv
import hashlib
import json
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List

from common import connect_db, load_config, now_utc, resolve_path
from teams_graph_collector import commit_pending_watermark, run as collect_one, source_signature


@dataclass
class Source:
    enabled: bool
    source_name: str
    mode: str
    chat_id: str = ''
    team_id: str = ''
    channel_id: str = ''
    from_datetime: str = ''
    overlap_hours: float | None = None

    @property
    def signature(self) -> str:
        return source_signature(self.mode, self.chat_id, self.team_id, self.channel_id)

    @property
    def key(self) -> str:
        return f'{self.mode}_{hashlib.sha1(self.signature.encode("utf-8")).hexdigest()[:12]}'


def _bool(v: str) -> bool:
    return str(v or '').strip().lower() in {'1', 'true', 'yes', 'y', 'si', 's'}


def load_sources(cfg, override: str = '') -> List[Source]:
    p = resolve_path(override or cfg.get('paths', 'teams_sources_file', fallback='config/teams_sources.csv'))
    if not p.exists():
        raise FileNotFoundError(f'Tabella sorgenti Teams non trovata: {p}')
    rows: List[Source] = []
    with p.open('r', encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f)
        required = {'enabled', 'source_name', 'mode', 'chat_id', 'team_id', 'channel_id', 'from_datetime', 'overlap_hours'}
        missing = required - set(reader.fieldnames or [])
        if missing:
            raise RuntimeError(f'Colonne mancanti in {p.name}: {", ".join(sorted(missing))}')
        for no, r in enumerate(reader, 2):
            if not _bool(r.get('enabled', '')):
                continue
            mode = (r.get('mode') or 'chat').strip().lower()
            if mode not in {'chat', 'channel'}:
                raise RuntimeError(f'Riga {no}: mode deve essere chat oppure channel')
            src = Source(
                enabled=True,
                source_name=(r.get('source_name') or '').strip() or f'Sorgente riga {no}',
                mode=mode,
                chat_id=(r.get('chat_id') or '').strip(),
                team_id=(r.get('team_id') or '').strip(),
                channel_id=(r.get('channel_id') or '').strip(),
                from_datetime=(r.get('from_datetime') or '').strip(),
                overlap_hours=float(r['overlap_hours']) if (r.get('overlap_hours') or '').strip() else None,
            )
            if mode == 'chat' and not src.chat_id:
                raise RuntimeError(f'Riga {no}: chat_id obbligatorio per {src.source_name}')
            if mode == 'channel' and (not src.team_id or not src.channel_id):
                raise RuntimeError(f'Riga {no}: team_id e channel_id obbligatori per {src.source_name}')
            rows.append(src)
    if not rows:
        raise RuntimeError(f'Nessuna sorgente Teams abilitata in {p}')
    seen = set()
    for src in rows:
        if src.signature in seen:
            raise RuntimeError(f'Sorgente duplicata nella tabella: {src.signature}')
        seen.add(src.signature)
    return rows


def source_dir(cfg, src: Source) -> Path:
    root = resolve_path(cfg.get('paths', 'teams_sources_out_dir', fallback='data/teams_download/sources'))
    return root / src.key


def sync_registry(cfg, sources: Iterable[Source]) -> None:
    try:
        con = connect_db(cfg['paths']['sqlite_db'])
    except Exception:
        return
    try:
        tables = {r['name'] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
        if 'teams_sources' not in tables or 'messages' not in tables:
            return
        for src in sources:
            con.execute('''
                INSERT INTO teams_sources(source_signature,source_name,mode,chat_id,team_id,channel_id,enabled,configured_from_datetime,overlap_hours,updated_at)
                VALUES (?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(source_signature) DO UPDATE SET
                  source_name=excluded.source_name, mode=excluded.mode, chat_id=excluded.chat_id,
                  team_id=excluded.team_id, channel_id=excluded.channel_id, enabled=excluded.enabled,
                  configured_from_datetime=excluded.configured_from_datetime,
                  overlap_hours=excluded.overlap_hours, updated_at=excluded.updated_at
            ''', (src.signature, src.source_name, src.mode, src.chat_id, src.team_id, src.channel_id, 1,
                  src.from_datetime, src.overlap_hours, now_utc()))
            # Backfill del nome sui messaggi storici del DB legacy.
            con.execute('UPDATE messages SET source_name=? WHERE source_signature=? AND COALESCE(source_name, "")<>?',
                        (src.source_name, src.signature, src.source_name))
        con.commit()
    finally:
        con.close()


def migrate_legacy_shared_files(cfg, sources: List[Source]) -> None:
    """Migra in modo non distruttivo il checkpoint/state condiviso della v4.x verso cartelle per sorgente."""
    legacy_root = resolve_path(cfg.get('paths', 'teams_out_dir', fallback='data/teams_download'))
    legacy_cp = legacy_root / 'messages_checkpoint.jsonl'
    if legacy_cp.exists():
        handles = {}
        try:
            for src in sources:
                dst = source_dir(cfg, src) / 'messages_checkpoint.jsonl'
                if not dst.exists():
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    handles[src.signature] = dst.open('w', encoding='utf-8')
            if handles:
                with legacy_cp.open('r', encoding='utf-8') as f:
                    for line in f:
                        try:
                            obj = json.loads(line)
                        except Exception:
                            continue
                        h = handles.get(str(obj.get('source_signature') or ''))
                        if h:
                            h.write(line if line.endswith('\n') else line + '\n')
        finally:
            for h in handles.values():
                h.close()

    legacy_state = legacy_root / 'download_state.json'
    if legacy_state.exists():
        try:
            state = json.loads(legacy_state.read_text(encoding='utf-8'))
            sig = str(state.get('source_signature') or '')
            for src in sources:
                if src.signature == sig:
                    dst = source_dir(cfg, src) / 'download_state.json'
                    if not dst.exists() and state.get('in_progress'):
                        dst.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(legacy_state, dst)
        except Exception:
            pass


def aggregate_outputs(cfg, sources: List[Source]) -> int:
    final = resolve_path(cfg.get('paths', 'teams_jsonl', fallback='data/teams_download/messages_final.jsonl'))
    final.parent.mkdir(parents=True, exist_ok=True)
    count = 0
    with final.open('w', encoding='utf-8') as out:
        for src in sources:
            p = source_dir(cfg, src) / 'messages_final.jsonl'
            if not p.exists():
                raise FileNotFoundError(f'Output sorgente mancante: {p}')
            with p.open('r', encoding='utf-8') as f:
                for line in f:
                    if line.strip():
                        out.write(line if line.endswith('\n') else line + '\n')
                        count += 1
    print(f'[{now_utc()}] JSONL aggregato multi-sorgente: {count} messaggi -> {final}')
    return count


def download_all(config_path: str, cfg, sources: List[Source], restart: bool, reset_watermarks: bool) -> int:
    migrate_legacy_shared_files(cfg, sources)
    sync_registry(cfg, sources)
    for idx, src in enumerate(sources, 1):
        out = source_dir(cfg, src)
        print('\n' + '-' * 92)
        print(f'[{now_utc()}] SORGENTE {idx}/{len(sources)}: {src.source_name}')
        print(f'  mode={src.mode} signature={src.signature}')
        print(f'  out={out}')
        print('-' * 92)
        rc = collect_one(
            config_path, restart=restart, chat_id_override=src.chat_id,
            reset_watermark=reset_watermarks, out_dir_override=str(out), mode_override=src.mode,
            team_id_override=src.team_id, channel_id_override=src.channel_id,
            from_datetime_override=src.from_datetime, overlap_hours_override=src.overlap_hours,
            source_name=src.source_name,
        )
        if rc != 0:
            return rc
    aggregate_outputs(cfg, sources)
    return 0


def commit_all(config_path: str, cfg, sources: List[Source]) -> int:
    sync_registry(cfg, sources)
    errors = 0
    for src in sources:
        try:
            rc = commit_pending_watermark(
                config_path, chat_id_override=src.chat_id, out_dir_override=str(source_dir(cfg, src)),
                mode_override=src.mode, team_id_override=src.team_id, channel_id_override=src.channel_id,
            )
            errors += int(rc != 0)
        except Exception as exc:
            errors += 1
            print(f'[ERRORE] Commit watermark {src.source_name}: {exc}')
    return 1 if errors else 0


def print_sources(cfg, sources: List[Source]) -> None:
    print('SORGENTI TEAMS CONFIGURATE E ABILITATE')
    print('=' * 120)
    for i, src in enumerate(sources, 1):
        ident = src.chat_id if src.mode == 'chat' else f'{src.team_id} / {src.channel_id}'
        print(f'{i:>2}. {src.source_name}\n    mode={src.mode}  id={ident}\n    signature={src.signature}\n    out={source_dir(cfg, src)}')


def main() -> int:
    ap = argparse.ArgumentParser(description='Orchestratore multi-chat/multi-source Teams Graph')
    ap.add_argument('--config', default='config/config.ini')
    ap.add_argument('--sources-file', default='')
    action = ap.add_mutually_exclusive_group(required=True)
    action.add_argument('--download', action='store_true')
    action.add_argument('--commit-watermarks', action='store_true')
    action.add_argument('--list', action='store_true')
    ap.add_argument('--restart', action='store_true')
    ap.add_argument('--reset-watermarks', action='store_true')
    args = ap.parse_args()
    cfg = load_config(args.config)
    sources = load_sources(cfg, args.sources_file)
    if args.list:
        print_sources(cfg, sources)
        return 0
    if args.download:
        return download_all(args.config, cfg, sources, args.restart, args.reset_watermarks)
    return commit_all(args.config, cfg, sources)


if __name__ == '__main__':
    raise SystemExit(main())

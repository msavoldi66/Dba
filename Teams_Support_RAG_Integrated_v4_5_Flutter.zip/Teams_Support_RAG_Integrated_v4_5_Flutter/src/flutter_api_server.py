from __future__ import annotations

import argparse
import asyncio
import importlib.util
import json
import os
import sqlite3
import subprocess
import sys
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import uvicorn

from common import connect_db, load_config, resolve_path

ROOT = Path(__file__).resolve().parents[1]
CONFIG_PATH = ROOT / "config" / "config.ini"
APP_VERSION = "v4.5-flutter-windows-2026-08-27"

app = FastAPI(title="Support DB2 Teams RAG API", version=APP_VERSION)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1", "http://localhost", "*"],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

_pipeline_lock = threading.Lock()
_pipeline_process: Optional[subprocess.Popen] = None
_pipeline_log_handle = None
_pipeline_log_path = ROOT / "logs" / "flutter_pipeline.log"
_rag_module = None


def cfg():
    return load_config(CONFIG_PATH)


def con() -> sqlite3.Connection:
    return connect_db(cfg()["paths"]["sqlite_db"])


def row_dict(row: Any) -> Dict[str, Any]:
    return dict(row) if row is not None else {}


def rows_dict(rows: Any) -> List[Dict[str, Any]]:
    return [dict(r) for r in rows]


def load_rag_module():
    global _rag_module
    if _rag_module is not None:
        return _rag_module
    path = ROOT / "src" / "08_rag_query_engine.py"
    spec = importlib.util.spec_from_file_location("rag_engine_flutter_api", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("Impossibile caricare il motore RAG")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    _rag_module = mod
    return mod


def latest_analysis_join() -> str:
    return """
    LEFT JOIN llm_message_analysis a
      ON a.id = (SELECT MAX(a2.id) FROM llm_message_analysis a2 WHERE a2.message_id=m.message_id)
    """


def qdrant_status() -> Dict[str, Any]:
    c = cfg()
    enabled = c.getboolean("qdrant", "enabled", fallback=True)
    if not enabled:
        return {"enabled": False, "ok": False, "message": "Qdrant disabilitato"}
    url = c.get("qdrant", "url", fallback="http://127.0.0.1:6333").rstrip("/")
    collection = c.get("qdrant", "collection", fallback="")
    try:
        r = requests.get(f"{url}/collections/{collection}", timeout=3)
        return {
            "enabled": True,
            "ok": r.status_code < 400,
            "http_status": r.status_code,
            "url": url,
            "collection": collection,
        }
    except Exception as exc:
        return {"enabled": True, "ok": False, "url": url, "collection": collection, "message": str(exc)}


def tail_file(path: Path, max_lines: int = 180) -> str:
    if not path.exists():
        return ""
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        return "\n".join(lines[-max_lines:])
    except Exception:
        return ""


class RagRequest(BaseModel):
    question: str = Field(min_length=1, max_length=12000)
    top_k: int = Field(default=8, ge=1, le=50)
    threshold: float = Field(default=0.20, ge=0.0, le=1.0)


class PipelineRequest(BaseModel):
    no_download: bool = False
    restart_download: bool = False
    reset_watermark: bool = False
    no_llm: bool = False
    no_qdrant: bool = False
    recreate_qdrant: bool = False


@app.get("/api/health")
def health():
    try:
        c = con()
        c.execute("SELECT 1").fetchone()
        c.close()
        db_ok = True
    except Exception:
        db_ok = False
    return {"ok": True, "version": APP_VERSION, "db_ok": db_ok}


@app.get("/api/dashboard")
def dashboard():
    c = con()
    counts = {
        "messages": c.execute("SELECT COUNT(*) c FROM messages").fetchone()["c"],
        "events": c.execute("SELECT COUNT(*) c FROM conversation_events").fetchone()["c"],
        "chunks": c.execute("SELECT COUNT(*) c FROM rag_chunks").fetchone()["c"],
        "llm_analyses": c.execute("SELECT COUNT(*) c FROM llm_message_analysis").fetchone()["c"],
        "entities": c.execute("SELECT COUNT(*) c FROM message_entities").fetchone()["c"],
        "pending_embeddings": c.execute("SELECT COUNT(*) c FROM rag_chunks WHERE COALESCE(embedded,0)=0").fetchone()["c"],
        "embedded_chunks": c.execute("SELECT COUNT(*) c FROM rag_chunks WHERE COALESCE(embedded,0)=1").fetchone()["c"],
    }
    try:
        counts["fts_records"] = c.execute("SELECT COUNT(*) c FROM messages_fts").fetchone()["c"]
    except Exception:
        counts["fts_records"] = 0

    sources = rows_dict(c.execute(
        """SELECT COALESCE(NULLIF(source_name,''), source_signature, 'legacy') source_name, COUNT(*) count
             FROM messages GROUP BY 1 ORDER BY count DESC"""
    ).fetchall())
    authors = rows_dict(c.execute(
        """SELECT COALESCE(NULLIF(author,''),'(sconosciuto)') author, COUNT(*) count
             FROM messages GROUP BY 1 ORDER BY count DESC LIMIT 10"""
    ).fetchall())
    score_buckets = rows_dict(c.execute(
        """SELECT CASE
                 WHEN operational_score >= 80 THEN '80-100'
                 WHEN operational_score >= 60 THEN '60-79'
                 WHEN operational_score >= 40 THEN '40-59'
                 WHEN operational_score >= 20 THEN '20-39'
                 ELSE '0-19' END bucket,
                 COUNT(*) count
             FROM messages GROUP BY 1
             ORDER BY CASE bucket WHEN '80-100' THEN 1 WHEN '60-79' THEN 2 WHEN '40-59' THEN 3 WHEN '20-39' THEN 4 ELSE 5 END"""
    ).fetchall())
    recent_messages = rows_dict(c.execute(
        """SELECT m.message_id,m.source_name,m.created_ts,m.author,m.text,m.reply_to_author,m.reply_to_text,
                  m.reaction_summary,m.operational_score,a.category,a.short_summary,a.urgency,a.status
             FROM messages m
             LEFT JOIN llm_message_analysis a
               ON a.id=(SELECT MAX(a2.id) FROM llm_message_analysis a2 WHERE a2.message_id=m.message_id)
             ORDER BY COALESCE(NULLIF(m.created_ts_utc,''),m.created_ts) DESC LIMIT 12"""
    ).fetchall())
    recent_events = rows_dict(c.execute(
        """SELECT event_id,source_name,event_type,title,start_ts,end_ts,summary,status,participants,main_entity
             FROM conversation_events
             ORDER BY COALESCE(NULLIF(start_ts_utc,''),start_ts) DESC LIMIT 10"""
    ).fetchall())
    run_log = rows_dict(c.execute(
        "SELECT id,step_name,status,details,created_at FROM run_log ORDER BY id DESC LIMIT 12"
    ).fetchall())
    c.close()
    return {
        "counts": counts,
        "sources": sources,
        "authors": authors,
        "score_buckets": score_buckets,
        "recent_messages": recent_messages,
        "recent_events": recent_events,
        "run_log": run_log,
        "qdrant": qdrant_status(),
    }


@app.get("/api/sources")
def sources():
    c = con()
    rows = rows_dict(c.execute(
        """SELECT s.source_signature,s.source_name,s.mode,s.chat_id,s.team_id,s.channel_id,s.enabled,
                  s.configured_from_datetime,s.overlap_hours,s.updated_at,
                  (SELECT COUNT(*) FROM messages m WHERE m.source_signature=s.source_signature) message_count
             FROM teams_sources s ORDER BY s.enabled DESC,s.source_name"""
    ).fetchall())
    c.close()
    return {"items": rows}


@app.get("/api/messages")
def messages(
    q: str = "",
    source: str = "",
    author: str = "",
    date_from: str = "",
    date_to: str = "",
    min_score: int = Query(default=0, ge=0, le=100),
    only_operational: bool = False,
    limit: int = Query(default=100, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
):
    clauses = ["1=1"]
    params: List[Any] = []
    if q.strip():
        like = f"%{q.strip()}%"
        clauses.append("""(
            m.text LIKE ? OR m.author LIKE ? OR m.reply_to_text LIKE ? OR m.raw_block LIKE ?
            OR m.mention_summary LIKE ? OR m.reaction_summary LIKE ?
            OR EXISTS(SELECT 1 FROM message_entities e WHERE e.message_id=m.message_id AND e.entity_value LIKE ?)
        )""")
        params.extend([like] * 7)
    if source:
        clauses.append("COALESCE(m.source_name,'') = ?")
        params.append(source)
    if author:
        clauses.append("COALESCE(m.author,'') LIKE ?")
        params.append(f"%{author}%")
    if date_from:
        clauses.append("m.created_date >= ?")
        params.append(date_from)
    if date_to:
        clauses.append("m.created_date <= ?")
        params.append(date_to)
    if min_score:
        clauses.append("COALESCE(m.operational_score,0) >= ?")
        params.append(min_score)
    if only_operational:
        clauses.append("COALESCE(m.operational_score,0) >= 40")

    where = " AND ".join(clauses)
    c = con()
    total = c.execute(f"SELECT COUNT(*) c FROM messages m WHERE {where}", params).fetchone()["c"]
    sql = f"""
        SELECT m.message_id,m.source_name,m.source_signature,m.created_ts,m.created_date,m.created_time,
               m.author,m.text,m.reply_to_author,m.reply_to_text,m.reaction_summary,m.mention_summary,
               m.operational_score,m.is_reply,m.importance,m.message_type,
               a.category,a.subcategory,a.short_summary,a.urgency,a.status,a.requires_followup
        FROM messages m
        {latest_analysis_join()}
        WHERE {where}
        ORDER BY COALESCE(NULLIF(m.created_ts_utc,''),m.created_ts) DESC,m.seq DESC
        LIMIT ? OFFSET ?
    """
    items = rows_dict(c.execute(sql, [*params, limit, offset]).fetchall())
    c.close()
    return {"total": total, "limit": limit, "offset": offset, "items": items}


@app.get("/api/messages/{message_id}")
def message_detail(message_id: str):
    c = con()
    row = c.execute("SELECT * FROM messages WHERE message_id=?", (message_id,)).fetchone()
    if not row:
        c.close()
        raise HTTPException(status_code=404, detail="Messaggio non trovato")
    message = row_dict(row)
    entities = rows_dict(c.execute(
        "SELECT entity_type,entity_value,confidence,extraction_method FROM message_entities WHERE message_id=? ORDER BY entity_type,entity_value",
        (message_id,),
    ).fetchall())
    analyses = rows_dict(c.execute(
        "SELECT * FROM llm_message_analysis WHERE message_id=? ORDER BY id DESC", (message_id,)
    ).fetchall())
    reactions = rows_dict(c.execute(
        "SELECT reaction_type,reaction_user,reaction_created_ts,reaction_count FROM message_reactions WHERE message_id=?",
        (message_id,),
    ).fetchall())
    mentions = rows_dict(c.execute(
        "SELECT mention_text,mentioned_user FROM message_mentions WHERE message_id=?", (message_id,)
    ).fetchall())
    ctx = c.execute("SELECT * FROM message_contexts WHERE message_id=?", (message_id,)).fetchone()
    context_messages: List[Dict[str, Any]] = []
    if ctx:
        ids: List[str] = []
        for key in ("previous_ids", "next_ids", "reply_children_ids", "same_entity_ids"):
            try:
                vals = json.loads(ctx[key] or "[]")
                if isinstance(vals, list):
                    ids.extend(str(x) for x in vals)
            except Exception:
                pass
        for extra in [ctx["reply_parent_id"], message_id]:
            if extra:
                ids.append(str(extra))
        seen = set()
        ids = [x for x in ids if not (x in seen or seen.add(x))]
        if ids:
            ph = ",".join("?" for _ in ids)
            context_messages = rows_dict(c.execute(
                f"SELECT message_id,source_name,created_ts,author,text,operational_score FROM messages WHERE message_id IN ({ph}) ORDER BY COALESCE(NULLIF(created_ts_utc,''),created_ts),seq",
                ids,
            ).fetchall())
    events = rows_dict(c.execute(
        """SELECT e.event_id,e.event_type,e.title,e.start_ts,e.end_ts,e.summary,e.status
             FROM event_messages em JOIN conversation_events e ON e.event_id=em.event_id
             WHERE em.message_id=? ORDER BY e.start_ts DESC""",
        (message_id,),
    ).fetchall())
    c.close()
    return {
        "message": message,
        "entities": entities,
        "analyses": analyses,
        "reactions": reactions,
        "mentions": mentions,
        "context": row_dict(ctx),
        "context_messages": context_messages,
        "events": events,
    }


@app.get("/api/events")
def events(
    q: str = "",
    source: str = "",
    event_type: str = "",
    limit: int = Query(default=100, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
):
    clauses = ["1=1"]
    params: List[Any] = []
    if q:
        like = f"%{q}%"
        clauses.append("(title LIKE ? OR summary LIKE ? OR entities LIKE ? OR participants LIKE ? OR main_entity LIKE ?)")
        params.extend([like] * 5)
    if source:
        clauses.append("COALESCE(source_name,'')=?")
        params.append(source)
    if event_type:
        clauses.append("COALESCE(event_type,'')=?")
        params.append(event_type)
    where = " AND ".join(clauses)
    c = con()
    total = c.execute(f"SELECT COUNT(*) c FROM conversation_events WHERE {where}", params).fetchone()["c"]
    items = rows_dict(c.execute(
        f"""SELECT event_id,source_name,event_type,title,start_ts,end_ts,main_entity,summary,status,participants,entities
             FROM conversation_events WHERE {where}
             ORDER BY COALESCE(NULLIF(start_ts_utc,''),start_ts) DESC LIMIT ? OFFSET ?""",
        [*params, limit, offset],
    ).fetchall())
    c.close()
    return {"total": total, "items": items, "limit": limit, "offset": offset}


@app.get("/api/events/{event_id}")
def event_detail(event_id: str):
    c = con()
    event = c.execute("SELECT * FROM conversation_events WHERE event_id=?", (event_id,)).fetchone()
    if not event:
        c.close()
        raise HTTPException(status_code=404, detail="Evento non trovato")
    msgs = rows_dict(c.execute(
        """SELECT m.message_id,m.source_name,m.created_ts,m.author,m.text,m.operational_score,em.role
             FROM event_messages em JOIN messages m ON m.message_id=em.message_id
             WHERE em.event_id=? ORDER BY COALESCE(NULLIF(m.created_ts_utc,''),m.created_ts),m.seq""",
        (event_id,),
    ).fetchall())
    c.close()
    return {"event": row_dict(event), "messages": msgs}


@app.get("/api/entities")
def entities(q: str = "", entity_type: str = "", limit: int = Query(default=200, ge=1, le=1000)):
    clauses = ["1=1"]
    params: List[Any] = []
    if q:
        clauses.append("entity_value LIKE ?")
        params.append(f"%{q}%")
    if entity_type:
        clauses.append("entity_type=?")
        params.append(entity_type)
    where = " AND ".join(clauses)
    c = con()
    items = rows_dict(c.execute(
        f"""SELECT entity_type,entity_value,COUNT(*) count,COUNT(DISTINCT message_id) message_count
             FROM message_entities WHERE {where}
             GROUP BY entity_type,entity_value ORDER BY message_count DESC,entity_value LIMIT ?""",
        [*params, limit],
    ).fetchall())
    types = rows_dict(c.execute("SELECT entity_type,COUNT(*) count FROM message_entities GROUP BY entity_type ORDER BY count DESC").fetchall())
    c.close()
    return {"items": items, "types": types}


@app.get("/api/history")
def history(limit: int = Query(default=100, ge=1, le=500)):
    c = con()
    items = rows_dict(c.execute(
        "SELECT qa_id,created_at,question,answer,retrieved_entities,model,elapsed_ms FROM qa_history ORDER BY qa_id DESC LIMIT ?",
        (limit,),
    ).fetchall())
    c.close()
    return {"items": items}


@app.post("/api/rag/ask")
async def rag_ask(req: RagRequest):
    try:
        rag = load_rag_module()
        result = await asyncio.to_thread(
            rag.ask_detailed,
            req.question,
            str(CONFIG_PATH),
            req.top_k,
            req.threshold,
        )
        return result
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.get("/api/system/status")
def system_status():
    c = con()
    db_path = resolve_path(cfg()["paths"]["sqlite_db"])
    db_size = db_path.stat().st_size if db_path.exists() else 0
    token_file = resolve_path(cfg().get("graph", "token_file", fallback="graph_access_token.txt"))
    env_key = cfg().get("llm", "api_key_env", fallback="DEEPINFRA_API_KEY")
    source_rows = rows_dict(c.execute(
        "SELECT source_name,mode,enabled,chat_id,team_id,channel_id,overlap_hours,updated_at FROM teams_sources ORDER BY source_name"
    ).fetchall())
    c.close()
    watermark_file = resolve_path(cfg().get("teams", "watermark_file", fallback="state/teams_watermark.json"))
    watermark = {}
    if watermark_file.exists():
        try:
            watermark = json.loads(watermark_file.read_text(encoding="utf-8"))
        except Exception:
            watermark = {"error": "watermark non leggibile"}
    return {
        "version": APP_VERSION,
        "project_root": str(ROOT),
        "database": str(db_path),
        "database_size_bytes": db_size,
        "timezone": cfg().get("time", "local_timezone", fallback="Europe/Rome"),
        "graph_token_present": token_file.exists() and token_file.stat().st_size > 0,
        "llm_api_key_present": bool(os.environ.get(env_key, "")),
        "qdrant": qdrant_status(),
        "sources": source_rows,
        "watermark": watermark,
    }


@app.post("/api/pipeline/start")
def pipeline_start(req: PipelineRequest):
    global _pipeline_process, _pipeline_log_handle
    with _pipeline_lock:
        if _pipeline_process is not None and _pipeline_process.poll() is None:
            raise HTTPException(status_code=409, detail="Pipeline già in esecuzione")
        _pipeline_log_path.parent.mkdir(parents=True, exist_ok=True)
        _pipeline_log_handle = _pipeline_log_path.open("w", encoding="utf-8", errors="replace")
        args = [sys.executable, "src/run_pipeline.py", "--config", "config/config.ini", "--no-streamlit"]
        if req.no_download:
            args.append("--no-download")
        if req.restart_download:
            args.append("--restart-download")
        if req.reset_watermark:
            args.append("--reset-watermark")
        if req.no_llm:
            args.append("--no-llm")
        if req.no_qdrant:
            args.append("--no-qdrant")
        if req.recreate_qdrant:
            args.append("--recreate-qdrant")
        kwargs: Dict[str, Any] = {
            "cwd": str(ROOT),
            "stdout": _pipeline_log_handle,
            "stderr": subprocess.STDOUT,
            "text": True,
        }
        if os.name == "nt":
            kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
        _pipeline_process = subprocess.Popen(args, **kwargs)
        return {"started": True, "pid": _pipeline_process.pid, "log_file": str(_pipeline_log_path)}


@app.get("/api/pipeline/status")
def pipeline_status():
    global _pipeline_process, _pipeline_log_handle
    with _pipeline_lock:
        running = _pipeline_process is not None and _pipeline_process.poll() is None
        exit_code = None if _pipeline_process is None or running else _pipeline_process.returncode
        pid = _pipeline_process.pid if _pipeline_process is not None else None
        if not running and _pipeline_log_handle is not None:
            try:
                _pipeline_log_handle.flush()
                _pipeline_log_handle.close()
            except Exception:
                pass
            _pipeline_log_handle = None
        return {
            "running": running,
            "pid": pid,
            "exit_code": exit_code,
            "log_file": str(_pipeline_log_path),
            "log_tail": tail_file(_pipeline_log_path),
        }


@app.post("/api/pipeline/stop")
def pipeline_stop():
    global _pipeline_process
    with _pipeline_lock:
        if _pipeline_process is None or _pipeline_process.poll() is not None:
            return {"stopped": False, "message": "Pipeline non in esecuzione"}
        try:
            _pipeline_process.terminate()
            return {"stopped": True, "pid": _pipeline_process.pid}
        except Exception as exc:
            raise HTTPException(status_code=500, detail=str(exc)) from exc


def main() -> int:
    ap = argparse.ArgumentParser(description="API locale per GUI Flutter Windows")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8765)
    args = ap.parse_args()
    uvicorn.run(app, host=args.host, port=args.port, log_level="info", access_log=False)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import re

from common import load_config, connect_db, stable_id, json_dumps


def parse_iso(ts):
    if not ts: return None
    try: return dt.datetime.fromisoformat(ts.replace('Z','+00:00'))
    except Exception: return None


def fmt_row(r):
    reply = ''
    if r['reply_to_author'] or r['reply_to_text']:
        reply = f"\n  ↪ In risposta a {r['reply_to_author'] or ''}: {r['reply_to_text'] or ''}"
    return f"[{r['created_ts']}] {r['author']}:{reply}\n{r['text'] or '[vuoto]'}"


def semantic_text_for_embedding(text: str) -> str:
    # I timestamp visualizzati non devono invalidare il vettore semantico.
    # Rimuove solo il timestamp iniziale delle righe messaggio, lasciando autore/testo invariati.
    return re.sub(r'(?m)^\[[^\]\n]+\]\s*', '', text or '')


def get_entities(con, ids):
    if not ids: return []
    qs = ','.join('?' for _ in ids)
    rows = con.execute(f'SELECT DISTINCT entity_type,entity_value FROM message_entities WHERE message_id IN ({qs})', ids).fetchall()
    return [{'type':r['entity_type'],'value':r['entity_value']} for r in rows]


def insert_chunk(con, chunk_type, rows, title=''):
    if not rows: return
    ids = [r['message_id'] for r in rows]
    text = '\n\n'.join(([title] if title else []) + [fmt_row(r) for r in rows])
    ents = get_entities(con, ids); participants = sorted({r['author'] for r in rows if r['author']})
    cid = stable_id(chunk_type, ids[0], ids[-1], title, prefix='chk_')
    h = hashlib.sha256(text.encode('utf-8')).hexdigest()
    old = con.execute('SELECT content_hash, embedded, qdrant_point_id, text FROM rag_chunks WHERE chunk_id=?', (cid,)).fetchone()
    same_semantic = bool(old and semantic_text_for_embedding(old['text'] or '') == semantic_text_for_embedding(text))
    embedded = int(old['embedded']) if old and (old['content_hash'] == h or same_semantic) else 0
    qid = old['qdrant_point_id'] if embedded and old else None
    con.execute('''INSERT INTO rag_chunks(chunk_id,chunk_type,start_ts,end_ts,start_ts_utc,end_ts_utc,text,content_hash,entities,participants,source_message_ids,qdrant_point_id,embedded)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(chunk_id) DO UPDATE SET
                   chunk_type=excluded.chunk_type,start_ts=excluded.start_ts,end_ts=excluded.end_ts,
                   start_ts_utc=excluded.start_ts_utc,end_ts_utc=excluded.end_ts_utc,text=excluded.text,
                   content_hash=excluded.content_hash,entities=excluded.entities,participants=excluded.participants,
                   source_message_ids=excluded.source_message_ids,qdrant_point_id=excluded.qdrant_point_id,embedded=excluded.embedded''',
                (cid, chunk_type, rows[0]['created_ts'], rows[-1]['created_ts'], rows[0]['created_ts_utc'] or rows[0]['created_ts'],
                 rows[-1]['created_ts_utc'] or rows[-1]['created_ts'], text, h, json_dumps(ents), json_dumps(participants), json_dumps(ids), qid, embedded))


def main() -> int:
    ap = argparse.ArgumentParser(); ap.add_argument('--config', default='config/config.ini'); ap.add_argument('--reset', action='store_true')
    args = ap.parse_args(); cfg = load_config(args.config); con = connect_db(cfg['paths']['sqlite_db'])
    # Elimina soltanto chunk non più ricostruiti alla fine usando una tabella temporanea di ID.
    con.execute('CREATE TEMP TABLE IF NOT EXISTS _new_chunks(id TEXT PRIMARY KEY)'); con.execute('DELETE FROM _new_chunks')
    original_insert = insert_chunk
    def tracked(ct, rows, title=''):
        if not rows: return
        ids=[r['message_id'] for r in rows]; cid=stable_id(ct,ids[0],ids[-1],title,prefix='chk_')
        original_insert(con,ct,rows,title); con.execute('INSERT OR IGNORE INTO _new_chunks(id) VALUES (?)',(cid,))

    rows = con.execute("SELECT * FROM messages ORDER BY source_signature, COALESCE(NULLIF(created_ts_utc,''), created_ts), seq").fetchall(); minutes = cfg.getint('rag','chunk_window_minutes',fallback=15)
    current=[]; window_start=None; current_sig=None; current_name=''
    for r in rows:
        t=parse_iso(r['created_ts_utc'] or r['created_ts'])
        if t is None: continue
        sig=r['source_signature'] or 'legacy'
        if current and sig != current_sig:
            tracked('TIME_WINDOW',current,f'Sorgente: {current_name or current_sig} | Finestra temporale {minutes} minuti')
            current=[]; window_start=None
        if window_start is None:
            window_start=t; current_sig=sig; current_name=r['source_name'] or ''
        if current and (t-window_start).total_seconds()>minutes*60:
            tracked('TIME_WINDOW',current,f'Sorgente: {current_name or current_sig} | Finestra temporale {minutes} minuti'); current=[]; window_start=t
        current.append(r)
    tracked('TIME_WINDOW',current,f'Sorgente: {current_name or current_sig} | Finestra temporale {minutes} minuti')
    for ev in con.execute('SELECT event_id,title,source_name,source_signature FROM conversation_events ORDER BY start_ts').fetchall():
        erows=con.execute('''SELECT m.* FROM event_messages em JOIN messages m ON m.message_id=em.message_id
                             WHERE em.event_id=? ORDER BY COALESCE(NULLIF(m.created_ts_utc,''), m.created_ts),m.seq''',(ev['event_id'],)).fetchall()
        tracked('ENTITY_BASED',erows,f"Sorgente: {ev['source_name'] or ev['source_signature'] or 'legacy'} | {ev['title']}")
    for p in con.execute('SELECT DISTINCT reply_to_message_id FROM messages WHERE reply_to_message_id IS NOT NULL').fetchall():
        ids=[p['reply_to_message_id']]+[x['message_id'] for x in con.execute("SELECT message_id FROM messages WHERE reply_to_message_id=? ORDER BY COALESCE(NULLIF(created_ts_utc,''), created_ts)",(p['reply_to_message_id'],)).fetchall()]
        qs=','.join('?' for _ in ids); erows=con.execute(f"SELECT * FROM messages WHERE message_id IN ({qs}) ORDER BY COALESCE(NULLIF(created_ts_utc,''), created_ts),seq",ids).fetchall()
        tracked('REPLY_CHAIN',erows,'Catena di risposta')
    con.execute('DELETE FROM rag_chunks WHERE chunk_id NOT IN (SELECT id FROM _new_chunks)')
    con.commit(); n=con.execute('SELECT COUNT(*) c FROM rag_chunks').fetchone()['c']; dirty=con.execute('SELECT COUNT(*) c FROM rag_chunks WHERE embedded=0').fetchone()['c']
    print(f'Chunk RAG disponibili: {n}; da embeddare/aggiornare: {dirty}'); return 0


if __name__ == '__main__': raise SystemExit(main())

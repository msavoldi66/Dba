from __future__ import annotations

import argparse
import sqlite3
from common import load_config, connect_db, resolve_path, normalize_iso_utc, iso_utc_to_local, get_local_timezone, ts_date, ts_time

SCHEMA = r'''
CREATE TABLE IF NOT EXISTS messages (
    message_id TEXT PRIMARY KEY,
    seq INTEGER,
    source_file TEXT,
    source_mode TEXT,
    source_name TEXT,
    source_signature TEXT,
    graph_message_id TEXT,
    graph_chat_id TEXT,
    graph_team_id TEXT,
    graph_channel_id TEXT,
    created_ts TEXT,
    created_ts_utc TEXT,
    last_modified_ts TEXT,
    last_modified_ts_utc TEXT,
    deleted_ts TEXT,
    deleted_ts_utc TEXT,
    created_date TEXT,
    created_time TEXT,
    author TEXT,
    text TEXT,
    raw_block TEXT,
    body_html TEXT,
    has_text INTEGER DEFAULT 1,
    is_reply INTEGER DEFAULT 0,
    reply_to_message_id TEXT,
    reply_to_graph_message_id TEXT,
    reply_to_ts TEXT,
    reply_to_ts_utc TEXT,
    reply_to_author TEXT,
    reply_to_text TEXT,
    reaction_summary TEXT,
    mention_summary TEXT,
    importance TEXT,
    message_type TEXT,
    subject TEXT,
    summary TEXT,
    etag TEXT,
    attachments_json TEXT,
    raw_json TEXT,
    operational_score INTEGER DEFAULT 0,
    imported_at TEXT DEFAULT CURRENT_TIMESTAMP,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS message_replies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id TEXT NOT NULL,
    reply_to_message_id TEXT,
    reply_to_graph_message_id TEXT,
    reply_to_author TEXT,
    reply_to_ts TEXT,
    reply_to_ts_utc TEXT,
    reply_to_text TEXT,
    source TEXT,
    UNIQUE(message_id),
    FOREIGN KEY(message_id) REFERENCES messages(message_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS message_reactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id TEXT NOT NULL,
    reaction_type TEXT,
    reaction_user TEXT,
    reaction_created_ts TEXT,
    reaction_created_ts_utc TEXT,
    reaction_count INTEGER DEFAULT 1,
    reaction_raw TEXT,
    FOREIGN KEY(message_id) REFERENCES messages(message_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS message_mentions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id TEXT NOT NULL,
    mention_text TEXT,
    mentioned_user TEXT,
    mention_raw TEXT,
    FOREIGN KEY(message_id) REFERENCES messages(message_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS message_entities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_value TEXT NOT NULL,
    confidence REAL DEFAULT 1.0,
    extraction_method TEXT,
    FOREIGN KEY(message_id) REFERENCES messages(message_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS message_contexts (
    message_id TEXT PRIMARY KEY,
    context_text TEXT,
    previous_ids TEXT,
    next_ids TEXT,
    reply_parent_id TEXT,
    reply_children_ids TEXT,
    same_entity_ids TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(message_id) REFERENCES messages(message_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS llm_message_analysis (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id TEXT NOT NULL,
    is_operational INTEGER,
    category TEXT,
    subcategory TEXT,
    short_summary TEXT,
    operational_summary TEXT,
    problem_detected TEXT,
    proposed_action TEXT,
    decision_taken TEXT,
    urgency TEXT,
    status TEXT,
    sentiment TEXT,
    requires_followup INTEGER,
    people_involved TEXT,
    systems_involved TEXT,
    keywords TEXT,
    llm_model TEXT,
    llm_raw_json TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(message_id) REFERENCES messages(message_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS conversation_events (
    event_id TEXT PRIMARY KEY,
    event_type TEXT,
    source_signature TEXT,
    source_name TEXT,
    title TEXT,
    start_ts TEXT,
    end_ts TEXT,
    start_ts_utc TEXT,
    end_ts_utc TEXT,
    main_entity TEXT,
    summary TEXT,
    status TEXT,
    participants TEXT,
    entities TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS event_messages (
    event_id TEXT NOT NULL,
    message_id TEXT NOT NULL,
    role TEXT,
    PRIMARY KEY(event_id, message_id),
    FOREIGN KEY(event_id) REFERENCES conversation_events(event_id) ON DELETE CASCADE,
    FOREIGN KEY(message_id) REFERENCES messages(message_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS rag_chunks (
    chunk_id TEXT PRIMARY KEY,
    chunk_type TEXT,
    start_ts TEXT,
    end_ts TEXT,
    start_ts_utc TEXT,
    end_ts_utc TEXT,
    text TEXT,
    content_hash TEXT,
    entities TEXT,
    participants TEXT,
    source_message_ids TEXT,
    qdrant_point_id TEXT,
    embedded INTEGER DEFAULT 0,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS qa_history (
    qa_id INTEGER PRIMARY KEY AUTOINCREMENT,
    question TEXT NOT NULL,
    answer TEXT,
    retrieved_chunks TEXT,
    retrieved_entities TEXT,
    model TEXT,
    elapsed_ms INTEGER,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS keyword_rules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    keyword TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    description TEXT,
    enabled INTEGER DEFAULT 1
);


CREATE TABLE IF NOT EXISTS teams_sources (
    source_signature TEXT PRIMARY KEY,
    source_name TEXT NOT NULL,
    mode TEXT NOT NULL,
    chat_id TEXT,
    team_id TEXT,
    channel_id TEXT,
    enabled INTEGER DEFAULT 1,
    configured_from_datetime TEXT,
    overlap_hours REAL,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS run_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    step_name TEXT,
    status TEXT,
    details TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

'''

INDEX_SCHEMA = r'''
CREATE INDEX IF NOT EXISTS idx_messages_ts ON messages(created_ts);
CREATE INDEX IF NOT EXISTS idx_messages_ts_utc ON messages(created_ts_utc);
CREATE INDEX IF NOT EXISTS idx_messages_seq ON messages(seq);
CREATE INDEX IF NOT EXISTS idx_messages_author ON messages(author);
CREATE INDEX IF NOT EXISTS idx_messages_source_name ON messages(source_name);
CREATE INDEX IF NOT EXISTS idx_messages_score ON messages(operational_score);
CREATE INDEX IF NOT EXISTS idx_messages_graph ON messages(source_signature, graph_message_id);
CREATE INDEX IF NOT EXISTS idx_messages_modified ON messages(last_modified_ts);
CREATE INDEX IF NOT EXISTS idx_messages_modified_utc ON messages(last_modified_ts_utc);
CREATE INDEX IF NOT EXISTS idx_entities_value ON message_entities(entity_value);
CREATE INDEX IF NOT EXISTS idx_entities_type ON message_entities(entity_type);
CREATE INDEX IF NOT EXISTS idx_chunks_ts ON rag_chunks(start_ts, end_ts);
CREATE INDEX IF NOT EXISTS idx_teams_sources_name ON teams_sources(source_name);
'''


REQUIRED_MESSAGE_COLUMNS = {
    'source_mode': 'TEXT', 'source_name': 'TEXT', 'source_signature': 'TEXT', 'graph_message_id': 'TEXT',
    'graph_chat_id': 'TEXT', 'graph_team_id': 'TEXT', 'graph_channel_id': 'TEXT',
    'created_ts_utc': 'TEXT', 'last_modified_ts': 'TEXT', 'last_modified_ts_utc': 'TEXT',
    'deleted_ts': 'TEXT', 'deleted_ts_utc': 'TEXT', 'body_html': 'TEXT',
    'reply_to_graph_message_id': 'TEXT', 'reply_to_ts_utc': 'TEXT', 'importance': 'TEXT', 'message_type': 'TEXT',
    'subject': 'TEXT', 'summary': 'TEXT', 'etag': 'TEXT', 'attachments_json': 'TEXT',
    'raw_json': 'TEXT', 'imported_at': 'TEXT'
}

REQUIRED_CHUNK_COLUMNS = {'content_hash': 'TEXT', 'start_ts_utc': 'TEXT', 'end_ts_utc': 'TEXT'}
REQUIRED_EVENT_COLUMNS = {'source_signature': 'TEXT', 'source_name': 'TEXT', 'start_ts_utc': 'TEXT', 'end_ts_utc': 'TEXT'}
REQUIRED_REPLY_COLUMNS = {'reply_to_graph_message_id': 'TEXT', 'reply_to_ts_utc': 'TEXT'}
REQUIRED_REACTION_COLUMNS = {'reaction_user': 'TEXT', 'reaction_created_ts': 'TEXT', 'reaction_created_ts_utc': 'TEXT'}
REQUIRED_MENTION_COLUMNS = {'mention_raw': 'TEXT'}

DEFAULT_RULES = [
    ('Fideuram', 'TOPIC', 'Ambito Fideuram'),
    ('PARMUTIL', 'TOOL', 'Parametrizzazione utility/segnalazioni'),
    ('DB20CHST', 'PROGRAM', 'Programma interno'),
    ('DB20RIBA', 'PROGRAM', 'Programma interno RIBA'),
    ('abend', 'EVENT', 'Errore job'),
    ('incident', 'PROCESS', 'Gestione incident'),
    ('ptask', 'PROCESS', 'Problem task'),
    ('udc', 'PROCESS', 'Change/UDC'),
    ('Flash Copy', 'TOPIC', 'FlashCopy DB2'),
]


def ensure_columns(con: sqlite3.Connection, table: str, wanted: dict[str, str]) -> None:
    existing = {r['name'] for r in con.execute(f'PRAGMA table_info({table})').fetchall()}
    for name, sql_type in wanted.items():
        if name not in existing:
            con.execute(f'ALTER TABLE {table} ADD COLUMN {name} {sql_type}')


def migrate_message_times_to_local(con: sqlite3.Connection, timezone_name: str) -> int:
    """V4.4: conserva UTC originale e converte i campi visibili in Europe/Rome.

    La migrazione e' idempotente: vengono elaborate solo righe senza *_utc valorizzato.
    """
    changed = 0
    rows = con.execute('''SELECT message_id, created_ts, created_ts_utc, last_modified_ts, last_modified_ts_utc,
                               deleted_ts, deleted_ts_utc, reply_to_ts, reply_to_ts_utc
                        FROM messages''').fetchall()
    for r in rows:
        updates = {}
        for local_col, utc_col in (('created_ts','created_ts_utc'), ('last_modified_ts','last_modified_ts_utc'),
                                   ('deleted_ts','deleted_ts_utc'), ('reply_to_ts','reply_to_ts_utc')):
            if (r[utc_col] or '').strip() or not (r[local_col] or '').strip():
                continue
            utc = normalize_iso_utc(r[local_col])
            updates[utc_col] = utc
            updates[local_col] = iso_utc_to_local(utc, timezone_name)
        if updates:
            if 'created_ts' in updates:
                updates['created_date'] = ts_date(updates['created_ts'])
                updates['created_time'] = ts_time(updates['created_ts'])
            sql = 'UPDATE messages SET ' + ', '.join(f'{k}=?' for k in updates) + ' WHERE message_id=?'
            con.execute(sql, [*updates.values(), r['message_id']])
            changed += 1

    for r in con.execute('SELECT id, reply_to_ts, reply_to_ts_utc FROM message_replies').fetchall():
        if not (r['reply_to_ts_utc'] or '').strip() and (r['reply_to_ts'] or '').strip():
            utc = normalize_iso_utc(r['reply_to_ts'])
            con.execute('UPDATE message_replies SET reply_to_ts=?, reply_to_ts_utc=? WHERE id=?',
                        (iso_utc_to_local(utc, timezone_name), utc, r['id']))

    for r in con.execute('SELECT id, reaction_created_ts, reaction_created_ts_utc FROM message_reactions').fetchall():
        if not (r['reaction_created_ts_utc'] or '').strip() and (r['reaction_created_ts'] or '').strip():
            utc = normalize_iso_utc(r['reaction_created_ts'])
            con.execute('UPDATE message_reactions SET reaction_created_ts=?, reaction_created_ts_utc=? WHERE id=?',
                        (iso_utc_to_local(utc, timezone_name), utc, r['id']))

    # Eventi/chunk sono derivati e verranno comunque ricostruiti nella pipeline; li convertiamo
    # anche qui per rendere il DB coerente immediatamente dopo lo step 00.
    for table in ('conversation_events', 'rag_chunks'):
        pk = 'event_id' if table == 'conversation_events' else 'chunk_id'
        for r in con.execute(f'SELECT {pk}, start_ts, end_ts, start_ts_utc, end_ts_utc FROM {table}').fetchall():
            vals = {}
            for local_col, utc_col in (('start_ts','start_ts_utc'), ('end_ts','end_ts_utc')):
                if not (r[utc_col] or '').strip() and (r[local_col] or '').strip():
                    utc = normalize_iso_utc(r[local_col])
                    vals[utc_col] = utc
                    vals[local_col] = iso_utc_to_local(utc, timezone_name)
            if vals:
                con.execute('UPDATE ' + table + ' SET ' + ', '.join(f'{k}=?' for k in vals) + f' WHERE {pk}=?',
                            [*vals.values(), r[pk]])
    return changed


def rebuild_fts(con: sqlite3.Connection) -> None:
    con.executescript('''
    DROP TRIGGER IF EXISTS messages_ai;
    DROP TRIGGER IF EXISTS messages_ad;
    DROP TRIGGER IF EXISTS messages_au;
    DROP TABLE IF EXISTS messages_fts;
    CREATE VIRTUAL TABLE messages_fts USING fts5(
        message_id UNINDEXED,
        author,
        text,
        reply_to_text,
        tokenize='unicode61'
    );
    INSERT INTO messages_fts(message_id, author, text, reply_to_text)
      SELECT message_id, COALESCE(author,''), COALESCE(text,''), COALESCE(reply_to_text,'') FROM messages;
    CREATE TRIGGER messages_ai AFTER INSERT ON messages BEGIN
      INSERT INTO messages_fts(message_id, author, text, reply_to_text)
      VALUES (new.message_id, COALESCE(new.author,''), COALESCE(new.text,''), COALESCE(new.reply_to_text,''));
    END;
    CREATE TRIGGER messages_ad AFTER DELETE ON messages BEGIN
      DELETE FROM messages_fts WHERE message_id = old.message_id;
    END;
    CREATE TRIGGER messages_au AFTER UPDATE OF author, text, reply_to_text ON messages BEGIN
      DELETE FROM messages_fts WHERE message_id = old.message_id;
      INSERT INTO messages_fts(message_id, author, text, reply_to_text)
      VALUES (new.message_id, COALESCE(new.author,''), COALESCE(new.text,''), COALESCE(new.reply_to_text,''));
    END;
    ''')


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', default='config/config.ini')
    args = ap.parse_args()
    cfg = load_config(args.config)
    db = cfg['paths']['sqlite_db']
    con = connect_db(db)
    previous_version = con.execute('PRAGMA user_version').fetchone()[0]
    # IMPORTANTE: su database provenienti dalle versioni precedenti, CREATE TABLE IF NOT EXISTS
    # non aggiunge le nuove colonne. Gli indici che dipendono dalle colonne Graph devono quindi
    # essere creati SOLO dopo la migrazione ALTER TABLE.
    con.executescript(SCHEMA)
    ensure_columns(con, 'messages', REQUIRED_MESSAGE_COLUMNS)
    ensure_columns(con, 'rag_chunks', REQUIRED_CHUNK_COLUMNS)
    ensure_columns(con, 'conversation_events', REQUIRED_EVENT_COLUMNS)
    ensure_columns(con, 'message_replies', REQUIRED_REPLY_COLUMNS)
    ensure_columns(con, 'message_reactions', REQUIRED_REACTION_COLUMNS)
    ensure_columns(con, 'message_mentions', REQUIRED_MENTION_COLUMNS)
    timezone_name = get_local_timezone(cfg)
    migrated = migrate_message_times_to_local(con, timezone_name) if previous_version < 4 else 0
    con.executescript(INDEX_SCHEMA)
    for kw, et, desc in DEFAULT_RULES:
        exists = con.execute('SELECT 1 FROM keyword_rules WHERE keyword=? AND entity_type=? LIMIT 1', (kw, et)).fetchone()
        if not exists:
            con.execute('INSERT INTO keyword_rules(keyword, entity_type, description) VALUES (?, ?, ?)', (kw, et, desc))
    rebuild_fts(con)
    con.execute('PRAGMA user_version=4')
    con.commit()
    print(f'Database inizializzato/migrato: {resolve_path(db)}')
    print(f'Timezone messaggi: {timezone_name}; righe migrate a ora locale: {migrated}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from common import (
    load_config, connect_db, resolve_path, stable_id, clean_text,
    normalize_iso_utc, iso_utc_to_local, get_local_timezone,
    ts_date, ts_time, json_dumps, now_utc,
)


def read_jsonl(path: Path) -> Iterable[Dict[str, Any]]:
    with path.open('r', encoding='utf-8') as f:
        for no, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                if isinstance(obj, dict):
                    yield obj
            except Exception as exc:
                print(f'[WARN] JSONL riga {no} ignorata: {exc}')


def composite_id(m: Dict[str, Any]) -> str:
    signature = m.get('source_signature') or _signature_from_fields(m)
    graph_id = str(m.get('id') or '')
    if not graph_id:
        return stable_id(signature, m.get('createdDateTime'), m.get('author'), m.get('text'), prefix='msg_')
    parent = str(m.get('replyToId') or '')
    if m.get('source_mode') == 'channel' and parent:
        return stable_id(signature, 'reply', parent, graph_id, prefix='msg_')
    return stable_id(signature, graph_id, prefix='msg_')


def _signature_from_fields(m: Dict[str, Any]) -> str:
    mode = m.get('source_mode') or 'chat'
    if mode == 'channel':
        return f"channel:{m.get('team_id','')}:{m.get('channel_id','')}"
    return f"chat:{m.get('chatId','')}"


def parent_id(m: Dict[str, Any]) -> Optional[str]:
    rid = str(m.get('replyToId') or '')
    if not rid:
        return None
    return stable_id(m.get('source_signature') or _signature_from_fields(m), rid, prefix='msg_')


def reaction_summary(reactions: List[Dict[str, Any]]) -> str:
    c = Counter()
    for r in reactions or []:
        rt = str(r.get('reactionType') or r.get('displayName') or 'reaction')
        c[rt] += 1
    return ', '.join(f'{k} x{v}' if v > 1 else k for k, v in sorted(c.items()))


def mention_summary(mentions: List[Dict[str, Any]]) -> str:
    vals = []
    for x in mentions or []:
        t = x.get('mentionText')
        if t:
            vals.append(str(t))
    return ', '.join(dict.fromkeys(vals))


def mentioned_user(x: Dict[str, Any]) -> str:
    mentioned = x.get('mentioned') or {}
    user = mentioned.get('user') or {}
    return str(user.get('displayName') or user.get('id') or x.get('mentionText') or '')


def reaction_user(r: Dict[str, Any]) -> str:
    user = ((r.get('user') or {}).get('user') or {})
    return str(user.get('displayName') or user.get('id') or '')


def _utc_and_local(value: Any, timezone_name: str) -> tuple[str, str]:
    utc = normalize_iso_utc(value)
    return utc, iso_utc_to_local(utc, timezone_name) if utc else ''


def upsert_message(con, m: Dict[str, Any], source_file: str, timezone_name: str) -> tuple[str, bool]:
    mid = composite_id(m)
    sig = m.get('source_signature') or _signature_from_fields(m)
    rc = m.get('reply_context') if isinstance(m.get('reply_context'), dict) else {}

    created_utc, created = _utc_and_local(m.get('createdDateTime'), timezone_name)
    modified_utc, modified = _utc_and_local(m.get('lastModifiedDateTime'), timezone_name)
    deleted_utc, deleted = _utc_and_local(m.get('deletedDateTime'), timezone_name)
    reply_utc, reply_ts = _utc_and_local(rc.get('createdDateTime'), timezone_name) if rc.get('createdDateTime') else ('', '')

    text = clean_text(str(m.get('text') or ''))
    reply_text = clean_text(str(rc.get('text') or ''))
    reply_author = str(rc.get('author') or '')
    reactions = m.get('reactions') or []
    mentions = m.get('mentions') or []
    raw = m.get('raw') or {}
    exists = con.execute('SELECT 1 FROM messages WHERE message_id=?', (mid,)).fetchone() is not None

    vals = (
        mid, source_file, m.get('source_mode'), str(m.get('source_name') or ''), sig, str(m.get('id') or ''), str(m.get('chatId') or ''),
        str(m.get('team_id') or ''), str(m.get('channel_id') or ''),
        created, created_utc, modified, modified_utc, deleted, deleted_utc,
        ts_date(created), ts_time(created), str(m.get('author') or 'Sconosciuto'), text,
        json_dumps(m), str(m.get('body_html') or ''), int(bool(text)), int(bool(m.get('is_reply') or m.get('replyToId') or rc)),
        parent_id(m), str(m.get('replyToId') or ''), reply_ts, reply_utc, reply_author, reply_text,
        reaction_summary(reactions), mention_summary(mentions), str(m.get('importance') or ''),
        str(m.get('messageType') or ''), str(m.get('subject') or ''), str(m.get('summary') or ''),
        str(m.get('etag') or ''), json_dumps(m.get('attachments') or []), json_dumps(raw), now_utc()
    )

    con.execute('''
    INSERT INTO messages(
      message_id, source_file, source_mode, source_name, source_signature, graph_message_id, graph_chat_id,
      graph_team_id, graph_channel_id, created_ts, created_ts_utc, last_modified_ts, last_modified_ts_utc,
      deleted_ts, deleted_ts_utc, created_date, created_time, author, text, raw_block, body_html, has_text,
      is_reply, reply_to_message_id, reply_to_graph_message_id, reply_to_ts, reply_to_ts_utc,
      reply_to_author, reply_to_text, reaction_summary, mention_summary, importance, message_type,
      subject, summary, etag, attachments_json, raw_json, imported_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(message_id) DO UPDATE SET
      source_file=excluded.source_file, source_mode=excluded.source_mode, source_name=excluded.source_name, source_signature=excluded.source_signature,
      graph_message_id=excluded.graph_message_id, graph_chat_id=excluded.graph_chat_id,
      graph_team_id=excluded.graph_team_id, graph_channel_id=excluded.graph_channel_id,
      created_ts=excluded.created_ts, created_ts_utc=excluded.created_ts_utc,
      last_modified_ts=excluded.last_modified_ts, last_modified_ts_utc=excluded.last_modified_ts_utc,
      deleted_ts=excluded.deleted_ts, deleted_ts_utc=excluded.deleted_ts_utc,
      created_date=excluded.created_date, created_time=excluded.created_time, author=excluded.author,
      text=excluded.text, raw_block=excluded.raw_block, body_html=excluded.body_html, has_text=excluded.has_text,
      is_reply=excluded.is_reply, reply_to_message_id=excluded.reply_to_message_id,
      reply_to_graph_message_id=excluded.reply_to_graph_message_id, reply_to_ts=excluded.reply_to_ts,
      reply_to_ts_utc=excluded.reply_to_ts_utc, reply_to_author=excluded.reply_to_author, reply_to_text=excluded.reply_to_text,
      reaction_summary=excluded.reaction_summary, mention_summary=excluded.mention_summary,
      importance=excluded.importance, message_type=excluded.message_type, subject=excluded.subject,
      summary=excluded.summary, etag=excluded.etag, attachments_json=excluded.attachments_json,
      raw_json=excluded.raw_json, imported_at=excluded.imported_at
    ''', vals)

    con.execute('DELETE FROM message_replies WHERE message_id=?', (mid,))
    if m.get('is_reply') or m.get('replyToId') or rc:
        con.execute('''INSERT INTO message_replies(message_id, reply_to_message_id, reply_to_graph_message_id,
                     reply_to_author, reply_to_ts, reply_to_ts_utc, reply_to_text, source) VALUES (?,?,?,?,?,?,?,?)''',
                    (mid, parent_id(m), str(m.get('replyToId') or ''), reply_author, reply_ts, reply_utc,
                     reply_text, str(rc.get('source') or 'replyToId')))

    con.execute('DELETE FROM message_reactions WHERE message_id=?', (mid,))
    for r in reactions:
        reaction_utc, reaction_local = _utc_and_local(r.get('createdDateTime'), timezone_name)
        con.execute('''INSERT INTO message_reactions(message_id,reaction_type,reaction_user,reaction_created_ts,
                       reaction_created_ts_utc,reaction_count,reaction_raw) VALUES (?,?,?,?,?,?,?)''',
                    (mid, str(r.get('reactionType') or r.get('displayName') or ''), reaction_user(r),
                     reaction_local, reaction_utc, 1, json_dumps(r)))

    con.execute('DELETE FROM message_mentions WHERE message_id=?', (mid,))
    for x in mentions:
        con.execute('INSERT INTO message_mentions(message_id,mention_text,mentioned_user,mention_raw) VALUES (?,?,?,?)',
                    (mid, str(x.get('mentionText') or ''), mentioned_user(x), json_dumps(x)))
    return mid, exists


def resequence(con) -> None:
    rows = con.execute('''SELECT message_id FROM messages
                          ORDER BY COALESCE(NULLIF(created_ts_utc,''), created_ts),
                                   source_signature, graph_message_id, message_id''').fetchall()
    con.executemany('UPDATE messages SET seq=? WHERE message_id=?', [(-(i + 100000000), r['message_id']) for i, r in enumerate(rows, 1)])
    con.executemany('UPDATE messages SET seq=? WHERE message_id=?', [(i, r['message_id']) for i, r in enumerate(rows, 1)])


def main() -> int:
    ap = argparse.ArgumentParser(description='Import strutturato Microsoft Graph JSONL -> SQLite')
    ap.add_argument('--config', default='config/config.ini')
    ap.add_argument('--input', default='')
    args = ap.parse_args()
    cfg = load_config(args.config)
    timezone_name = get_local_timezone(cfg)
    path = resolve_path(args.input or cfg.get('paths', 'teams_jsonl', fallback='data/teams_download/messages_final.jsonl'))
    if not path.exists():
        raise FileNotFoundError(f'JSONL Teams non trovato: {path}')
    con = connect_db(cfg['paths']['sqlite_db'])
    inserted = updated = 0
    con.execute('BEGIN')
    try:
        for m in read_jsonl(path):
            _, existed = upsert_message(con, m, str(path), timezone_name)
            if existed:
                updated += 1
            else:
                inserted += 1
        resequence(con)
        con.commit()
    except Exception:
        con.rollback()
        raise
    total = con.execute('SELECT COUNT(*) c FROM messages').fetchone()['c']
    print(f'Import Graph completato: nuovi={inserted}, aggiornati={updated}, totale_db={total}; timezone={timezone_name}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

from __future__ import annotations

import argparse
from pathlib import Path
from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from common import load_config, connect_db, resolve_path, json_loads_safe


def add_msg(doc, r):
    p = doc.add_paragraph()
    run = p.add_run(f"[{r['created_ts']}] {r['author']}")
    run.bold = True
    run.font.size = Pt(10)
    if r['reply_to_text']:
        q = doc.add_paragraph(style=None)
        q.paragraph_format.left_indent = Pt(18)
        qr = q.add_run(f"↪ In risposta a {r['reply_to_author'] or ''}: {r['reply_to_text']}")
        qr.italic = True
        qr.font.color.rgb = RGBColor(90, 90, 90)
        qr.font.size = Pt(9)
    body = doc.add_paragraph(r['text'] or '[messaggio vuoto/non testuale]')
    body.paragraph_format.left_indent = Pt(12)
    if r['reaction_summary']:
        rr = doc.add_paragraph()
        rr.paragraph_format.left_indent = Pt(12)
        x = rr.add_run(f"Reazioni: {r['reaction_summary']}")
        x.font.size = Pt(8)
        x.font.color.rgb = RGBColor(110, 110, 110)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', default='config/config.ini')
    ap.add_argument('--entity', help='Entità/evento, es. INC023114503 o PARMUTIL')
    ap.add_argument('--event-id')
    ap.add_argument('--output', default='exports/event_report.docx')
    args = ap.parse_args()
    cfg = load_config(args.config)
    con = connect_db(cfg['paths']['sqlite_db'])
    doc = Document()
    title = doc.add_heading('Report evento chat Support DB2', 0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    if args.event_id:
        ev = con.execute('SELECT * FROM conversation_events WHERE event_id=?', (args.event_id,)).fetchone()
    else:
        ev = con.execute('SELECT * FROM conversation_events WHERE UPPER(main_entity)=UPPER(?) OR UPPER(title) LIKE UPPER(?) ORDER BY start_ts LIMIT 1', (args.entity, f'%{args.entity}%')).fetchone()
    if not ev:
        raise SystemExit('Evento non trovato')
    doc.add_paragraph(f"Titolo: {ev['title']}")
    doc.add_paragraph(f"Periodo: {ev['start_ts']} - {ev['end_ts']}")
    doc.add_paragraph(f"Summary: {ev['summary']}")
    doc.add_heading('Messaggi collegati', level=1)
    rows = con.execute('''SELECT m.* FROM event_messages em JOIN messages m ON m.message_id=em.message_id
                          WHERE em.event_id=? ORDER BY COALESCE(NULLIF(m.created_ts_utc,''), m.created_ts), m.seq''', (ev['event_id'],)).fetchall()
    for r in rows:
        add_msg(doc, r)
    out = resolve_path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    doc.save(out)
    print(f'Creato: {out}')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())

from __future__ import annotations

import argparse
import re
from typing import Dict, List, Tuple

import yaml
from tqdm import tqdm
from common import load_config, connect_db, resolve_path, clean_text


def load_rules(path):
    with open(resolve_path(path), 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)


def add_entity(out, etype, value, method='regex', confidence=1.0):
    v = clean_text(value)
    if not v:
        return
    out.append((etype, v, confidence, method))


def score_message(text: str, entities: List[Tuple[str, str, float, str]], noise: List[str]) -> int:
    t = text.lower().strip()
    if not t or t == '[messaggio vuoto o non testuale]':
        return 0
    if any(t == n.lower() for n in noise):
        return 0
    score = 10
    score += min(70, len(entities) * 12)
    operative_terms = ['abend','errore','incident','ptask','udc','job','reorg','recover','bind','plan','package','fideuram','parmutil','critical','shortage','rallent','chiud','riapert','segnal']
    for term in operative_terms:
        if term in t:
            score += 8
    return max(0, min(100, score))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', default='config/config.ini')
    ap.add_argument('--rules', default='config/entity_patterns.yaml')
    ap.add_argument('--reset', action='store_true')
    args = ap.parse_args()
    cfg = load_config(args.config)
    con = connect_db(cfg['paths']['sqlite_db'])
    rules = load_rules(args.rules)
    if args.reset:
        con.execute('DELETE FROM message_entities')
        con.commit()

    regexes = [(k, re.compile(v, re.I)) for k, v in rules.get('regex_patterns', {}).items()]
    dicts = rules.get('dictionaries', {})
    noise = rules.get('noise_phrases', [])

    rows = con.execute('SELECT message_id, text, reply_to_text FROM messages ORDER BY seq').fetchall()
    total_entities = 0
    for row in tqdm(rows, desc='Estrazione entità'):
        text = ' '.join([row['text'] or '', row['reply_to_text'] or ''])
        found = []
        seen = set()
        for etype, rx in regexes:
            for m in rx.finditer(text):
                val = m.group(0)
                key = (etype, val.upper())
                if key not in seen:
                    add_entity(found, etype, val, 'regex')
                    seen.add(key)
        lower = text.lower()
        for etype, values in dicts.items():
            for value in values:
                if value.lower() in lower:
                    key = (etype, value.upper())
                    if key not in seen:
                        add_entity(found, etype, value, 'dictionary')
                        seen.add(key)
        con.execute('DELETE FROM message_entities WHERE message_id=?', (row['message_id'],))
        for etype, val, conf, method in found:
            con.execute('INSERT INTO message_entities(message_id, entity_type, entity_value, confidence, extraction_method) VALUES (?, ?, ?, ?, ?)', (row['message_id'], etype, val, conf, method))
        score = score_message(row['text'] or '', found, noise)
        con.execute('UPDATE messages SET operational_score=? WHERE message_id=?', (score, row['message_id']))
        total_entities += len(found)
    con.commit()
    print(f'Entità inserite: {total_entities}')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())

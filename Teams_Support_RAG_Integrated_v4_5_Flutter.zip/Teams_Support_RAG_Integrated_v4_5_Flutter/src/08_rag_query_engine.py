from __future__ import annotations

import argparse
import json
import os
import re
import time
from typing import Any, Dict, List, Optional, Tuple

import requests

from common import load_config, connect_db, json_dumps
from deepinfra_embed import embed_texts

ENGINE_VERSION = "v2-hybrid-exact-first-2026-05-28"

# Identificativi tecnici che NON devono essere cercati solo semanticamente.
TECH_PATTERNS = [
    r"\bINC[0-9A-Z]+\b",
    r"\bPTASK[0-9A-Z]+\b",
    r"\bH[0-9A-Z]{8,12}\b",
    r"\bO[0-9A-Z]{8,12}\b",
    r"\bDB20[A-Z0-9]+\b",
    r"\bDBR[0-9A-Z]+\b",
    r"\bDB[0-9A-Z]{2}\b",
    r"\b(?=[A-Z0-9]{6,12}\b)(?=[A-Z0-9]*\d)[A-Z][A-Z0-9]{5,11}\b",  # codici alfanumerici con almeno una cifra
    r"\b[A-Z0-9]{4,12}[£$#@]\b",     # es. job con caratteri speciali
]

KEYWORD_TERMS = {
    "PARMUTIL", "FIDEURAM", "IDAA", "FLASHCOPY", "FLASH", "COPY",
    "ABEND", "SQLCODE", "BIND", "REBIND", "RECOVER", "REORG", "RUNSTATS",
    "LOAD", "UNLOAD", "DSSIZE", "CRITICAL", "SHORTAGE", "NULLID",
    "CONFRONTO_PLAN", "CONFRONTO", "PLAN", "PACKAGE", "PACKAGES",
}

STOP_TERMS = {
    "TROVA", "RIFERIMENTI", "RIFERIMENTO", "PACKAGE", "PACKAGES",
    "MESSAGGI", "VERIFICA", "VERIFICARE", "SISTEMI", "PROBLEMI",
    "DIMMI", "CERCA", "CHAT", "TEAMS", "DBA", "SUPPORTO", "QUALCOSA",
    "COSA", "STATO", "DETTO", "RELATIVI", "RELATIVO", "PRESENTE",
}


def _row_to_dict(row: Any) -> Dict[str, Any]:
    return dict(row) if row is not None else {}


def extract_exact_terms(question: str) -> List[str]:
    """
    Estrae codici tecnici e keyword operative dalla domanda.
    Questi termini hanno priorità assoluta sulla ricerca semantica.
    """
    q = (question or "").upper()
    terms: List[str] = []

    for pat in TECH_PATTERNS:
        terms.extend(re.findall(pat, q, flags=re.I))

    for kw in KEYWORD_TERMS:
        if re.search(rf"\b{re.escape(kw)}\b", q, flags=re.I):
            terms.append(kw)

    cleaned = []
    for t in terms:
        t = t.strip().upper()
        if len(t) < 3:
            continue
        if t in STOP_TERMS:
            continue
        # evita di trattare parole italiane comuni maiuscolate come codici.
        if t.isalpha() and t not in KEYWORD_TERMS and len(t) < 8:
            continue
        cleaned.append(t)

    return sorted(set(cleaned))


def like_escape(value: str) -> str:
    return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def search_sqlite_exact_messages(con, terms: List[str], limit_per_term: int = 100) -> List[Dict[str, Any]]:
    """
    Ricerca deterministica in messages e message_entities.
    È la parte più importante per codici come Z7AJA000, INC..., PTASK..., job, package.
    """
    if not terms:
        return []

    results: List[Dict[str, Any]] = []
    seen: set[Tuple[str, str]] = set()

    for term in terms:
        term_upper = term.upper()
        like = f"%{like_escape(term_upper)}%"

        # 1) Ricerca diretta nel testo, reply, reaction, mention.
        rows = con.execute(
            """
            SELECT *
            FROM messages
            WHERE UPPER(COALESCE(text,'')) LIKE ? ESCAPE '\\'
               OR UPPER(COALESCE(reply_to_text,'')) LIKE ? ESCAPE '\\'
               OR UPPER(COALESCE(raw_block,'')) LIKE ? ESCAPE '\\'
               OR UPPER(COALESCE(reaction_summary,'')) LIKE ? ESCAPE '\\'
               OR UPPER(COALESCE(mention_summary,'')) LIKE ? ESCAPE '\\'
            ORDER BY COALESCE(NULLIF(created_ts_utc,''), created_ts), seq
            LIMIT ?
            """,
            (like, like, like, like, like, limit_per_term),
        ).fetchall()

        for r in rows:
            msg = _row_to_dict(r)
            key = (msg.get("message_id", ""), term_upper)
            if key in seen:
                continue
            seen.add(key)
            results.append({
                "source": "sqlite_exact_like",
                "score": 1.0,
                "matched_term": term_upper,
                "message": msg,
            })

        # 2) Ricerca su entità estratte.
        try:
            rows = con.execute(
                """
                SELECT DISTINCT m.*, e.entity_type, e.entity_value
                FROM message_entities e
                JOIN messages m ON m.message_id = e.message_id
                WHERE UPPER(e.entity_value) = ?
                   OR UPPER(e.entity_value) LIKE ? ESCAPE '\\'
                ORDER BY COALESCE(NULLIF(m.created_ts_utc,''), m.created_ts), m.seq
                LIMIT ?
                """,
                (term_upper, like, limit_per_term),
            ).fetchall()
        except Exception:
            rows = []

        for r in rows:
            d = _row_to_dict(r)
            msg = {k: d.get(k) for k in d.keys() if k not in {"entity_type", "entity_value"}}
            key = (msg.get("message_id", ""), term_upper)
            if key in seen:
                continue
            seen.add(key)
            results.append({
                "source": "sqlite_entity",
                "score": 1.0,
                "matched_term": term_upper,
                "entity_type": d.get("entity_type"),
                "entity_value": d.get("entity_value"),
                "message": msg,
            })

    return results


def make_fts_query(question: str) -> str:
    """
    Query FTS5 prudente. Per codici tecnici usa OR di token ripuliti.
    """
    tokens = re.findall(r"[A-Za-z0-9_£$#@]+", question or "")
    tokens = [t for t in tokens if len(t) >= 3 and t.upper() not in STOP_TERMS]
    if not tokens:
        return ""
    return " OR ".join(f'"{t}"' for t in tokens[:12])


def search_sqlite_fts(con, question: str, limit: int = 50) -> List[Dict[str, Any]]:
    """
    Usa messages_fts quando è popolata correttamente.
    Se la tabella è contentless e restituisce NULL, viene ignorata senza bloccare il RAG.
    """
    q = make_fts_query(question)
    if not q:
        return []

    try:
        rows = con.execute(
            """
            SELECT
                f.message_id AS fts_message_id,
                bm25(messages_fts) AS fts_score,
                m.*
            FROM messages_fts f
            JOIN messages m ON m.message_id = f.message_id
            WHERE messages_fts MATCH ?
            ORDER BY fts_score
            LIMIT ?
            """,
            (q, limit),
        ).fetchall()
    except Exception:
        return []

    results = []
    for r in rows:
        d = _row_to_dict(r)
        if not d.get("message_id"):
            continue
        results.append({
            "source": "sqlite_fts",
            "score": float(d.get("fts_score") or 0),
            "matched_term": "FTS",
            "message": d,
        })
    return results


def search_chunks_by_terms(con, terms: List[str], limit_per_term: int = 20) -> List[Dict[str, Any]]:
    """Ricerca LIKE sui chunk già costruiti. Utile se Qdrant non è allineato."""
    if not terms:
        return []
    out = []
    seen = set()
    for term in terms:
        like = f"%{like_escape(term.upper())}%"
        rows = con.execute(
            """
            SELECT *
            FROM rag_chunks
            WHERE UPPER(COALESCE(text,'')) LIKE ? ESCAPE '\\'
               OR UPPER(COALESCE(entities,'')) LIKE ? ESCAPE '\\'
            ORDER BY start_ts
            LIMIT ?
            """,
            (like, like, limit_per_term),
        ).fetchall()
        for r in rows:
            ch = _row_to_dict(r)
            cid = ch.get("chunk_id")
            if cid in seen:
                continue
            seen.add(cid)
            out.append({
                "id": cid,
                "score": 1.0,
                "source": "sqlite_chunk_like",
                "payload": ch,
                "matched_term": term,
            })
    return out


def hydrate_chunk_payloads(con, chunks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Sostituisce il payload Qdrant con la versione corrente SQLite quando disponibile.

    Serve anche alla migrazione timezone v4.4: i vettori esistenti restano validi, mentre
    timestamp e testo mostrati vengono letti dal chunk SQLite aggiornato.
    """
    for ch in chunks:
        payload = ch.get('payload') or {}
        cid = payload.get('chunk_id') or ch.get('id')
        if not cid:
            continue
        row = con.execute('SELECT * FROM rag_chunks WHERE chunk_id=?', (cid,)).fetchone()
        if row:
            ch['payload'] = _row_to_dict(row)
    return chunks


def expand_message_context(con, message_ids: List[str], before: int = 2, after: int = 2) -> List[Dict[str, Any]]:
    """Recupera messaggi prima/dopo per dare contesto operativo al match esatto."""
    if not message_ids:
        return []

    contexts: List[Dict[str, Any]] = []
    seen = set()

    for mid in message_ids:
        row = con.execute("SELECT seq, source_signature FROM messages WHERE message_id=?", (mid,)).fetchone()
        if not row or row["seq"] is None:
            continue
        seq = int(row["seq"])
        sig = row['source_signature']
        prev_rows = con.execute(
            "SELECT * FROM messages WHERE source_signature IS ? AND seq < ? ORDER BY seq DESC LIMIT ?",
            (sig, seq, before),
        ).fetchall()
        cur_rows = con.execute("SELECT * FROM messages WHERE message_id=?", (mid,)).fetchall()
        next_rows = con.execute(
            "SELECT * FROM messages WHERE source_signature IS ? AND seq > ? ORDER BY seq ASC LIMIT ?",
            (sig, seq, after),
        ).fetchall()
        rows = list(reversed(prev_rows)) + list(cur_rows) + list(next_rows)
        for r in rows:
            msg = _row_to_dict(r)
            key = msg.get("message_id")
            if key in seen:
                continue
            seen.add(key)
            contexts.append(msg)
    return contexts


def qdrant_search(cfg, question: str, top_k: int = 8, threshold: float = 0.2) -> List[Dict[str, Any]]:
    if not cfg.getboolean('qdrant', 'enabled', fallback=True):
        return []
    qurl = cfg["qdrant"]["url"].rstrip("/")
    collection = cfg["qdrant"]["collection"]
    vec = embed_texts(
        [question],
        cfg["llm"]["embedding_model"],
        cfg["llm"]["base_url"],
        cfg["llm"].get("api_key_env", "DEEPINFRA_API_KEY"),
    )[0]
    body = {"vector": vec, "limit": top_k, "with_payload": True, "score_threshold": threshold}
    r = requests.post(f"{qurl}/collections/{collection}/points/search", json=body, timeout=120)
    if r.status_code >= 400:
        raise RuntimeError(f"Qdrant search HTTP {r.status_code}: {r.text[:1000]}")
    result = r.json().get("result", []) or []
    for item in result:
        item.setdefault("source", "qdrant")
    return result


def filter_qdrant_for_exact_terms(chunks: List[Dict[str, Any]], exact_terms: List[str]) -> List[Dict[str, Any]]:
    """Se la domanda contiene codici tecnici, tieni solo chunk che contengono davvero quei codici."""
    if not exact_terms:
        return chunks
    kept = []
    for ch in chunks:
        payload = ch.get("payload") or {}
        hay = "\n".join(str(payload.get(k, "")) for k in ["text", "entities", "participants", "chunk_type"]).upper()
        if any(t.upper() in hay for t in exact_terms):
            kept.append(ch)
    return kept


def dedupe_message_results(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out = []
    seen = set()
    for item in items:
        msg = item.get("message") or {}
        mid = msg.get("message_id")
        src = item.get("source")
        key = (mid, src)
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
    return out


def format_message_line(msg: Dict[str, Any], max_len: int = 800) -> str:
    text = (msg.get("text") or "").strip()
    if len(text) > max_len:
        text = text[:max_len] + "..."
    reply = (msg.get("reply_to_text") or "").strip()
    prefix = ""
    if reply:
        ra = msg.get("reply_to_author") or ""
        rt = msg.get("reply_to_ts") or ""
        if len(reply) > 300:
            reply = reply[:300] + "..."
        prefix = f"  ↪ in risposta a {ra} {rt}: {reply}\n  "
    reacts = msg.get("reaction_summary") or ""
    if reacts:
        text = f"{text}\n  Reazioni: {reacts}"
    return f"- {msg.get('created_ts')} - {msg.get('author')}:\n  {prefix}{text}"


def build_answer_prompt(question: str, exact_terms: List[str], chunks: List[Dict[str, Any]], messages: List[Dict[str, Any]], context_messages: List[Dict[str, Any]]) -> str:
    parts = [
        "Sei un assistente tecnico DBA DB2 z/OS.",
        "Rispondi SOLO usando le fonti fornite sotto.",
        "Se la domanda contiene un codice tecnico specifico, considera validi solo riferimenti dove quel codice compare esplicitamente.",
        "Non compensare con argomenti genericamente simili. Non citare Fideuram, DB20RIBA, IDAA, ecc. se non sono nelle fonti pertinenti alla domanda.",
        "Organizza la risposta in: Sintesi, Timeline, Persone coinvolte, Azioni/decisioni, Fonti.",
        f"DOMANDA: {question}",
        f"TERMINI TECNICI ESTRATTI: {', '.join(exact_terms) if exact_terms else 'nessuno'}",
        "",
        "FONTI MESSAGGI EXACT/FTS:",
    ]

    if messages:
        for i, item in enumerate(messages[:40], 1):
            msg = item.get("message") or {}
            parts.append(f"[MSG {i}] source={item.get('source')} match={item.get('matched_term','')}\n{format_message_line(msg, 1200)}")
    else:
        parts.append("Nessun messaggio exact/FTS trovato.")

    if context_messages:
        parts.append("\nCONTESTO TEMPORALE DEI MESSAGGI TROVATI:")
        for i, msg in enumerate(context_messages[:80], 1):
            parts.append(f"[CTX {i}] {format_message_line(msg, 700)}")

    if chunks:
        parts.append("\nCHUNK RAG/SEMANTICI:")
        for i, ch in enumerate(chunks[:12], 1):
            p = ch.get("payload", {}) or {}
            text = (p.get("text") or "")[:3000]
            parts.append(f"[CHUNK {i}] source={ch.get('source','qdrant')} score={ch.get('score')} {p.get('start_ts')} - {p.get('end_ts')} tipo={p.get('chunk_type')}\n{text}")
    else:
        parts.append("\nNessun chunk RAG pertinente trovato.")

    return "\n\n".join(parts)


def call_chat_llm(cfg, prompt: str) -> Optional[str]:
    if not cfg.getboolean("llm", "enabled", fallback=False):
        return None
    api_key = os.environ.get(cfg["llm"].get("api_key_env", "DEEPINFRA_API_KEY"), "")
    if not api_key:
        return None
    url = cfg["llm"]["base_url"].rstrip("/") + "/chat/completions"
    payload = {
        "model": cfg["llm"]["chat_model"],
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0,
        "max_tokens": 1500,
    }
    r = requests.post(url, headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}, json=payload, timeout=180)
    r.raise_for_status()
    return r.json()["choices"][0]["message"]["content"]


def heuristic_answer(question: str, exact_terms: List[str], chunks: List[Dict[str, Any]], msgs: List[Dict[str, Any]], context_messages: List[Dict[str, Any]], qdrant_error: Optional[str] = None) -> str:
    lines: List[str] = []

    if exact_terms:
        lines.append(f"**Sintesi**")
        if msgs:
            lines.append(f"Ho trovato {len(msgs)} messaggio/i con riferimento diretto a: `{', '.join(exact_terms)}`.")
        else:
            lines.append(f"Non ho trovato riferimenti diretti a: `{', '.join(exact_terms)}` nei messaggi Teams caricati.")
            lines.append("Non riporto risultati generici perché la domanda contiene un identificativo tecnico specifico.")
            if qdrant_error:
                lines.append(f"Nota tecnica Qdrant: {qdrant_error}")
            return "\n\n".join(lines)
    else:
        lines.append("**Sintesi**")
        if not msgs and not chunks:
            lines.append("Non ho trovato risultati sufficienti nel database locale/RAG.")
            if qdrant_error:
                lines.append(f"Nota tecnica Qdrant: {qdrant_error}")
            return "\n\n".join(lines)
        lines.append(f"Ho trovato {len(msgs)} messaggio/i SQLite/FTS e {len(chunks)} chunk RAG.")

    if msgs:
        lines.append("\n**Timeline**")
        seen = set()
        for item in msgs[:25]:
            msg = item.get("message") or {}
            mid = msg.get("message_id")
            if mid in seen:
                continue
            seen.add(mid)
            term = item.get("matched_term") or ""
            source = item.get("source") or ""
            lines.append(f"- **{msg.get('created_ts')}** — **{msg.get('author')}** [{source} {term}]  ")
            if msg.get("reply_to_text"):
                lines.append(f"  ↪ Risponde a **{msg.get('reply_to_author','')}**: {(msg.get('reply_to_text') or '')[:300]}")
            lines.append(f"  {(msg.get('text') or '').strip()[:1200]}")
            if msg.get("reaction_summary"):
                lines.append(f"  Reazioni: {msg.get('reaction_summary')}")

    if context_messages and exact_terms:
        lines.append("\n**Contesto vicino ai match**")
        for msg in context_messages[:20]:
            marker = ""
            text_upper = ((msg.get("text") or "") + " " + (msg.get("reply_to_text") or "")).upper()
            if any(t in text_upper for t in exact_terms):
                marker = " ← match"
            lines.append(f"- {msg.get('created_ts')} — {msg.get('author')}: {(msg.get('text') or '')[:350]}{marker}")

    if chunks and not exact_terms:
        lines.append("\n**Chunk RAG principali**")
        for ch in chunks[:8]:
            p = ch.get("payload", {}) or {}
            score = ch.get("score")
            try:
                score_txt = f"{float(score):.3f}"
            except Exception:
                score_txt = str(score)
            lines.append(f"- {p.get('start_ts')} - {p.get('end_ts')} | {p.get('chunk_type')} | score={score_txt}")

    people = []
    for item in msgs:
        a = (item.get("message") or {}).get("author")
        if a and a not in people:
            people.append(a)
    if people:
        lines.append("\n**Persone coinvolte**")
        lines.append(", ".join(people[:20]))

    lines.append("\n**Azioni/decisioni**")
    lines.append("Vedi i messaggi riportati sopra; la risposta è basata sui match esatti/FTS e non su chunk generici.")

    if qdrant_error:
        lines.append(f"\n**Nota tecnica Qdrant**: {qdrant_error}")

    return "\n".join(lines)


def ask_detailed(question: str, config: str = "config/config.ini", top_k: Optional[int] = None, threshold: Optional[float] = None) -> Dict[str, Any]:
    t0 = time.time()
    cfg = load_config(config)
    con = connect_db(cfg["paths"]["sqlite_db"])
    top_k = top_k or cfg.getint("rag", "top_k", fallback=8)
    threshold = threshold if threshold is not None else cfg.getfloat("rag", "score_threshold", fallback=0.2)

    before = cfg.getint("rag", "context_before", fallback=3)
    after = cfg.getint("rag", "context_after", fallback=3)

    exact_terms = extract_exact_terms(question)
    exact = search_sqlite_exact_messages(con, exact_terms)
    fts = search_sqlite_fts(con, question)

    # Per domande con codice tecnico, non permettere a Qdrant di contaminare la risposta con chunk generici.
    chunks: List[Dict[str, Any]] = []
    qdrant_error: Optional[str] = None

    if exact_terms:
        chunks = search_chunks_by_terms(con, exact_terms, limit_per_term=10)
        # Qdrant si usa solo come complemento, e poi si filtra obbligatoriamente per presenza del codice.
        try:
            qchunks = qdrant_search(cfg, question, top_k, threshold)
            chunks.extend(filter_qdrant_for_exact_terms(qchunks, exact_terms))
        except Exception as e:
            qdrant_error = str(e)
    else:
        try:
            chunks = qdrant_search(cfg, question, top_k, threshold)
        except Exception as e:
            qdrant_error = str(e)

    chunks = hydrate_chunk_payloads(con, chunks)

    msgs = dedupe_message_results(exact + fts)

    # Se ci sono termini tecnici, rimuovi messaggi FTS che non contengono almeno un termine.
    if exact_terms:
        filtered = []
        for item in msgs:
            msg = item.get("message") or {}
            hay = "\n".join(str(msg.get(k, "")) for k in ["text", "reply_to_text", "raw_block", "mention_summary", "reaction_summary"]).upper()
            if any(t.upper() in hay for t in exact_terms):
                filtered.append(item)
        msgs = filtered

    context_messages = []
    if msgs:
        context_messages = expand_message_context(con, [(x.get("message") or {}).get("message_id") for x in msgs if (x.get("message") or {}).get("message_id")], before, after)

    prompt = build_answer_prompt(question, exact_terms, chunks, msgs, context_messages)
    answer = call_chat_llm(cfg, prompt) or heuristic_answer(question, exact_terms, chunks, msgs, context_messages, qdrant_error)

    elapsed = int((time.time() - t0) * 1000)
    retrieved_chunk_ids = [c.get("id") or (c.get("payload") or {}).get("chunk_id") for c in chunks]
    retrieved_entities = exact_terms
    con.execute(
        "INSERT INTO qa_history(question, answer, retrieved_chunks, retrieved_entities, model, elapsed_ms) VALUES (?, ?, ?, ?, ?, ?)",
        (question, answer, json_dumps(retrieved_chunk_ids), json_dumps(retrieved_entities), cfg["llm"].get("chat_model", "heuristic"), elapsed),
    )
    con.commit()

    return {
        "answer": answer,
        "exact_terms": exact_terms,
        "messages": msgs,
        "context_messages": context_messages,
        "chunks": chunks,
        "qdrant_error": qdrant_error,
        "elapsed_ms": elapsed,
        "engine_version": ENGINE_VERSION,
    }


def ask(question: str, config: str = "config/config.ini", top_k: Optional[int] = None, threshold: Optional[float] = None) -> str:
    return ask_detailed(question, config=config, top_k=top_k, threshold=threshold)["answer"]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("question", nargs="*")
    ap.add_argument("--config", default="config/config.ini")
    ap.add_argument("--top-k", type=int)
    ap.add_argument("--threshold", type=float)
    ap.add_argument("--json", action="store_true", help="Stampa output dettagliato JSON")
    args = ap.parse_args()

    q = " ".join(args.question).strip() or input("Domanda: ")
    result = ask_detailed(q, args.config, top_k=args.top_k, threshold=args.threshold)
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
    else:
        print(result["answer"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

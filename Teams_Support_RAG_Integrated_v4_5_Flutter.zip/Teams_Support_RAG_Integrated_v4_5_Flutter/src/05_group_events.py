from __future__ import annotations

import argparse
import datetime as dt
from collections import defaultdict

from common import load_config, connect_db, stable_id, json_dumps, parse_iso_utc

PRIORITY_TYPES = ['INCIDENT','PTASK','UDC_H','UDC_O','DB20_PROGRAM','DBR','DB2_SUBSYSTEM','TOPIC','JOB_ID']


def split_by_gap(rows, gap_minutes: int):
    groups = []; current = []; previous = None
    for r in sorted(rows, key=lambda x: (x['created_ts_utc'] or x['created_ts'] or '', x['message_id'])):
        cur = parse_iso_utc(r['created_ts_utc'] or r['created_ts'])
        if current and previous and cur and (cur - previous).total_seconds() > gap_minutes * 60:
            groups.append(current); current = []
        current.append(r)
        if cur: previous = cur
    if current: groups.append(current)
    return groups


def main() -> int:
    ap = argparse.ArgumentParser(); ap.add_argument('--config', default='config/config.ini'); ap.add_argument('--reset', action='store_true')
    args = ap.parse_args(); cfg = load_config(args.config); con = connect_db(cfg['paths']['sqlite_db'])
    gap = cfg.getint('events', 'max_gap_minutes', fallback=360)
    # Gli eventi sono derivati: ricostruirli è più sicuro che lasciare cluster obsoleti.
    con.execute('DELETE FROM event_messages'); con.execute('DELETE FROM conversation_events')
    ent_map = defaultdict(list)
    for r in con.execute('''SELECT e.entity_type,e.entity_value,m.message_id,m.created_ts,m.created_ts_utc,m.author,m.source_signature,m.source_name
                            FROM message_entities e JOIN messages m ON m.message_id=e.message_id
                            WHERE m.operational_score >= 30 ORDER BY COALESCE(NULLIF(m.created_ts_utc,''), m.created_ts)''').fetchall():
        if r['entity_type'] in PRIORITY_TYPES:
            ent_map[(r['source_signature'] or 'legacy', r['source_name'] or '', r['entity_type'], r['entity_value'].upper())].append(r)
    created = 0
    for (sig, src_name, etype, val), rows in ent_map.items():
        for group_no, group in enumerate(split_by_gap(rows, gap), 1):
            participants = sorted({r['author'] for r in group if r['author']})
            event_id = stable_id(sig, etype, val, (group[0]['created_ts_utc'] or group[0]['created_ts'])[:13], group_no, prefix='evt_')
            title = f'{etype}: {val}'
            summary = f'Cluster operativo {etype}={val}; messaggi collegati: {len(group)}; gap massimo cluster: {gap} minuti.'
            con.execute('''INSERT INTO conversation_events(event_id,event_type,source_signature,source_name,title,start_ts,end_ts,start_ts_utc,end_ts_utc,main_entity,summary,status,participants,entities)
                           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)''', (event_id, etype, sig, src_name, title, group[0]['created_ts'], group[-1]['created_ts'],
                           group[0]['created_ts_utc'] or group[0]['created_ts'], group[-1]['created_ts_utc'] or group[-1]['created_ts'], val,
                           summary, 'non_determinato', json_dumps(participants), json_dumps([{'type':etype,'value':val}])))
            for i, r in enumerate(group):
                con.execute('INSERT INTO event_messages(event_id,message_id,role) VALUES (?,?,?)', (event_id, r['message_id'], 'opening' if i == 0 else 'context'))
            created += 1
    con.commit(); print(f'Eventi temporali creati: {created}'); return 0


if __name__ == '__main__': raise SystemExit(main())

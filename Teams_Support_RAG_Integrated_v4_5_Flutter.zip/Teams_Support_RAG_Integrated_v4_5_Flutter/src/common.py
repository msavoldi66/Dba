from __future__ import annotations

import configparser
import datetime as dt
import hashlib
import json
import re
import sqlite3
from pathlib import Path
from typing import Any, Iterable, List, Optional
from zoneinfo import ZoneInfo

from dotenv import load_dotenv


def project_root() -> Path:
    return Path(__file__).resolve().parents[1]


# Carica automaticamente .env dalla root del progetto.
load_dotenv(project_root() / '.env')


def load_config(path: str | Path = 'config/config.ini') -> configparser.ConfigParser:
    p = Path(path)
    if not p.is_absolute():
        p = project_root() / p
    cfg = configparser.ConfigParser(interpolation=None)
    if not p.exists():
        raise FileNotFoundError(f'Config non trovato: {p}')
    cfg.read(p, encoding='utf-8')
    return cfg


def resolve_path(value: str | Path) -> Path:
    p = Path(value)
    if not p.is_absolute():
        p = project_root() / p
    return p


def connect_db(db_path: str | Path) -> sqlite3.Connection:
    p = resolve_path(db_path)
    p.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(p, timeout=60)
    con.row_factory = sqlite3.Row
    con.execute('PRAGMA journal_mode=WAL')
    con.execute('PRAGMA foreign_keys=ON')
    con.execute('PRAGMA synchronous=NORMAL')
    con.execute('PRAGMA busy_timeout=60000')
    return con


def now_utc() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds').replace('+00:00', 'Z')


def parse_iso_utc(value: Optional[str]) -> Optional[dt.datetime]:
    if not value:
        return None
    s = value.strip()
    if not s:
        return None
    if re.fullmatch(r'\d{4}-\d{2}-\d{2}', s):
        s += 'T00:00:00Z'
    if s.endswith('Z'):
        s = s[:-1] + '+00:00'
    try:
        d = dt.datetime.fromisoformat(s)
    except ValueError:
        return None
    if d.tzinfo is None:
        d = d.replace(tzinfo=dt.timezone.utc)
    return d.astimezone(dt.timezone.utc)


def normalize_iso_utc(value: Optional[str]) -> str:
    d = parse_iso_utc(value)
    if d is None:
        return value or ''
    return d.isoformat(timespec='seconds').replace('+00:00', 'Z')


def get_local_timezone(cfg=None, fallback: str = 'Europe/Rome') -> str:
    if cfg is None:
        return fallback
    try:
        return cfg.get('time', 'local_timezone', fallback=fallback).strip() or fallback
    except Exception:
        return fallback


def iso_utc_to_local(value: Optional[str], timezone_name: str = 'Europe/Rome') -> str:
    # Converte UTC in ora locale applicando automaticamente CET/CEST.
    d = parse_iso_utc(value)
    if d is None:
        return value or ''
    try:
        tz = ZoneInfo(timezone_name)
    except Exception as exc:
        raise RuntimeError(
            f'Timezone IANA non disponibile: {timezone_name}. Verificare la dipendenza tzdata.'
        ) from exc
    return d.astimezone(tz).isoformat(timespec='seconds')


def ts_date(ts: str) -> str:
    return ts[:10] if ts else ''


def ts_time(ts: str) -> str:
    return ts[11:19] if len(ts) >= 19 else ''


def stable_id(*parts: Any, prefix: str = '') -> str:
    raw = '|'.join(str(p) for p in parts)
    h = hashlib.sha1(raw.encode('utf-8', errors='ignore')).hexdigest()[:20]
    return f'{prefix}{h}' if prefix else h


def clean_text(s: Optional[str]) -> str:
    if not s:
        return ''
    s = s.replace('\xa0', ' ')
    s = re.sub(r'[ \t]+', ' ', s)
    s = re.sub(r'\n{3,}', '\n\n', s)
    return s.strip()


def json_dumps(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True)


def json_loads_safe(s: Optional[str], default: Any = None) -> Any:
    if not s:
        return default
    try:
        return json.loads(s)
    except Exception:
        return default


def batched(seq: List[Any], size: int) -> Iterable[List[Any]]:
    for i in range(0, len(seq), size):
        yield seq[i:i + size]

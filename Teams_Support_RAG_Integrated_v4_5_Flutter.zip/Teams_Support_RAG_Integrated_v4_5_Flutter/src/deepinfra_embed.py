from __future__ import annotations
import os
import requests
from typing import List


def embed_texts(texts: List[str], model: str, base_url: str, api_key_env: str) -> List[List[float]]:
    api_key = os.environ.get(api_key_env, '')
    if not api_key:
        raise RuntimeError(f'Variabile ambiente {api_key_env} non impostata')
    url = base_url.rstrip('/') + '/embeddings'
    r = requests.post(url, headers={'Authorization': f'Bearer {api_key}', 'Content-Type':'application/json'}, json={'model': model, 'input': texts}, timeout=180)
    r.raise_for_status()
    data = r.json()['data']
    data = sorted(data, key=lambda x: x.get('index', 0))
    return [x['embedding'] for x in data]

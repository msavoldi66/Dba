from __future__ import annotations

import argparse
import datetime as dt
import html
import json
import re
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple
from urllib.parse import quote

import requests

from common import load_config, resolve_path, parse_iso_utc, normalize_iso_utc, iso_utc_to_local, get_local_timezone, now_utc
from graph_auth import get_access_token


def log(msg: str) -> None:
    print(f'[{now_utc()}] {msg}', flush=True)


def strip_html_to_text(value: Optional[str]) -> str:
    if not value:
        return ''
    text = value
    text = re.sub(r'(?is)<(script|style).*?>.*?</\1>', ' ', text)
    text = re.sub(r'(?i)<br\s*/?>', '\n', text)
    text = re.sub(r'(?i)</(?:p|div)\s*>', '\n', text)
    text = re.sub(r'(?s)<[^>]+>', ' ', text)
    text = html.unescape(text).replace('\xa0', ' ')
    text = re.sub(r'[ \t\r\f\v]+', ' ', text)
    text = re.sub(r'\n\s+', '\n', text)
    text = re.sub(r'\n{3,}', '\n\n', text)
    return text.strip()


def remove_blockquotes(value: Optional[str]) -> str:
    return re.sub(r'(?is)<blockquote.*?>.*?</blockquote>', ' ', value or '')


def extract_quoted_reply(value: Optional[str]) -> Optional[Dict[str, str]]:
    if not value:
        return None
    m = re.search(r'(?is)<blockquote.*?>(.*?)</blockquote>', value)
    if not m:
        return None
    txt = strip_html_to_text(m.group(1))
    if not txt:
        return None
    author = ''
    qdt = ''
    m2 = re.search(r"(?im)^([A-ZÀ-Ü][A-ZÀ-Ü' .-]{2,80})\s+(\d{1,2}/\d{1,2}/\d{4}\s+\d{1,2}:\d{2})", txt)
    if m2:
        author, qdt = m2.group(1).strip(), m2.group(2).strip()
    return {'quoted_text': txt, 'quoted_author': author, 'quoted_datetime': qdt}


def source_signature(mode: str, chat_id: str, team_id: str, channel_id: str) -> str:
    return f'chat:{chat_id}' if mode == 'chat' else f'channel:{team_id}:{channel_id}'


def iso_z(value: dt.datetime) -> str:
    return value.astimezone(dt.timezone.utc).isoformat(timespec='seconds').replace('+00:00', 'Z')


def utc_now_dt() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0)


def normalize_message(raw: Dict[str, Any], mode: str, chat_id: str, team_id: str, channel_id: str,
                      parent_context: Optional[Dict[str, Any]] = None, source_name: str = '') -> Dict[str, Any]:
    body = raw.get('body') or {}
    from_obj = raw.get('from') or {}
    user = from_obj.get('user') or {}
    app = from_obj.get('application') or {}
    author = user.get('displayName') or app.get('displayName') or raw.get('fromDisplayName') or 'Sconosciuto'
    body_html = body.get('content') or ''
    quote_ctx = extract_quoted_reply(body_html)
    text = strip_html_to_text(remove_blockquotes(body_html) or body_html)
    reply_to_id = raw.get('replyToId') or raw.get('replyToMessageId') or raw.get('parentMessageId')

    reply_context = parent_context
    if not reply_context and quote_ctx:
        reply_context = {
            'source': 'quoted_reply_html', 'id': None,
            'createdDateTime': quote_ctx.get('quoted_datetime', ''),
            'author': quote_ctx.get('quoted_author', ''), 'text': quote_ctx.get('quoted_text', '')
        }

    return {
        'id': str(raw.get('id') or ''),
        'createdDateTime': normalize_iso_utc(raw.get('createdDateTime') or raw.get('lastModifiedDateTime')),
        'lastModifiedDateTime': normalize_iso_utc(raw.get('lastModifiedDateTime')),
        'lastEditedDateTime': normalize_iso_utc(raw.get('lastEditedDateTime')),
        'deletedDateTime': normalize_iso_utc(raw.get('deletedDateTime')),
        'importance': raw.get('importance'), 'messageType': raw.get('messageType'),
        'subject': raw.get('subject'), 'summary': raw.get('summary'), 'etag': raw.get('etag'),
        'chatId': raw.get('chatId') or chat_id or '', 'replyToId': reply_to_id,
        'author': author, 'from': from_obj, 'body_content_type': body.get('contentType'),
        'body_html': body_html, 'text': text, 'full_text_with_quote': strip_html_to_text(body_html),
        'quoted_reply': quote_ctx, 'is_reply': bool(reply_to_id or reply_context), 'reply_context': reply_context,
        'attachments': raw.get('attachments') or [], 'mentions': raw.get('mentions') or [],
        'reactions': raw.get('reactions') or [], 'source_mode': mode,
        'source_name': source_name,
        'source_signature': source_signature(mode, chat_id, team_id, channel_id),
        'team_id': team_id or '', 'channel_id': channel_id or '', 'raw': raw,
    }


def graph_get_json(url: str, token: str, timeout: int, max_retries: int, verify_ssl: bool) -> Dict[str, Any]:
    headers = {'Authorization': f'Bearer {token}', 'Accept': 'application/json'}
    last_error: Optional[BaseException] = None
    for attempt in range(1, max_retries + 1):
        try:
            r = requests.get(url, headers=headers, timeout=timeout, verify=verify_ssl)
            if r.status_code == 429:
                retry = r.headers.get('Retry-After', '')
                wait = int(retry) if retry.isdigit() else min(60, 2 ** attempt)
                log(f'Graph throttling HTTP 429: attendo {wait}s')
                time.sleep(wait)
                continue
            if 500 <= r.status_code < 600:
                wait = min(60, 2 ** attempt)
                log(f'Graph HTTP {r.status_code}: retry tra {wait}s')
                time.sleep(wait)
                continue
            if r.status_code >= 400:
                raise RuntimeError(f'Graph HTTP {r.status_code}: {r.text[:3000]}')
            return r.json()
        except requests.RequestException as exc:
            last_error = exc
            wait = min(60, 2 ** attempt)
            log(f'Errore rete Graph: {exc}; retry tra {wait}s')
            time.sleep(wait)
    raise RuntimeError(f'Graph non raggiungibile dopo {max_retries} tentativi: {last_error}')


def build_initial_url(cfg, mode: str, chat_id: str, team_id: str, channel_id: str,
                      incremental_since: Optional[dt.datetime] = None,
                      incremental_until: Optional[dt.datetime] = None) -> str:
    base = cfg.get('graph', 'base_url', fallback='https://graph.microsoft.com/v1.0').rstrip('/')
    top = min(50, max(1, cfg.getint('graph', 'page_size', fallback=50)))
    if mode == 'chat':
        cid = quote(chat_id, safe=':@.-_')
        if incremental_since is not None:
            # V4: incrementalità vera su lastModifiedDateTime. Questo intercetta anche edit e reaction.
            upper = incremental_until or utc_now_dt()
            filter_expr = f'lastModifiedDateTime gt {iso_z(incremental_since)} and lastModifiedDateTime lt {iso_z(upper)}'
            encoded_filter = quote(filter_expr, safe=':.-')
            return (
                f'{base}/chats/{cid}/messages?$top={top}'
                f'&$orderby=lastModifiedDateTime%20desc&$filter={encoded_filter}'
            )
        # Primo caricamento: Graph non supporta createdDateTime gt, quindi si pagina in ordine created desc
        # e ci si ferma appena si supera il limite inferiore configurato.
        return f'{base}/chats/{cid}/messages?$top={top}&$orderby=createdDateTime%20desc'
    tid = quote(team_id, safe='-_.')
    chid = quote(channel_id, safe=':@.-_')
    expand = '&$expand=replies' if cfg.getboolean('teams', 'include_channel_replies', fallback=True) else ''
    return f'{base}/teams/{tid}/channels/{chid}/messages?$top={top}{expand}'


def paths(out_dir: Path) -> Tuple[Path, Path, Path, Path]:
    return (out_dir / 'download_state.json', out_dir / 'messages_checkpoint.jsonl',
            out_dir / 'messages_final.jsonl', out_dir / 'messaggi_chat.txt')


def run_messages_path(out_dir: Path) -> Path:
    # Journal del run corrente: consente resume e produce un JSONL delta esatto senza
    # rileggere come delta tutti i record storici che ricadono nell'overlap.
    return out_dir / 'messages_current_run.jsonl'


def watermark_path(cfg) -> Path:
    return resolve_path(cfg.get('teams', 'watermark_file', fallback='state/teams_watermark.json'))


def load_state(p: Path) -> Dict[str, Any]:
    try:
        return json.loads(p.read_text(encoding='utf-8')) if p.exists() else {}
    except Exception:
        return {}


def save_state(p: Path, state: Dict[str, Any]) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + '.tmp')
    tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(p)


def load_watermark_store(p: Path) -> Dict[str, Any]:
    data = load_state(p)
    if not isinstance(data, dict):
        data = {}
    data.setdefault('version', 1)
    data.setdefault('sources', {})
    if not isinstance(data['sources'], dict):
        data['sources'] = {}
    return data


def get_source_watermark(cfg, signature: str) -> Optional[dt.datetime]:
    store = load_watermark_store(watermark_path(cfg))
    entry = store.get('sources', {}).get(signature) or {}
    return parse_iso_utc(entry.get('watermark_utc'))


def reset_source_watermark(cfg, signature: str) -> None:
    p = watermark_path(cfg)
    store = load_watermark_store(p)
    if signature in store.get('sources', {}):
        del store['sources'][signature]
        store['updated_at'] = now_utc()
        save_state(p, store)
        log(f'Watermark rimosso per {signature}.')


def commit_pending_watermark(config_path: str, chat_id_override: str = '', out_dir_override: str = '',
                             mode_override: str = '', team_id_override: str = '', channel_id_override: str = '') -> int:
    cfg = load_config(config_path)
    out_dir = resolve_path(out_dir_override or cfg.get('paths', 'teams_out_dir', fallback='data/teams_download'))
    state_p, _, _, _ = paths(out_dir)
    state = load_state(state_p)

    mode = (mode_override or cfg.get('teams', 'mode', fallback='chat')).strip().lower()
    chat_id = (chat_id_override or cfg.get('teams', 'chat_id', fallback='')).strip()
    team_id = (team_id_override or cfg.get('teams', 'team_id', fallback='')).strip()
    channel_id = (channel_id_override or cfg.get('teams', 'channel_id', fallback='')).strip()
    signature = source_signature(mode, chat_id, team_id, channel_id)

    if not state.get('completed') or state.get('source_signature') != signature:
        log('Nessun watermark pendente da confermare per questa sorgente.')
        return 0
    pending = parse_iso_utc(state.get('pending_watermark_utc'))
    if pending is None:
        log('Download completato ma nessun pending_watermark_utc presente: nulla da confermare.')
        return 0

    p = watermark_path(cfg)
    store = load_watermark_store(p)
    old = parse_iso_utc((store.get('sources', {}).get(signature) or {}).get('watermark_utc'))
    committed = max(x for x in (old, pending) if x is not None) if old else pending
    store['sources'][signature] = {
        'watermark_utc': iso_z(committed),
        'committed_at': now_utc(),
        'last_scan_mode': state.get('scan_mode', ''),
        'last_scan_started_at': state.get('run_started_at', ''),
        'last_scan_effective_since': state.get('effective_since', ''),
        'last_scan_upper_bound': state.get('scan_upper_bound', ''),
        'overlap_hours_used': state.get('overlap_hours', 0),
        'last_seen_message_id': state.get('last_seen_message_id', ''),
        'last_seen_created_datetime': state.get('last_seen_created_datetime', ''),
        'last_seen_modified_datetime': state.get('last_seen_modified_datetime', ''),
        'last_download_completed_at': state.get('completed_at', ''),
    }
    store['updated_at'] = now_utc()
    save_state(p, store)

    state['watermark_committed'] = True
    state['watermark_committed_at'] = now_utc()
    state['committed_watermark_utc'] = iso_z(committed)
    save_state(state_p, state)
    log(f'Watermark confermato per {signature}: {iso_z(committed)}')
    return 0


def message_version_key(m: Dict[str, Any]) -> str:
    sig = str(m.get('source_signature') or '')
    mid = str(m.get('id') or '')
    parent = str(m.get('replyToId') or '')
    if m.get('source_mode') == 'channel' and parent:
        return f'{sig}|reply:{parent}:{mid}'
    return f'{sig}|{mid}'


def load_known_versions(checkpoint: Path) -> Dict[str, str]:
    versions: Dict[str, str] = {}
    if not checkpoint.exists():
        return versions
    with checkpoint.open('r', encoding='utf-8') as f:
        for line in f:
            try:
                m = json.loads(line)
                key = message_version_key(m)
                if not m.get('id'):
                    continue
                versions[key] = str(m.get('etag') or m.get('lastModifiedDateTime') or m.get('createdDateTime') or '')
            except Exception:
                pass
    return versions


def append_changed(checkpoint: Path, messages: Iterable[Dict[str, Any]], versions: Dict[str, str]) -> Tuple[int, int]:
    inserted = unchanged = 0
    checkpoint.parent.mkdir(parents=True, exist_ok=True)
    with checkpoint.open('a', encoding='utf-8') as f:
        for m in messages:
            key = message_version_key(m)
            version = str(m.get('etag') or m.get('lastModifiedDateTime') or m.get('createdDateTime') or '')
            if versions.get(key) == version:
                unchanged += 1
                continue
            f.write(json.dumps(m, ensure_ascii=False) + '\n')
            versions[key] = version
            inserted += 1
    return inserted, unchanged


def created_in_scope(m: Dict[str, Any], from_dt: Optional[dt.datetime], to_dt: Optional[dt.datetime]) -> bool:
    mts = parse_iso_utc(m.get('createdDateTime'))
    if mts is None:
        return from_dt is None and to_dt is None
    return not (from_dt and mts < from_dt) and not (to_dt and mts > to_dt)


def modified_in_window(m: Dict[str, Any], since: Optional[dt.datetime], until: Optional[dt.datetime]) -> bool:
    mts = parse_iso_utc(m.get('lastModifiedDateTime')) or parse_iso_utc(m.get('createdDateTime'))
    if mts is None:
        return since is None and until is None
    if since and not (mts > since):
        return False
    if until and not (mts < until):
        return False
    return True


def parent_context(root: Dict[str, Any], mode: str, chat_id: str, team_id: str, channel_id: str, source_name: str = '') -> Dict[str, Any]:
    n = normalize_message(root, mode, chat_id, team_id, channel_id, source_name=source_name)
    return {'source': 'channel_root', 'id': n['id'], 'createdDateTime': n['createdDateTime'],
            'author': n['author'], 'text': n['text']}


def collect_channel_page(values: List[Dict[str, Any]], cfg, token: str, timeout: int, retries: int,
                         verify_ssl: bool, chat_id: str, team_id: str, channel_id: str, source_name: str = '') -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    include_replies = cfg.getboolean('teams', 'include_channel_replies', fallback=True)
    for root in values:
        nr = normalize_message(root, 'channel', chat_id, team_id, channel_id, source_name=source_name)
        out.append(nr)
        if not include_replies:
            continue
        pctx = parent_context(root, 'channel', chat_id, team_id, channel_id, source_name)
        for rep in root.get('replies') or []:
            rep = dict(rep)
            rep.setdefault('replyToId', root.get('id'))
            out.append(normalize_message(rep, 'channel', chat_id, team_id, channel_id, pctx, source_name))
        reply_next = root.get('replies@odata.nextLink')
        while reply_next:
            data = graph_get_json(reply_next, token, timeout, retries, verify_ssl)
            for rep in data.get('value') or []:
                rep = dict(rep)
                rep.setdefault('replyToId', root.get('id'))
                out.append(normalize_message(rep, 'channel', chat_id, team_id, channel_id, pctx, source_name))
            reply_next = data.get('@odata.nextLink')
    return out


def load_latest_messages(path: Path) -> Dict[str, Dict[str, Any]]:
    latest: Dict[str, Dict[str, Any]] = {}
    if not path.exists():
        return latest
    with path.open('r', encoding='utf-8') as f:
        for line in f:
            try:
                m = json.loads(line)
            except Exception:
                continue
            key = message_version_key(m)
            if not m.get('id'):
                continue
            latest[key] = m
    return latest


def append_run_messages(path: Path, messages: Iterable[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a', encoding='utf-8') as f:
        for m in messages:
            f.write(json.dumps(m, ensure_ascii=False) + '\n')


def rebuild_outputs(selection_checkpoint: Path, final_jsonl: Path, txt: Path,
                    initial_from_dt: Optional[dt.datetime], to_dt: Optional[dt.datetime],
                    context_checkpoint: Optional[Path] = None, timezone_name: str = 'Europe/Rome') -> int:
    # selection_checkpoint determina ESATTAMENTE quali messaggi finiscono nel JSONL del run.
    # context_checkpoint può invece essere lo storico globale, usato per risolvere i parent delle reply.
    selected_latest = load_latest_messages(selection_checkpoint)
    context_latest = load_latest_messages(context_checkpoint or selection_checkpoint)
    selected = [m for m in selected_latest.values() if created_in_scope(m, initial_from_dt, to_dt)]
    selected.sort(key=lambda m: (m.get('createdDateTime') or '', m.get('id') or ''))

    by_key = {}
    for pm in context_latest.values():
        if pm.get('source_mode') == 'channel' and pm.get('replyToId'):
            continue
        by_key[(pm.get('source_signature'), str(pm.get('id')))] = pm
    for m in selected:
        rid = str(m.get('replyToId') or '')
        if rid and not m.get('reply_context'):
            parent = by_key.get((m.get('source_signature'), rid))
            if parent:
                m['reply_context'] = {
                    'source': 'replyToId', 'id': rid,
                    'createdDateTime': parent.get('createdDateTime'), 'author': parent.get('author'),
                    'text': parent.get('text') or parent.get('full_text_with_quote') or ''
                }
                m['is_reply'] = True

    final_jsonl.parent.mkdir(parents=True, exist_ok=True)
    with final_jsonl.open('w', encoding='utf-8') as f:
        for m in selected:
            f.write(json.dumps(m, ensure_ascii=False) + '\n')

    sep = '-' * 120
    with txt.open('w', encoding='utf-8') as f:
        for m in reversed(selected):
            f.write(f"[{iso_utc_to_local(m.get('createdDateTime',''), timezone_name)}] {m.get('author','Sconosciuto')}: ")
            rc = m.get('reply_context') or {}
            if rc:
                f.write(f"\n  >>> IN RISPOSTA A [{iso_utc_to_local(rc.get('createdDateTime',''), timezone_name)}] {rc.get('author','')}:\n")
                for line in str(rc.get('text') or '').splitlines():
                    f.write(f'  >>> {line}\n')
            f.write((m.get('text') or '') + '\n' + sep + '\n')
    return len(selected)


def update_last_seen(state: Dict[str, Any], messages: Iterable[Dict[str, Any]]) -> None:
    best_mod = parse_iso_utc(state.get('last_seen_modified_datetime'))
    best_created = parse_iso_utc(state.get('last_seen_created_datetime'))
    best_id = state.get('last_seen_message_id', '')
    for m in messages:
        mod = parse_iso_utc(m.get('lastModifiedDateTime')) or parse_iso_utc(m.get('createdDateTime'))
        created = parse_iso_utc(m.get('createdDateTime'))
        if mod and (best_mod is None or mod > best_mod):
            best_mod = mod
            best_id = str(m.get('id') or best_id)
        if created and (best_created is None or created > best_created):
            best_created = created
    state['last_seen_modified_datetime'] = iso_z(best_mod) if best_mod else ''
    state['last_seen_created_datetime'] = iso_z(best_created) if best_created else ''
    state['last_seen_message_id'] = best_id


def run(config_path: str, restart: bool = False, rebuild_only: bool = False,
        chat_id_override: str = '', reset_watermark: bool = False, out_dir_override: str = '',
        mode_override: str = '', team_id_override: str = '', channel_id_override: str = '',
        from_datetime_override: str = '', overlap_hours_override: Optional[float] = None,
        source_name: str = '') -> int:
    cfg = load_config(config_path)
    timezone_name = get_local_timezone(cfg)
    out_dir = resolve_path(out_dir_override or cfg.get('paths', 'teams_out_dir', fallback='data/teams_download'))
    out_dir.mkdir(parents=True, exist_ok=True)
    state_p, checkpoint, final_jsonl, txt = paths(out_dir)

    mode = (mode_override or cfg.get('teams', 'mode', fallback='chat')).strip().lower()
    chat_id = (chat_id_override or cfg.get('teams', 'chat_id', fallback='')).strip()
    team_id = (team_id_override or cfg.get('teams', 'team_id', fallback='')).strip()
    channel_id = (channel_id_override or cfg.get('teams', 'channel_id', fallback='')).strip()
    if mode == 'chat' and (not chat_id or chat_id.startswith('INSERISCI_')):
        raise RuntimeError('Configura [teams] chat_id in config/config.ini')
    if mode == 'channel' and (not team_id or not channel_id):
        raise RuntimeError('Configura [teams] team_id e channel_id')

    signature = source_signature(mode, chat_id, team_id, channel_id)
    initial_from_dt = parse_iso_utc(from_datetime_override.strip() if from_datetime_override else cfg.get('teams', 'from_datetime', fallback='').strip())
    to_dt = parse_iso_utc(cfg.get('teams', 'to_datetime', fallback='').strip())
    incremental_enabled = cfg.getboolean('teams', 'incremental_enabled', fallback=True)
    overlap_hours = max(0.0, overlap_hours_override if overlap_hours_override is not None else cfg.getfloat('teams', 'overlap_hours', fallback=24.0))

    if reset_watermark:
        reset_source_watermark(cfg, signature)
        state_p.unlink(missing_ok=True)
        restart = True

    if rebuild_only:
        n = rebuild_outputs(checkpoint, final_jsonl, txt, initial_from_dt, to_dt, context_checkpoint=checkpoint, timezone_name=timezone_name)
        log(f'Output completi rigenerati dal checkpoint: {n} messaggi')
        return 0

    token = get_access_token(cfg)
    timeout = cfg.getint('graph', 'timeout_seconds', fallback=60)
    retries = cfg.getint('graph', 'max_retries', fallback=6)
    verify_ssl = cfg.getboolean('graph', 'verify_ssl', fallback=True)
    max_pages = cfg.getint('teams', 'max_pages', fallback=0)
    sleep_pages = cfg.getfloat('teams', 'sleep_between_pages', fallback=0)
    resume = cfg.getboolean('teams', 'resume', fallback=True)

    current_run_p = run_messages_path(out_dir)
    state = {} if restart else load_state(state_p)
    resume_ok = bool(
        resume and not restart and state.get('in_progress') and
        state.get('source_signature') == signature and state.get('next_link')
    )

    if resume_ok:
        url = state['next_link']
        page_no = int(state.get('page_no', 0))
        run_started_dt = parse_iso_utc(state.get('run_started_at')) or utc_now_dt()
        scan_upper = parse_iso_utc(state.get('scan_upper_bound')) or run_started_dt
        effective_since = parse_iso_utc(state.get('effective_since'))
        scan_mode = state.get('scan_mode', 'incremental' if effective_since else 'full')
        log(f'RESUME: riprendo dal nextLink salvato; scan_mode={scan_mode}, run_started_at={iso_z(run_started_dt)}')
    else:
        run_started_dt = utc_now_dt()
        scan_upper = min(run_started_dt, to_dt) if to_dt else run_started_dt
        committed_wm = get_source_watermark(cfg, signature) if incremental_enabled and mode == 'chat' else None
        if committed_wm is not None:
            effective_since = committed_wm - dt.timedelta(hours=overlap_hours)
            if initial_from_dt and effective_since < initial_from_dt:
                effective_since = initial_from_dt
            scan_mode = 'incremental'
            url = build_initial_url(cfg, mode, chat_id, team_id, channel_id, effective_since, scan_upper)
            log(
                f'INCREMENTALE: watermark={iso_z(committed_wm)}, overlap={overlap_hours:g}h, '
                f'effective_since={iso_z(effective_since)}, upper={iso_z(scan_upper)}'
            )
        else:
            effective_since = None
            scan_mode = 'full'
            url = build_initial_url(cfg, mode, chat_id, team_id, channel_id)
            log(f'PRIMO CARICAMENTO/FULL SCAN: from_datetime={iso_z(initial_from_dt) if initial_from_dt else "<nessun limite>"}')
        page_no = 0
        # Nuova scansione: azzera il journal del run. In caso di resume NON viene azzerato.
        current_run_p.write_text('', encoding='utf-8')
        state = {
            'source_signature': signature,
            'source_name': source_name,
            'mode': mode,
            'scan_mode': scan_mode,
            'run_started_at': iso_z(run_started_dt),
            'scan_upper_bound': iso_z(scan_upper),
            'effective_since': iso_z(effective_since) if effective_since else '',
            'initial_from_datetime': iso_z(initial_from_dt) if initial_from_dt else '',
            'overlap_hours': overlap_hours,
            'watermark_committed': False,
            'in_progress': True,
            'completed': False,
            'page_no': 0,
            'next_link': url,
        }
        save_state(state_p, state)

    versions = load_known_versions(checkpoint)
    total_received = int(state.get('total_received_this_run', 0)) if resume_ok else 0
    total_written = int(state.get('total_written_this_run', 0)) if resume_ok else 0
    total_unchanged = int(state.get('total_unchanged_this_run', 0)) if resume_ok else 0

    while url:
        page_no += 1
        data = graph_get_json(url, token, timeout, retries, verify_ssl)
        values = data.get('value') or []
        total_received += len(values)
        if mode == 'channel':
            normalized = collect_channel_page(values, cfg, token, timeout, retries, verify_ssl,
                                              chat_id, team_id, channel_id, source_name)
        else:
            normalized = [normalize_message(m, mode, chat_id, team_id, channel_id, source_name=source_name) for m in values]

        # Il limite storico configurato resta valido anche in incremental: non importare messaggi creati
        # prima del perimetro iniziale, pur se modificati oggi.
        in_scope = [m for m in normalized if created_in_scope(m, initial_from_dt, to_dt)]
        # Journal del run: salva tutti i messaggi restituiti da Graph nella finestra corrente.
        # Il checkpoint globale conserva invece soltanto le versioni nuove/modificate.
        append_run_messages(current_run_p, in_scope)
        written, unchanged = append_changed(checkpoint, in_scope, versions)
        total_written += written
        total_unchanged += unchanged

        next_link = data.get('@odata.nextLink')
        stop = False
        if scan_mode == 'full' and mode == 'chat' and initial_from_dt:
            # Full scan ordinato per createdDateTime desc: stop appena la pagina attraversa il limite inferiore.
            created = [parse_iso_utc(m.get('createdDateTime')) for m in normalized]
            created = [x for x in created if x is not None]
            if created and min(created) < initial_from_dt:
                stop = True

        state.update({
            'source_signature': signature,
            'source_name': source_name,
            'mode': mode,
            'scan_mode': scan_mode,
            'run_started_at': iso_z(run_started_dt),
            'scan_upper_bound': iso_z(scan_upper),
            'effective_since': iso_z(effective_since) if effective_since else '',
            'initial_from_datetime': iso_z(initial_from_dt) if initial_from_dt else '',
            'overlap_hours': overlap_hours,
            'next_link': None if stop else next_link,
            'page_no': page_no,
            'in_progress': bool(next_link and not stop),
            'completed': bool(stop or not next_link),
            'last_update': now_utc(),
            'last_page_received': len(values),
            'total_received_this_run': total_received,
            'total_written_this_run': total_written,
            'total_unchanged_this_run': total_unchanged,
            'stop_reason': 'older_than_initial_from_datetime' if stop else ('graph_completed' if not next_link else ''),
        })
        update_last_seen(state, in_scope)
        save_state(state_p, state)
        log(
            f'Pagina {page_no}: root={len(values)}, normalizzati={len(normalized)}, '
            f'in_scope={len(in_scope)}, nuovi/modificati={written}, invariati={unchanged}'
        )

        if stop or not next_link or (max_pages and page_no >= max_pages):
            if max_pages and page_no >= max_pages and next_link and not stop:
                state['in_progress'] = True
                state['completed'] = False
                state['next_link'] = next_link
                state['stop_reason'] = 'max_pages'
                save_state(state_p, state)
            break
        url = next_link
        if sleep_pages:
            time.sleep(sleep_pages)

    # Il file finale contiene esattamente i messaggi toccati nel run corrente.
    # Nel primo run equivale al FULL storico; nei run successivi è il DELTA restituito dal filtro
    # lastModifiedDateTime, con il checkpoint globale usato soltanto per ricostruire reply_context.
    n = rebuild_outputs(
        current_run_p, final_jsonl, txt, initial_from_dt, to_dt, context_checkpoint=checkpoint, timezone_name=timezone_name
    )
    state = load_state(state_p)
    if state.get('in_progress'):
        state.update({'completed': False, 'final_messages': n})
        save_state(state_p, state)
        log(f'Scansione parziale salvata (resume disponibile). JSONL corrente: {n} messaggi -> {final_jsonl}')
    else:
        # Watermark a due fasi: il collector propone il limite superiore della scansione, ma NON lo
        # conferma. run_pipeline lo committa solo dopo che SQLite/entità/contesti/eventi/chunk sono OK.
        state.update({
            'in_progress': False,
            'completed': True,
            'completed_at': now_utc(),
            'final_messages': n,
            'pending_watermark_utc': iso_z(scan_upper),
            'watermark_committed': False,
        })
        save_state(state_p, state)
        log(
            f'Download/scansione completata. JSONL {"DELTA" if scan_mode == "incremental" else "FULL"}: '
            f'{n} messaggi -> {final_jsonl}. Watermark PENDENTE={iso_z(scan_upper)}'
        )
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description='Collector Teams Microsoft Graph integrato - V4 incremental watermark')
    ap.add_argument('--config', default='config/config.ini')
    ap.add_argument('--restart', action='store_true', help='Ignora il nextLink salvato ma conserva il watermark committato')
    ap.add_argument('--reset-watermark', action='store_true', help='Cancella il watermark della sorgente e forza un full scan')
    ap.add_argument('--commit-watermark', action='store_true', help='Conferma il watermark pendente dopo il successo della pipeline core')
    ap.add_argument('--chat-id', default='', help='Override del chat_id configurato in config.ini')
    ap.add_argument('--source-name', default='', help='Nome descrittivo della sorgente salvato nei messaggi')
    ap.add_argument('--mode', choices=['chat','channel'], default='', help='Override della modalita sorgente')
    ap.add_argument('--team-id', default='', help='Override team_id per sorgenti channel')
    ap.add_argument('--channel-id', default='', help='Override channel_id per sorgenti channel')
    ap.add_argument('--out-dir', default='', help='Directory stato/checkpoint/output dedicata alla sorgente')
    ap.add_argument('--from-datetime', default='', help='Override del limite storico iniziale')
    ap.add_argument('--overlap-hours', type=float, default=None, help='Override overlap incrementale della sorgente')
    ap.add_argument('--rebuild-outputs', action='store_true', help='Rigenera output completi dal checkpoint senza chiamare Graph')
    args = ap.parse_args()
    try:
        if args.commit_watermark:
            return commit_pending_watermark(args.config, chat_id_override=args.chat_id, out_dir_override=args.out_dir,
                                            mode_override=args.mode, team_id_override=args.team_id, channel_id_override=args.channel_id)
        return run(
            args.config,
            restart=args.restart,
            rebuild_only=args.rebuild_outputs,
            chat_id_override=args.chat_id,
            reset_watermark=args.reset_watermark,
            out_dir_override=args.out_dir,
            mode_override=args.mode,
            team_id_override=args.team_id,
            channel_id_override=args.channel_id,
            from_datetime_override=args.from_datetime,
            overlap_hours_override=args.overlap_hours,
            source_name=args.source_name,
        )
    except KeyboardInterrupt:
        log('Interrotto: il checkpoint dell’ultima pagina completata resta disponibile e il watermark NON avanza.')
        return 130
    except Exception as exc:
        log(f'ERRORE: {exc}')
        return 1


if __name__ == '__main__':
    raise SystemExit(main())

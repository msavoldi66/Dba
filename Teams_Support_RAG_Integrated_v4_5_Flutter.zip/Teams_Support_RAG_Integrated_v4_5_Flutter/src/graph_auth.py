from __future__ import annotations

from pathlib import Path

from common import resolve_path


def _cfg(cfg, section: str, key: str, default: str = '') -> str:
    return cfg.get(section, key, fallback=default).strip()


def get_access_token(cfg) -> str:
    """Legge esclusivamente il bearer token Microsoft Graph fornito manualmente.

    La v4 non esegue alcun OAuth/MSAL/Device Code Flow e non tenta refresh automatici.
    Il token deve essere copiato dall'operatore nel file graph_access_token.txt
    (o nel percorso configurato in [graph] token_file).
    """
    token_file = _cfg(cfg, 'graph', 'token_file', 'graph_access_token.txt')
    if not token_file:
        token_file = 'graph_access_token.txt'

    p = resolve_path(token_file)
    if not p.exists():
        raise FileNotFoundError(
            f'Token Microsoft Graph non trovato: {p}. '
            'Crea graph_access_token.txt nella root del progetto e incolla il solo access token.'
        )

    token = p.read_text(encoding='utf-8-sig').strip()
    if not token:
        raise RuntimeError(
            f'Token Microsoft Graph mancante: {p} e vuoto. '
            'Incolla nel file il bearer access token, senza virgolette e senza prefisso "Bearer ".'
        )

    # Accetta per comodita anche un token copiato come "Bearer ey...", ma normalizza il valore.
    if token.lower().startswith('bearer '):
        token = token[7:].strip()

    if any(ch.isspace() for ch in token):
        raise RuntimeError(
            f'Il file {p} contiene spazi o righe aggiuntive. '
            'Deve contenere esclusivamente il token Graph su una sola riga.'
        )
    if token.upper().startswith(('INCOLLA_', 'INSERISCI_', 'TUO_')):
        raise RuntimeError(f'Il file {p} contiene ancora un valore segnaposto, non un access token valido.')

    return token

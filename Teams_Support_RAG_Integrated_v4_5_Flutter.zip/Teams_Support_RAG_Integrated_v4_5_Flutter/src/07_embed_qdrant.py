from __future__ import annotations

import argparse
import os
import requests
import uuid
from tqdm import tqdm

from common import load_config, connect_db, batched, json_loads_safe
from deepinfra_embed import embed_texts


def qdrant_request(method, url, **kwargs):
    r = requests.request(method, url, timeout=180, **kwargs)
    if r.status_code >= 400:
        raise RuntimeError(f'Qdrant HTTP {r.status_code}: {r.text[:1000]}')
    return r.json() if r.text else {}


def check_qdrant(base: str) -> bool:
    try:
        return requests.get(base.rstrip('/') + '/collections', timeout=8).status_code == 200
    except requests.RequestException:
        return False


def ensure_collection(qurl, collection, dim, recreate=False):
    base = qurl.rstrip('/')
    exists = requests.get(f'{base}/collections/{collection}', timeout=30)
    if exists.status_code == 200 and recreate:
        qdrant_request('DELETE', f'{base}/collections/{collection}')
        exists = None
    if exists is not None and exists.status_code == 200:
        try:
            actual = exists.json()['result']['config']['params']['vectors']['size']
        except Exception:
            actual = dim
        if int(actual) != int(dim):
            raise RuntimeError(f'Collection Qdrant {collection} dimensione={actual}, embedding dimensione={dim}. Usa --recreate-collection.')
        return
    body = {'vectors': {'size': dim, 'distance': 'Cosine'}}
    qdrant_request('PUT', f'{base}/collections/{collection}', json=body)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', default='config/config.ini')
    ap.add_argument('--limit', type=int, default=5000)
    ap.add_argument('--batch-size', type=int, default=16)
    ap.add_argument('--recreate-collection', action='store_true')
    args = ap.parse_args(); cfg = load_config(args.config)
    if not cfg.getboolean('qdrant', 'enabled', fallback=True):
        print('Qdrant disabilitato da config.'); return 0
    required = cfg.getboolean('qdrant', 'required', fallback=False)
    qurl = cfg['qdrant']['url'].rstrip('/')
    if not check_qdrant(qurl):
        msg = f'Qdrant non raggiungibile su {qurl}'
        if required: raise RuntimeError(msg)
        print(f'[SKIP] {msg}; ricerca exact/FTS resta disponibile.'); return 0
    env = cfg['llm']['api_key_env']
    if not os.environ.get(env, '').strip():
        msg = f'Variabile {env} non impostata: embedding non eseguibile'
        if required: raise RuntimeError(msg)
        print(f'[SKIP] {msg}; ricerca exact/FTS resta disponibile.'); return 0

    con = connect_db(cfg['paths']['sqlite_db'])
    rows = con.execute('SELECT * FROM rag_chunks WHERE embedded=0 ORDER BY start_ts LIMIT ?', (args.limit,)).fetchall()
    if not rows:
        print('Nessun chunk da embeddare'); return 0
    base_url = cfg['llm']['base_url']; model = cfg['llm']['embedding_model']; collection = cfg['qdrant']['collection']
    recreate = args.recreate_collection or cfg.getboolean('qdrant','recreate_collection',fallback=False)

    first_vec = embed_texts([rows[0]['text'][:8000]], model, base_url, env)[0]
    ensure_collection(qurl, collection, len(first_vec), recreate=recreate)

    done = 0
    for batch in tqdm(list(batched(rows, args.batch_size)), desc='Embedding + Qdrant upsert'):
        texts = [r['text'][:8000] for r in batch]; vecs = embed_texts(texts, model, base_url, env)
        points = []
        for r, v in zip(batch, vecs):
            payload = {'chunk_id':r['chunk_id'],'chunk_type':r['chunk_type'],'start_ts':r['start_ts'],'end_ts':r['end_ts'],
                       'text':r['text'],'entities':json_loads_safe(r['entities'],[]),'participants':json_loads_safe(r['participants'],[]),
                       'source_message_ids':json_loads_safe(r['source_message_ids'],[])}
            qid = str(uuid.uuid5(uuid.NAMESPACE_URL, r['chunk_id'])); points.append({'id':qid,'vector':v,'payload':payload})
        qdrant_request('PUT', f'{qurl}/collections/{collection}/points?wait=true', json={'points':points})
        for r in batch:
            qid = str(uuid.uuid5(uuid.NAMESPACE_URL, r['chunk_id']))
            con.execute('UPDATE rag_chunks SET embedded=1,qdrant_point_id=? WHERE chunk_id=?',(qid,r['chunk_id']))
        con.commit(); done += len(batch)
    print(f'Chunk embeddati/aggiornati: {done}'); return 0


if __name__ == '__main__': raise SystemExit(main())

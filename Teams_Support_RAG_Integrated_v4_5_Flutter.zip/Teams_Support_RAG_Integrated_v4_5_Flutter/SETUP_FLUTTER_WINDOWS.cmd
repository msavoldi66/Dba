@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo ====================================================================================
echo   SETUP FLUTTER WINDOWS - SUPPORT DB2 TEAMS RAG
 echo ====================================================================================
where flutter >nul 2>nul
if errorlevel 1 (
  echo [ERRORE] Flutter SDK non trovato nel PATH.
  echo Installa Flutter e Visual Studio con workload "Desktop development with C++".
  echo Poi verifica con: flutter doctor -v
  exit /b 1
)

flutter config --enable-windows-desktop
if errorlevel 1 exit /b 1

pushd flutter_app
if not exist "windows\CMakeLists.txt" (
  echo [SETUP] Genero il runner Windows nativo...
  flutter create --platforms=windows --project-name support_db2_teams_rag .
  if errorlevel 1 (popd & exit /b 1)
)

echo [SETUP] Recupero pacchetti Dart/Flutter...
flutter pub get
if errorlevel 1 (popd & exit /b 1)

flutter doctor -v
popd

echo.
echo [OK] Ambiente Flutter Windows pronto.
endlocal

# Changelog v4.2.0

## Elenco completo delle sorgenti Microsoft Teams

`LIST_TEAMS_SOURCES.cmd` ora permette di individuare direttamente chat, Team e channel utilizzando il token manuale presente in `graph_access_token.txt`.

Modalita disponibili:

```bat
LIST_TEAMS_SOURCES.cmd
LIST_TEAMS_SOURCES.cmd chats
LIST_TEAMS_SOURCES.cmd teams
LIST_TEAMS_SOURCES.cmd channels
LIST_TEAMS_SOURCES.cmd channels <TEAM_ID>
LIST_TEAMS_SOURCES.cmd csv
```

La modalita `channels` senza Team ID esegue automaticamente:

1. `GET /me/joinedTeams`;
2. per ogni Team accessibile, `GET /teams/{team-id}/channels`;
3. stampa una tabella con nome Team, nome channel, membership type, Team ID e Channel ID.

La modalita `csv` crea inoltre `exports/teams_graph_sources.csv` con chat, Team e channel.

Gli errori su un singolo Team non interrompono l'elenco degli altri Team: vengono riportati come warning alla fine.

Nessuna modifica alla pipeline operativa `RUN_ALL.cmd`, al watermark incrementale o al modello dati SQLite rispetto alla v4.1.

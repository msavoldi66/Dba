@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" call SETUP_ONLY.cmd
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe src\run_pipeline.py --config config\config.ini --no-streamlit %*
endlocal

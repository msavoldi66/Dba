@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  where py >nul 2>nul && (py -3 -m venv .venv) || (python -m venv .venv)
)
.venv\Scripts\python.exe -m pip install --upgrade pip
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 exit /b 1
if not exist ".env" copy /Y .env.example .env >nul
if not exist "config\config.ini" copy /Y config\config.ini.example config\config.ini >nul
if not exist "config\teams_sources.csv" copy /Y config\teams_sources.csv.example config\teams_sources.csv >nul
if not exist "graph_access_token.txt" type nul > graph_access_token.txt
echo Setup Python/FastAPI completato.
echo Per Flutter Windows esegui SETUP_FLUTTER_WINDOWS.cmd.
endlocal

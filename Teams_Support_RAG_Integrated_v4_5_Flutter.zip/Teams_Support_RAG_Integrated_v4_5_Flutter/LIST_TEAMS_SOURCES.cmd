@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set PYTHONUTF8=1
set "PY=.venv\Scripts\python.exe"

if not exist "%PY%" (
  echo Ambiente non inizializzato. Esegui prima SETUP_ONLY.cmd oppure RUN_ALL.cmd.
  exit /b 1
)
if not exist "graph_access_token.txt" (
  echo File graph_access_token.txt non trovato.
  exit /b 1
)

rem V4.2:
rem   LIST_TEAMS_SOURCES.cmd              = chat + Team + channel
rem   LIST_TEAMS_SOURCES.cmd chats        = solo chat
rem   LIST_TEAMS_SOURCES.cmd teams        = solo Team
rem   LIST_TEAMS_SOURCES.cmd channels     = channel di tutti i Team accessibili
rem   LIST_TEAMS_SOURCES.cmd channels ID  = channel del solo Team ID
rem   LIST_TEAMS_SOURCES.cmd csv          = tutto + export CSV in exports\teams_graph_sources.csv

if /I "%~1"=="chats" (
  "%PY%" tools\list_graph_sources.py --config config\config.ini --chats
  goto :done
)

if /I "%~1"=="teams" (
  "%PY%" tools\list_graph_sources.py --config config\config.ini --teams
  goto :done
)

if /I "%~1"=="channels" (
  if "%~2"=="" (
    "%PY%" tools\list_graph_sources.py --config config\config.ini --channels
  ) else (
    "%PY%" tools\list_graph_sources.py --config config\config.ini --channels --team-id "%~2"
  )
  goto :done
)

if /I "%~1"=="csv" (
  "%PY%" tools\list_graph_sources.py --config config\config.ini --all --csv exports\teams_graph_sources.csv
  goto :done
)

"%PY%" tools\list_graph_sources.py --config config\config.ini --all

:done
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" echo [ERRORE] LIST_TEAMS_SOURCES terminato con rc=%RC%
endlocal & exit /b %RC%

import 'package:flutter_test/flutter_test.dart';
import 'package:support_db2_teams_rag/app.dart';

void main() {
  testWidgets('app builds', (tester) async {
    await tester.pumpWidget(const SupportRagApp());
    expect(find.text('Support DB2 Teams RAG'), findsWidgets);
  });
}

import 'dart:async';
import 'package:fluent_ui/fluent_ui.dart';
import 'services/api_service.dart';
import 'pages/dashboard_page.dart';
import 'pages/rag_page.dart';
import 'pages/messages_page.dart';
import 'pages/events_page.dart';
import 'pages/entities_page.dart';
import 'pages/sources_page.dart';
import 'pages/history_page.dart';
import 'pages/system_page.dart';

class SupportRagApp extends StatefulWidget {
  const SupportRagApp({super.key});
  @override
  State<SupportRagApp> createState() => _SupportRagAppState();
}

class _SupportRagAppState extends State<SupportRagApp> {
  bool dark = true;
  @override
  Widget build(BuildContext context) {
    return FluentApp(
      title: 'Support DB2 Teams RAG',
      debugShowCheckedModeBanner: false,
      themeMode: dark ? ThemeMode.dark : ThemeMode.light,
      theme: FluentThemeData(accentColor: Colors.blue, brightness: Brightness.light),
      darkTheme: FluentThemeData(accentColor: Colors.blue, brightness: Brightness.dark),
      home: AppShell(dark: dark, onThemeChanged: (v) => setState(() => dark = v)),
    );
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key, required this.dark, required this.onThemeChanged});
  final bool dark;
  final ValueChanged<bool> onThemeChanged;
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  final api = ApiService();
  int index = 0;
  bool backendOk = false;
  Timer? healthTimer;

  @override
  void initState() {
    super.initState();
    _health();
    healthTimer = Timer.periodic(const Duration(seconds: 10), (_) => _health());
  }

  @override
  void dispose() {
    healthTimer?.cancel();
    super.dispose();
  }

  Future<void> _health() async {
    try {
      final h = await api.getJson('/health');
      if (mounted) setState(() => backendOk = h['ok'] == true && h['db_ok'] == true);
    } catch (_) {
      if (mounted) setState(() => backendOk = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final items = <NavigationPaneItem>[
      PaneItem(icon: const Icon(FluentIcons.home), title: const Text('Dashboard'), body: DashboardPage(api: api)),
      PaneItem(icon: const Icon(FluentIcons.robot), title: const Text('Assistente RAG'), body: RagPage(api: api)),
      PaneItem(icon: const Icon(FluentIcons.message), title: const Text('Messaggi'), body: MessagesPage(api: api)),
      PaneItem(icon: const Icon(FluentIcons.timeline), title: const Text('Eventi'), body: EventsPage(api: api)),
      PaneItem(icon: const Icon(FluentIcons.tag), title: const Text('Entità'), body: EntitiesPage(api: api)),
      PaneItem(icon: const Icon(FluentIcons.group), title: const Text('Sorgenti Teams'), body: SourcesPage(api: api)),
      PaneItem(icon: const Icon(FluentIcons.history), title: const Text('Cronologia Q&A'), body: HistoryPage(api: api)),
    ];
    final footer = <NavigationPaneItem>[
      PaneItem(icon: const Icon(FluentIcons.server_processes), title: const Text('Pipeline & Sistema'), body: SystemPage(api: api)),
    ];

    return NavigationView(
      titleBar: TitleBar(
        title: const Text('Support DB2 Teams RAG'),
        content: Row(mainAxisAlignment: MainAxisAlignment.end, children: [
          InfoBadge(
            color: backendOk ? Colors.green.normal : Colors.red.normal,
            source: Text(backendOk ? 'Backend online' : 'Backend offline'),
          ),
          const SizedBox(width: 12),
          ToggleSwitch(checked: widget.dark, content: const Text('Tema scuro'), onChanged: widget.onThemeChanged),
          const SizedBox(width: 12),
        ]),
      ),
      pane: NavigationPane(
        selected: index,
        onChanged: (i) => setState(() => index = i),
        displayMode: PaneDisplayMode.auto,
        header: const Padding(
          padding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          child: Row(children: [Icon(FluentIcons.database, size: 22), SizedBox(width: 10), Expanded(child: Text('DB2 Teams Knowledge'))]),
        ),
        items: items,
        footerItems: footer,
      ),
    );
  }
}

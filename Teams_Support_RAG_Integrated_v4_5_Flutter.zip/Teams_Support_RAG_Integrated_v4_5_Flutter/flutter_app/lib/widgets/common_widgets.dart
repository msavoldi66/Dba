import 'package:fluent_ui/fluent_ui.dart';
import 'package:intl/intl.dart';

String fmtNumber(dynamic n) {
  final value = n is num ? n : num.tryParse('$n') ?? 0;
  return NumberFormat.decimalPattern('it_IT').format(value);
}

String shortText(dynamic value, [int max = 180]) {
  final s = (value ?? '').toString().replaceAll(RegExp(r'\s+'), ' ').trim();
  if (s.length <= max) return s;
  return '${s.substring(0, max)}…';
}

Color scoreColor(BuildContext context, dynamic value) {
  final n = value is num ? value.toInt() : int.tryParse('$value') ?? 0;
  if (n >= 80) return Colors.red.normal;
  if (n >= 60) return Colors.orange.normal;
  if (n >= 40) return Colors.yellow.dark;
  return FluentTheme.of(context).accentColor.normal;
}

class StatCard extends StatelessWidget {
  const StatCard({super.key, required this.title, required this.value, required this.icon, this.subtitle});
  final String title;
  final String value;
  final IconData icon;
  final String? subtitle;

  @override
  Widget build(BuildContext context) {
    final theme = FluentTheme.of(context);
    return Card(
      padding: const EdgeInsets.all(16),
      borderRadius: BorderRadius.circular(12),
      child: Row(
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: theme.accentColor.normal.withValues(alpha: .14),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: theme.accentColor.normal),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(title, style: theme.typography.caption),
                const SizedBox(height: 2),
                Text(value, style: theme.typography.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
                if (subtitle != null) ...[
                  const SizedBox(height: 2),
                  Text(subtitle!, style: theme.typography.caption),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class SectionHeader extends StatelessWidget {
  const SectionHeader(this.title, {super.key, this.icon, this.trailing});
  final String title;
  final IconData? icon;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        if (icon != null) ...[Icon(icon, size: 18), const SizedBox(width: 8)],
        Expanded(child: Text(title, style: FluentTheme.of(context).typography.subtitle)),
        if (trailing != null) trailing!,
      ],
    );
  }
}

class SourceBadge extends StatelessWidget {
  const SourceBadge(this.text, {super.key});
  final String text;
  @override
  Widget build(BuildContext context) {
    final theme = FluentTheme.of(context);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: theme.accentColor.normal.withValues(alpha: .12),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(text.isEmpty ? 'legacy' : text, style: theme.typography.caption),
    );
  }
}

class EmptyState extends StatelessWidget {
  const EmptyState({super.key, required this.title, this.description, this.icon = FluentIcons.search_issue});
  final String title;
  final String? description;
  final IconData icon;
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 42, color: FluentTheme.of(context).resources.textFillColorSecondary),
            const SizedBox(height: 12),
            Text(title, style: FluentTheme.of(context).typography.subtitle),
            if (description != null) ...[
              const SizedBox(height: 6),
              Text(description!, textAlign: TextAlign.center, style: FluentTheme.of(context).typography.body),
            ],
          ],
        ),
      ),
    );
  }
}

class LoadingPane extends StatelessWidget {
  const LoadingPane({super.key, this.text = 'Caricamento…'});
  final String text;
  @override
  Widget build(BuildContext context) => Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [const ProgressRing(), const SizedBox(height: 12), Text(text)],
        ),
      );
}

Future<void> showErrorDialog(BuildContext context, Object error) async {
  await showDialog<void>(
    context: context,
    builder: (context) => ContentDialog(
      title: const Text('Errore'),
      content: SelectableText(error.toString()),
      actions: [FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Chiudi'))],
    ),
  );
}

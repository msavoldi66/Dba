import 'package:fluent_ui/fluent_ui.dart';
import '../services/api_service.dart';
import 'common_widgets.dart';
import 'message_detail_dialog.dart';

Future<void> showEventDetail(BuildContext context, ApiService api, String eventId) async {
  await showDialog<void>(
    context: context,
    builder: (context) => _EventDetail(api: api, eventId: eventId),
  );
}

class _EventDetail extends StatefulWidget {
  const _EventDetail({required this.api, required this.eventId});
  final ApiService api;
  final String eventId;
  @override
  State<_EventDetail> createState() => _EventDetailState();
}

class _EventDetailState extends State<_EventDetail> {
  Map<String, dynamic>? data;
  Object? error;
  @override
  void initState() {
    super.initState();
    widget.api.getJson('/events/${Uri.encodeComponent(widget.eventId)}').then((v) {
      if (mounted) setState(() => data = v);
    }).catchError((e) {
      if (mounted) setState(() => error = e);
    });
  }

  @override
  Widget build(BuildContext context) {
    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 900, maxHeight: 720),
      title: const Text('Dettaglio evento'),
      content: error != null
          ? Text(error.toString())
          : data == null
              ? const SizedBox(height: 280, child: LoadingPane())
              : _body(context),
      actions: [FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Chiudi'))],
    );
  }

  Widget _body(BuildContext context) {
    final event = Map<String, dynamic>.from(data!['event'] ?? {});
    final msgs = List<Map<String, dynamic>>.from((data!['messages'] ?? []).map((e) => Map<String, dynamic>.from(e)));
    return SingleChildScrollView(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Wrap(spacing: 8, children: [
          SourceBadge('${event['source_name'] ?? ''}'),
          InfoBadge(source: Text('${event['event_type'] ?? ''}')),
          if ((event['status'] ?? '').toString().isNotEmpty) InfoBadge(source: Text('${event['status']}')),
        ]),
        const SizedBox(height: 12),
        Text('${event['title'] ?? ''}', style: FluentTheme.of(context).typography.title),
        const SizedBox(height: 6),
        Text('${event['start_ts'] ?? ''}  →  ${event['end_ts'] ?? ''}'),
        const SizedBox(height: 12),
        SelectableText('${event['summary'] ?? ''}'),
        if ((event['participants'] ?? '').toString().isNotEmpty) ...[
          const SizedBox(height: 10),
          Text('Partecipanti: ${event['participants']}'),
        ],
        if ((event['entities'] ?? '').toString().isNotEmpty) ...[
          const SizedBox(height: 6),
          Text('Entità: ${event['entities']}'),
        ],
        const SizedBox(height: 18),
        const SectionHeader('Messaggi dell’evento', icon: FluentIcons.message),
        const SizedBox(height: 8),
        ...msgs.map((m) => Container(
              margin: const EdgeInsets.only(bottom: 7),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: FluentTheme.of(context).resources.subtleFillColorSecondary,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(children: [
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${m['created_ts']} • ${m['author']}', style: FluentTheme.of(context).typography.caption),
                    const SizedBox(height: 4),
                    Text(shortText(m['text'], 350)),
                  ]),
                ),
                IconButton(
                  icon: const Icon(FluentIcons.open_in_new_window),
                  onPressed: () => showMessageDetail(context, widget.api, '${m['message_id']}'),
                ),
              ]),
            )),
      ]),
    );
  }
}

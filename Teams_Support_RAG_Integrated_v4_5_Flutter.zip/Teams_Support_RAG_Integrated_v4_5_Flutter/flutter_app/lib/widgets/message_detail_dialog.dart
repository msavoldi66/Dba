import 'package:fluent_ui/fluent_ui.dart';
import '../services/api_service.dart';
import 'common_widgets.dart';

Future<void> showMessageDetail(BuildContext context, ApiService api, String messageId) async {
  await showDialog<void>(
    context: context,
    barrierDismissible: true,
    builder: (context) => _MessageDetail(api: api, messageId: messageId),
  );
}

class _MessageDetail extends StatefulWidget {
  const _MessageDetail({required this.api, required this.messageId});
  final ApiService api;
  final String messageId;

  @override
  State<_MessageDetail> createState() => _MessageDetailState();
}

class _MessageDetailState extends State<_MessageDetail> {
  Map<String, dynamic>? data;
  Object? error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final d = await widget.api.getJson('/messages/${Uri.encodeComponent(widget.messageId)}');
      if (mounted) setState(() => data = d);
    } catch (e) {
      if (mounted) setState(() => error = e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ContentDialog(
      constraints: const BoxConstraints(maxWidth: 920, maxHeight: 760),
      title: const Text('Dettaglio messaggio Teams'),
      content: error != null
          ? SelectableText(error.toString())
          : data == null
              ? const SizedBox(height: 300, child: LoadingPane())
              : _content(context),
      actions: [FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Chiudi'))],
    );
  }

  Widget _content(BuildContext context) {
    final msg = Map<String, dynamic>.from(data!['message'] ?? {});
    final entities = List<Map<String, dynamic>>.from((data!['entities'] ?? []).map((e) => Map<String, dynamic>.from(e)));
    final analyses = List<Map<String, dynamic>>.from((data!['analyses'] ?? []).map((e) => Map<String, dynamic>.from(e)));
    final contextMessages = List<Map<String, dynamic>>.from((data!['context_messages'] ?? []).map((e) => Map<String, dynamic>.from(e)));
    final events = List<Map<String, dynamic>>.from((data!['events'] ?? []).map((e) => Map<String, dynamic>.from(e)));
    final analysis = analyses.isEmpty ? <String, dynamic>{} : analyses.first;

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(spacing: 8, runSpacing: 8, children: [
            SourceBadge('${msg['source_name'] ?? ''}'),
            InfoBadge(source: Text('Score ${msg['operational_score'] ?? 0}')),
            if ((analysis['category'] ?? '').toString().isNotEmpty) InfoBadge(source: Text('${analysis['category']}')),
            if ((analysis['urgency'] ?? '').toString().isNotEmpty) InfoBadge(source: Text('Urgenza ${analysis['urgency']}')),
          ]),
          const SizedBox(height: 12),
          Text('${msg['created_ts'] ?? ''}  •  ${msg['author'] ?? ''}', style: FluentTheme.of(context).typography.subtitle),
          const SizedBox(height: 12),
          SelectableText('${msg['text'] ?? ''}'),
          if ((msg['reply_to_text'] ?? '').toString().isNotEmpty) ...[
            const SizedBox(height: 14),
            InfoBar(
              title: Text('In risposta a ${msg['reply_to_author'] ?? ''}'),
              content: SelectableText('${msg['reply_to_text']}'),
              severity: InfoBarSeverity.info,
            ),
          ],
          if ((msg['reaction_summary'] ?? '').toString().isNotEmpty) ...[
            const SizedBox(height: 10),
            Text('Reazioni: ${msg['reaction_summary']}'),
          ],
          if (analysis.isNotEmpty) ...[
            const SizedBox(height: 18),
            const SectionHeader('Analisi LLM', icon: FluentIcons.robot),
            const SizedBox(height: 8),
            _kv('Sintesi', analysis['short_summary']),
            _kv('Sintesi operativa', analysis['operational_summary']),
            _kv('Problema rilevato', analysis['problem_detected']),
            _kv('Azione proposta', analysis['proposed_action']),
            _kv('Decisione', analysis['decision_taken']),
            _kv('Stato', analysis['status']),
            _kv('Follow-up', analysis['requires_followup']),
          ],
          if (entities.isNotEmpty) ...[
            const SizedBox(height: 18),
            const SectionHeader('Entità estratte', icon: FluentIcons.tag),
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: entities
                  .map((e) => InfoBadge(source: Text('${e['entity_type']}: ${e['entity_value']}')))
                  .toList(),
            ),
          ],
          if (events.isNotEmpty) ...[
            const SizedBox(height: 18),
            const SectionHeader('Eventi associati', icon: FluentIcons.timeline),
            ...events.map((e) => Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text('• ${e['title']}  (${e['start_ts']} - ${e['end_ts']})'),
                )),
          ],
          if (contextMessages.isNotEmpty) ...[
            const SizedBox(height: 18),
            const SectionHeader('Contesto prima/dopo', icon: FluentIcons.chat),
            const SizedBox(height: 6),
            ...contextMessages.map((m) => Container(
                  margin: const EdgeInsets.only(bottom: 6),
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: FluentTheme.of(context).resources.subtleFillColorSecondary,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('${m['created_ts']} • ${m['author']}', style: FluentTheme.of(context).typography.caption),
                      const SizedBox(height: 4),
                      SelectableText('${m['text'] ?? ''}'),
                    ],
                  ),
                )),
          ],
        ],
      ),
    );
  }

  Widget _kv(String key, dynamic value) {
    if (value == null || value.toString().trim().isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(bottom: 7),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(width: 150, child: Text(key, style: const TextStyle(fontWeight: FontWeight.w600))),
        Expanded(child: SelectableText(value.toString())),
      ]),
    );
  }
}

import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiException implements Exception {
  final String message;
  final int? statusCode;
  ApiException(this.message, [this.statusCode]);
  @override
  String toString() => message;
}

class ApiService {
  ApiService({this.baseUrl = 'http://127.0.0.1:8765/api'});
  final String baseUrl;

  Uri _uri(String path, [Map<String, dynamic>? params]) {
    final uri = Uri.parse('$baseUrl$path');
    if (params == null) return uri;
    final query = <String, String>{};
    for (final entry in params.entries) {
      final value = entry.value;
      if (value == null) continue;
      if (value is String && value.trim().isEmpty) continue;
      query[entry.key] = value.toString();
    }
    return uri.replace(queryParameters: query);
  }

  Future<Map<String, dynamic>> getJson(String path, {Map<String, dynamic>? params}) async {
    try {
      final response = await http.get(_uri(path, params)).timeout(const Duration(seconds: 30));
      return _decode(response);
    } catch (e) {
      if (e is ApiException) rethrow;
      throw ApiException('API non raggiungibile: $e');
    }
  }

  Future<Map<String, dynamic>> postJson(String path, Map<String, dynamic> body, {Duration? timeout}) async {
    try {
      final response = await http
          .post(
            _uri(path),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode(body),
          )
          .timeout(timeout ?? const Duration(minutes: 5));
      return _decode(response);
    } catch (e) {
      if (e is ApiException) rethrow;
      throw ApiException('Errore chiamata API: $e');
    }
  }

  Map<String, dynamic> _decode(http.Response response) {
    Map<String, dynamic> data = {};
    if (response.body.isNotEmpty) {
      final decoded = jsonDecode(utf8.decode(response.bodyBytes));
      if (decoded is Map<String, dynamic>) data = decoded;
    }
    if (response.statusCode >= 400) {
      final detail = data['detail']?.toString() ?? 'HTTP ${response.statusCode}';
      throw ApiException(detail, response.statusCode);
    }
    return data;
  }
}

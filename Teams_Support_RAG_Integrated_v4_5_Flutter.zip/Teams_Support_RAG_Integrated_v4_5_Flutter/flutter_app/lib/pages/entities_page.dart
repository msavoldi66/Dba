import 'package:fluent_ui/fluent_ui.dart';
import '../services/api_service.dart';
import '../widgets/common_widgets.dart';

class EntitiesPage extends StatefulWidget {
  const EntitiesPage({super.key, required this.api});
  final ApiService api;
  @override
  State<EntitiesPage> createState() => _EntitiesPageState();
}

class _EntitiesPageState extends State<EntitiesPage> {
  final search = TextEditingController();
  String type = '';
  List<String> types = [];
  List<Map<String, dynamic>> items = [];
  bool loading = false;
  Object? error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final d = await widget.api.getJson('/entities', params: {'q': search.text.trim(), 'entity_type': type, 'limit': 500});
      if (mounted) {
        setState(() {
          items = List<Map<String, dynamic>>.from((d['items'] ?? []).map((e) => Map<String, dynamic>.from(e)));
          types = List<Map<String, dynamic>>.from((d['types'] ?? []).map((e) => Map<String, dynamic>.from(e)))
              .map((e) => '${e['entity_type']}')
              .where((e) => e.isNotEmpty)
              .toList();
        });
      }
    } catch (e) {
      if (mounted) setState(() => error = e);
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ScaffoldPage(
      header: const PageHeader(title: Text('Entità tecniche estratte')),
      content: Column(children: [
        Card(
          child: Row(children: [
            Expanded(child: TextBox(controller: search, placeholder: 'DB2 subsystem, SQLCODE, JOB, INC, PTASK, programma…', onSubmitted: (_) => _load())),
            const SizedBox(width: 10),
            SizedBox(
              width: 220,
              child: ComboBox<String>(
                value: type,
                isExpanded: true,
                items: [const ComboBoxItem(value: '', child: Text('Tutti i tipi')), ...types.map((t) => ComboBoxItem(value: t, child: Text(t)))],
                onChanged: (v) => setState(() => type = v ?? ''),
              ),
            ),
            const SizedBox(width: 10),
            FilledButton(onPressed: loading ? null : _load, child: const Text('Cerca')),
          ]),
        ),
        const SizedBox(height: 10),
        if (error != null) InfoBar(title: const Text('Errore'), content: Text(error.toString()), severity: InfoBarSeverity.error),
        Expanded(
          child: loading && items.isEmpty
              ? const LoadingPane()
              : items.isEmpty
                  ? const EmptyState(title: 'Nessuna entità trovata')
                  : GridView.builder(
                      gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 360, mainAxisExtent: 110, crossAxisSpacing: 10, mainAxisSpacing: 10),
                      itemCount: items.length,
                      itemBuilder: (context, i) {
                        final e = items[i];
                        return Card(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Row(children: [
                              InfoBadge(source: Text('${e['entity_type'] ?? ''}')),
                              const Spacer(),
                              Text('${fmtNumber(e['message_count'])} msg', style: FluentTheme.of(context).typography.caption),
                            ]),
                            const SizedBox(height: 10),
                            SelectableText('${e['entity_value'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.w600)),
                            const Spacer(),
                            Text('${fmtNumber(e['count'])} occorrenze', style: FluentTheme.of(context).typography.caption),
                          ]),
                        );
                      },
                    ),
        ),
      ]),
    );
  }
}

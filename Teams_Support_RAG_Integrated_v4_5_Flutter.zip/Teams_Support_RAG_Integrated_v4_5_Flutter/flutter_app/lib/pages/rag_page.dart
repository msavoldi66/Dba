import 'package:fluent_ui/fluent_ui.dart';
import '../services/api_service.dart';
import '../widgets/common_widgets.dart';
import '../widgets/message_detail_dialog.dart';

class RagPage extends StatefulWidget {
  const RagPage({super.key, required this.api});
  final ApiService api;
  @override
  State<RagPage> createState() => _RagPageState();
}

class _RagPageState extends State<RagPage> {
  final question = TextEditingController();
  bool loading = false;
  Map<String, dynamic>? result;
  Object? error;
  double topK = 8;
  double threshold = .20;

  Future<void> _ask() async {
    final q = question.text.trim();
    if (q.isEmpty) return;
    setState(() {
      loading = true;
      error = null;
      result = null;
    });
    try {
      final d = await widget.api.postJson('/rag/ask', {
        'question': q,
        'top_k': topK.round(),
        'threshold': threshold,
      }, timeout: const Duration(minutes: 5));
      if (mounted) setState(() => result = d);
    } catch (e) {
      if (mounted) setState(() => error = e);
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final messages = _maps(result?['messages']);
    final contextMessages = _maps(result?['context_messages']);
    final chunks = _maps(result?['chunks']);
    final exact = List<dynamic>.from(result?['exact_terms'] ?? []);

    return ScaffoldPage.scrollable(
      header: const PageHeader(title: Text('Assistente RAG DB2 / Teams')),
      children: [
        Card(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Interroga la knowledge base', style: FluentTheme.of(context).typography.subtitle),
            const SizedBox(height: 8),
            TextBox(
              controller: question,
              minLines: 3,
              maxLines: 6,
              placeholder: 'Esempio: cosa è successo per INC024759656? Quali decisioni sono state prese?',
              onSubmitted: (_) => _ask(),
            ),
            const SizedBox(height: 12),
            Wrap(spacing: 18, runSpacing: 10, crossAxisAlignment: WrapCrossAlignment.center, children: [
              SizedBox(
                width: 240,
                child: Row(children: [
                  const Text('Top K'),
                  Expanded(child: Slider(value: topK, min: 1, max: 30, divisions: 29, label: '${topK.round()}', onChanged: (v) => setState(() => topK = v))),
                  SizedBox(width: 28, child: Text('${topK.round()}')),
                ]),
              ),
              SizedBox(
                width: 300,
                child: Row(children: [
                  const Text('Soglia'),
                  Expanded(child: Slider(value: threshold, min: 0, max: 1, divisions: 20, label: threshold.toStringAsFixed(2), onChanged: (v) => setState(() => threshold = v))),
                  SizedBox(width: 40, child: Text(threshold.toStringAsFixed(2))),
                ]),
              ),
              FilledButton(
                onPressed: loading ? null : _ask,
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  if (loading) ...[const SizedBox(width: 16, height: 16, child: ProgressRing(strokeWidth: 2)), const SizedBox(width: 8)] else const Icon(FluentIcons.search),
                  const SizedBox(width: 7),
                  Text(loading ? 'Ricerca in corso…' : 'Esegui domanda'),
                ]),
              ),
              Button(onPressed: () => question.clear(), child: const Text('Pulisci')),
            ]),
          ]),
        ),
        if (error != null) ...[
          const SizedBox(height: 12),
          InfoBar(title: const Text('Errore RAG'), content: SelectableText(error.toString()), severity: InfoBarSeverity.error),
        ],
        if (result != null) ...[
          const SizedBox(height: 14),
          if (exact.isNotEmpty)
            InfoBar(
              title: const Text('Termini tecnici riconosciuti'),
              content: Text(exact.join(', ')),
              severity: InfoBarSeverity.info,
            ),
          if ((result!['qdrant_error'] ?? '').toString().isNotEmpty) ...[
            const SizedBox(height: 8),
            InfoBar(
              title: const Text('Qdrant non disponibile'),
              content: Text('${result!['qdrant_error']}'),
              severity: InfoBarSeverity.warning,
            ),
          ],
          const SizedBox(height: 12),
          Card(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                const Icon(FluentIcons.robot),
                const SizedBox(width: 8),
                Text('Risposta', style: FluentTheme.of(context).typography.subtitle),
                const Spacer(),
                Text('${result!['elapsed_ms'] ?? 0} ms', style: FluentTheme.of(context).typography.caption),
              ]),
              const SizedBox(height: 14),
              SelectionArea(child: Text('${result!['answer'] ?? ''}', style: const TextStyle(fontSize: 15, height: 1.5))),
            ]),
          ),
          const SizedBox(height: 12),
          Expander(
            header: Text('Fonti messaggi SQLite / FTS (${messages.length})'),
            initiallyExpanded: true,
            content: messages.isEmpty
                ? const Text('Nessun messaggio exact/FTS.')
                : Column(children: messages.take(40).map((item) {
                    final msg = Map<String, dynamic>.from(item['message'] ?? {});
                    return ListTile.selectable(
                      title: Row(children: [
                        Expanded(child: Text('${msg['author'] ?? ''} • ${msg['created_ts'] ?? ''}')),
                        SourceBadge('${msg['source_name'] ?? ''}'),
                      ]),
                      subtitle: Text(shortText(msg['text'], 360)),
                      trailing: const Icon(FluentIcons.open_in_new_window),
                      onPressed: () => showMessageDetail(context, widget.api, '${msg['message_id']}'),
                    );
                  }).toList()),
          ),
          const SizedBox(height: 8),
          Expander(
            header: Text('Contesto prima/dopo (${contextMessages.length})'),
            content: Column(
              children: contextMessages.take(60).map((m) => ListTile(
                    title: Text('${m['author'] ?? ''} • ${m['created_ts'] ?? ''}'),
                    subtitle: Text(shortText(m['text'], 380)),
                  )).toList(),
            ),
          ),
          const SizedBox(height: 8),
          Expander(
            header: Text('Chunk RAG / Qdrant (${chunks.length})'),
            content: Column(
              children: chunks.take(20).map((ch) {
                final p = Map<String, dynamic>.from(ch['payload'] ?? {});
                return Card(
                  margin: const EdgeInsets.only(bottom: 7),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${p['start_ts'] ?? ''} → ${p['end_ts'] ?? ''} • ${p['chunk_type'] ?? ''} • score ${ch['score'] ?? ''}', style: FluentTheme.of(context).typography.caption),
                    const SizedBox(height: 5),
                    SelectableText(shortText(p['text'], 900)),
                  ]),
                );
              }).toList(),
            ),
          ),
        ],
      ],
    );
  }

  List<Map<String, dynamic>> _maps(dynamic v) =>
      List<Map<String, dynamic>>.from((v ?? []).map((e) => Map<String, dynamic>.from(e)));
}

import 'dart:async';
import 'dart:convert';
import 'package:fluent_ui/fluent_ui.dart';
import '../services/api_service.dart';
import '../widgets/common_widgets.dart';

class SystemPage extends StatefulWidget {
  const SystemPage({super.key, required this.api});
  final ApiService api;
  @override
  State<SystemPage> createState() => _SystemPageState();
}

class _SystemPageState extends State<SystemPage> {
  Map<String, dynamic>? status;
  Map<String, dynamic>? pipeline;
  Object? error;
  bool loading = true;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    _refreshAll();
    timer = Timer.periodic(const Duration(seconds: 3), (_) => _refreshPipeline());
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> _refreshAll() async {
    setState(() => loading = true);
    try {
      final s = await widget.api.getJson('/system/status');
      final p = await widget.api.getJson('/pipeline/status');
      if (mounted) setState(() {
        status = s;
        pipeline = p;
        error = null;
      });
    } catch (e) {
      if (mounted) setState(() => error = e);
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _refreshPipeline() async {
    try {
      final p = await widget.api.getJson('/pipeline/status');
      if (mounted) setState(() => pipeline = p);
    } catch (_) {}
  }

  Future<void> _start(Map<String, dynamic> options) async {
    try {
      await widget.api.postJson('/pipeline/start', options);
      await _refreshPipeline();
    } catch (e) {
      if (mounted) await showErrorDialog(context, e);
    }
  }

  Future<bool> _confirm(String title, String body) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => ContentDialog(
        title: Text(title),
        content: Text(body),
        actions: [
          Button(onPressed: () => Navigator.pop(context, false), child: const Text('Annulla')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Conferma')),
        ],
      ),
    );
    return result == true;
  }

  @override
  Widget build(BuildContext context) {
    final q = Map<String, dynamic>.from(status?['qdrant'] ?? {});
    final running = pipeline?['running'] == true;
    return ScaffoldPage.scrollable(
      header: PageHeader(
        title: const Text('Pipeline & Sistema'),
        commandBar: IconButton(icon: const Icon(FluentIcons.refresh), onPressed: _refreshAll),
      ),
      children: [
        if (loading && status == null) const SizedBox(height: 250, child: LoadingPane()),
        if (error != null) InfoBar(title: const Text('Errore'), content: Text(error.toString()), severity: InfoBarSeverity.error),
        if (status != null) ...[
          LayoutBuilder(builder: (context, box) {
            final w = box.maxWidth > 900 ? (box.maxWidth - 24) / 3 : box.maxWidth;
            return Wrap(spacing: 12, runSpacing: 12, children: [
              SizedBox(width: w, child: StatCard(title: 'Database SQLite', value: _size(status!['database_size_bytes']), icon: FluentIcons.database, subtitle: '${status!['timezone']}')),
              SizedBox(width: w, child: StatCard(title: 'Qdrant', value: q['ok'] == true ? 'ONLINE' : 'OFFLINE', icon: FluentIcons.cloud, subtitle: '${q['collection'] ?? ''}')),
              SizedBox(width: w, child: StatCard(title: 'Credenziali', value: status!['graph_token_present'] == true ? 'Graph OK' : 'Graph MANCANTE', icon: FluentIcons.permissions, subtitle: status!['llm_api_key_present'] == true ? 'DeepInfra configurata' : 'DeepInfra non configurata')),
            ]);
          }),
          const SizedBox(height: 14),
          Card(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const SectionHeader('Comandi pipeline', icon: FluentIcons.processing),
              const SizedBox(height: 10),
              Wrap(spacing: 8, runSpacing: 8, children: [
                FilledButton(
                  onPressed: running ? null : () => _start({}),
                  child: const Text('▶ Incrementale completa'),
                ),
                Button(
                  onPressed: running ? null : () => _start({'no_download': true}),
                  child: const Text('Rielabora senza download'),
                ),
                Button(
                  onPressed: running ? null : () => _start({'no_llm': true}),
                  child: const Text('Esegui senza LLM'),
                ),
                Button(
                  onPressed: running ? null : () => _start({'no_qdrant': true}),
                  child: const Text('Esegui senza Qdrant'),
                ),
                Button(
                  onPressed: running
                      ? null
                      : () async {
                          if (await _confirm('Restart download', 'Ignora il nextLink salvato ma mantiene il watermark. Continuare?')) {
                            await _start({'restart_download': true});
                          }
                        },
                  child: const Text('Restart download'),
                ),
                Button(
                  onPressed: running
                      ? null
                      : () async {
                          if (await _confirm('Reset watermark', 'Questa operazione può provocare un nuovo full scan delle sorgenti. Continuare?')) {
                            await _start({'reset_watermark': true});
                          }
                        },
                  child: const Text('Reset watermark'),
                ),
                Button(
                  onPressed: running
                      ? () async {
                          if (await _confirm('Interrompi pipeline', 'Terminare il processo pipeline attualmente in esecuzione?')) {
                            await widget.api.postJson('/pipeline/stop', {});
                            await _refreshPipeline();
                          }
                        }
                      : null,
                  child: const Text('■ Stop'),
                ),
              ]),
              const SizedBox(height: 12),
              InfoBar(
                title: Text(running ? 'Pipeline in esecuzione' : 'Pipeline non in esecuzione'),
                content: Text('PID: ${pipeline?['pid'] ?? '-'}   exit code: ${pipeline?['exit_code'] ?? '-'}'),
                severity: running ? InfoBarSeverity.info : (pipeline?['exit_code'] == 0 ? InfoBarSeverity.success : InfoBarSeverity.info),
              ),
            ]),
          ),
          const SizedBox(height: 12),
          Card(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                const Expanded(child: SectionHeader('Log pipeline', icon: FluentIcons.text_document)),
                IconButton(icon: const Icon(FluentIcons.refresh), onPressed: _refreshPipeline),
              ]),
              const SizedBox(height: 8),
              Container(
                height: 330,
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(color: Colors.black.withValues(alpha: .30), borderRadius: BorderRadius.circular(8)),
                child: SingleChildScrollView(
                  reverse: true,
                  child: SelectionArea(
                    child: Text('${pipeline?['log_tail'] ?? ''}', style: const TextStyle(fontFamily: 'Consolas', fontSize: 12, height: 1.35)),
                  ),
                ),
              ),
            ]),
          ),
          const SizedBox(height: 12),
          Card(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const SectionHeader('Watermark e configurazione', icon: FluentIcons.sync),
              const SizedBox(height: 8),
              SelectableText(JsonEncoder.withIndent('  ').convert(status!['watermark'] ?? {}), style: const TextStyle(fontFamily: 'Consolas', fontSize: 12)),
              const SizedBox(height: 10),
              SelectableText('DB: ${status!['database']}\nRoot: ${status!['project_root']}', style: FluentTheme.of(context).typography.caption),
            ]),
          ),
        ],
      ],
    );
  }

  String _size(dynamic value) {
    final bytes = (value as num?)?.toDouble() ?? 0;
    if (bytes > 1024 * 1024 * 1024) return '${(bytes / 1024 / 1024 / 1024).toStringAsFixed(2)} GB';
    if (bytes > 1024 * 1024) return '${(bytes / 1024 / 1024).toStringAsFixed(1)} MB';
    return '${(bytes / 1024).toStringAsFixed(0)} KB';
  }
}

import 'package:fluent_ui/fluent_ui.dart';
import '../services/api_service.dart';
import '../widgets/common_widgets.dart';
import '../widgets/message_detail_dialog.dart';

class MessagesPage extends StatefulWidget {
  const MessagesPage({super.key, required this.api});
  final ApiService api;
  @override
  State<MessagesPage> createState() => _MessagesPageState();
}

class _MessagesPageState extends State<MessagesPage> {
  final search = TextEditingController();
  final author = TextEditingController();
  final from = TextEditingController();
  final to = TextEditingController();
  bool operational = false;
  double minScore = 0;
  String source = '';
  List<String> sources = [];
  List<Map<String, dynamic>> items = [];
  int total = 0;
  int offset = 0;
  final int limit = 100;
  bool loading = false;
  Object? error;

  @override
  void initState() {
    super.initState();
    _loadSources();
    _load();
  }

  Future<void> _loadSources() async {
    try {
      final d = await widget.api.getJson('/sources');
      final s = List<Map<String, dynamic>>.from((d['items'] ?? []).map((e) => Map<String, dynamic>.from(e)));
      if (mounted) setState(() => sources = s.map((e) => '${e['source_name']}').where((e) => e.isNotEmpty).toList());
    } catch (_) {}
  }

  Future<void> _load({bool reset = false}) async {
    if (reset) offset = 0;
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final d = await widget.api.getJson('/messages', params: {
        'q': search.text.trim(),
        'source': source,
        'author': author.text.trim(),
        'date_from': from.text.trim(),
        'date_to': to.text.trim(),
        'min_score': minScore.round(),
        'only_operational': operational,
        'limit': limit,
        'offset': offset,
      });
      if (mounted) {
        setState(() {
          items = List<Map<String, dynamic>>.from((d['items'] ?? []).map((e) => Map<String, dynamic>.from(e)));
          total = d['total'] ?? 0;
        });
      }
    } catch (e) {
      if (mounted) setState(() => error = e);
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  void _clear() {
    search.clear();
    author.clear();
    from.clear();
    to.clear();
    setState(() {
      source = '';
      operational = false;
      minScore = 0;
      offset = 0;
    });
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return ScaffoldPage(
      header: PageHeader(
        title: const Text('Ricerca messaggi'),
        commandBar: Row(mainAxisSize: MainAxisSize.min, children: [
          Text('${fmtNumber(total)} risultati'),
          const SizedBox(width: 10),
          IconButton(icon: const Icon(FluentIcons.refresh), onPressed: loading ? null : () => _load()),
        ]),
      ),
      content: Column(children: [
        Card(
          child: Column(children: [
            Row(children: [
              Expanded(flex: 3, child: TextBox(controller: search, placeholder: 'Testo, codice INC/PTASK/JOB, entità…', onSubmitted: (_) => _load(reset: true))),
              const SizedBox(width: 8),
              Expanded(flex: 2, child: TextBox(controller: author, placeholder: 'Autore')),
              const SizedBox(width: 8),
              SizedBox(
                width: 260,
                child: ComboBox<String>(
                  value: source,
                  isExpanded: true,
                  items: [
                    const ComboBoxItem(value: '', child: Text('Tutte le sorgenti')),
                    ...sources.map((s) => ComboBoxItem(value: s, child: Text(s, overflow: TextOverflow.ellipsis))),
                  ],
                  onChanged: (v) => setState(() => source = v ?? ''),
                ),
              ),
            ]),
            const SizedBox(height: 10),
            Row(children: [
              SizedBox(width: 150, child: TextBox(controller: from, placeholder: 'Da YYYY-MM-DD')),
              const SizedBox(width: 8),
              SizedBox(width: 150, child: TextBox(controller: to, placeholder: 'A YYYY-MM-DD')),
              const SizedBox(width: 14),
              Text('Score ≥ ${minScore.round()}'),
              SizedBox(width: 180, child: Slider(value: minScore, min: 0, max: 100, divisions: 20, onChanged: (v) => setState(() => minScore = v))),
              const SizedBox(width: 14),
              ToggleSwitch(checked: operational, content: const Text('Solo operativi'), onChanged: (v) => setState(() => operational = v)),
              const Spacer(),
              FilledButton(onPressed: loading ? null : () => _load(reset: true), child: const Text('Cerca')),
              const SizedBox(width: 8),
              Button(onPressed: _clear, child: const Text('Azzera')),
            ]),
          ]),
        ),
        const SizedBox(height: 10),
        if (error != null) InfoBar(title: const Text('Errore'), content: Text(error.toString()), severity: InfoBarSeverity.error),
        Expanded(
          child: loading && items.isEmpty
              ? const LoadingPane()
              : items.isEmpty
                  ? const EmptyState(title: 'Nessun messaggio trovato', description: 'Prova a modificare i filtri di ricerca.')
                  : ListView.separated(
                      itemCount: items.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 6),
                      itemBuilder: (context, i) {
                        final m = items[i];
                        return Card(
                          padding: const EdgeInsets.all(10),
                          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Container(width: 5, height: 70, decoration: BoxDecoration(color: scoreColor(context, m['operational_score']), borderRadius: BorderRadius.circular(5))),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Row(children: [
                                  Expanded(child: Text('${m['author'] ?? '(autore n/d)'}', style: const TextStyle(fontWeight: FontWeight.w600))),
                                  SourceBadge('${m['source_name'] ?? ''}'),
                                  const SizedBox(width: 8),
                                  InfoBadge(source: Text('Score ${m['operational_score'] ?? 0}')),
                                ]),
                                const SizedBox(height: 4),
                                Text('${m['created_ts'] ?? ''}', style: FluentTheme.of(context).typography.caption),
                                const SizedBox(height: 5),
                                Text(shortText(m['text'], 520), maxLines: 3, overflow: TextOverflow.ellipsis),
                                if ((m['short_summary'] ?? '').toString().isNotEmpty) ...[
                                  const SizedBox(height: 5),
                                  Text('LLM: ${shortText(m['short_summary'], 260)}', style: FluentTheme.of(context).typography.caption),
                                ],
                              ]),
                            ),
                            const SizedBox(width: 8),
                            IconButton(icon: const Icon(FluentIcons.open_in_new_window), onPressed: () => showMessageDetail(context, widget.api, '${m['message_id']}')),
                          ]),
                        );
                      },
                    ),
        ),
        const SizedBox(height: 8),
        Row(mainAxisAlignment: MainAxisAlignment.end, children: [
          Button(
            onPressed: offset <= 0 || loading
                ? null
                : () {
                    setState(() => offset = (offset - limit).clamp(0, 1 << 30).toInt());
                    _load();
                  },
            child: const Text('← Precedenti'),
          ),
          const SizedBox(width: 10),
          Text('${offset + 1}-${(offset + items.length).clamp(0, total)} di $total'),
          const SizedBox(width: 10),
          Button(
            onPressed: offset + items.length >= total || loading
                ? null
                : () {
                    setState(() => offset += limit);
                    _load();
                  },
            child: const Text('Successivi →'),
          ),
        ]),
      ]),
    );
  }
}

import 'package:fl_chart/fl_chart.dart';
import 'package:fluent_ui/fluent_ui.dart';
import '../services/api_service.dart';
import '../widgets/common_widgets.dart';
import '../widgets/event_detail_dialog.dart';
import '../widgets/message_detail_dialog.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key, required this.api});
  final ApiService api;
  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  Map<String, dynamic>? data;
  Object? error;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final d = await widget.api.getJson('/dashboard');
      if (mounted) setState(() => data = d);
    } catch (e) {
      if (mounted) setState(() => error = e);
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading && data == null) return const LoadingPane(text: 'Caricamento dashboard…');
    if (error != null && data == null) {
      return EmptyState(title: 'Backend non disponibile', description: error.toString(), icon: FluentIcons.server);
    }
    final counts = Map<String, dynamic>.from(data?['counts'] ?? {});
    final sources = _maps(data?['sources']);
    final recentMessages = _maps(data?['recent_messages']);
    final recentEvents = _maps(data?['recent_events']);
    final qdrant = Map<String, dynamic>.from(data?['qdrant'] ?? {});

    return ScaffoldPage.scrollable(
      header: PageHeader(
        title: const Text('Dashboard operativa'),
        commandBar: Row(mainAxisSize: MainAxisSize.min, children: [
          if (qdrant['enabled'] == true)
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: InfoBadge(
                color: qdrant['ok'] == true ? Colors.green.normal : Colors.orange.normal,
                source: Text(qdrant['ok'] == true ? 'Qdrant OK' : 'Qdrant offline'),
              ),
            ),
          IconButton(icon: const Icon(FluentIcons.refresh), onPressed: _load),
        ]),
      ),
      children: [
        LayoutBuilder(builder: (context, box) {
          final width = box.maxWidth;
          final columns = width > 1250 ? 5 : width > 850 ? 3 : 2;
          final itemWidth = (width - (columns - 1) * 12) / columns;
          final cards = [
            StatCard(title: 'Messaggi', value: fmtNumber(counts['messages']), icon: FluentIcons.message),
            StatCard(title: 'Analisi LLM', value: fmtNumber(counts['llm_analyses']), icon: FluentIcons.robot),
            StatCard(title: 'Eventi', value: fmtNumber(counts['events']), icon: FluentIcons.timeline),
            StatCard(title: 'Entità', value: fmtNumber(counts['entities']), icon: FluentIcons.tag),
            StatCard(
              title: 'Chunk RAG',
              value: fmtNumber(counts['chunks']),
              icon: FluentIcons.database,
              subtitle: '${fmtNumber(counts['pending_embeddings'])} da embeddare',
            ),
          ];
          return Wrap(
            spacing: 12,
            runSpacing: 12,
            children: cards.map((c) => SizedBox(width: itemWidth, child: c)).toList(),
          );
        }),
        const SizedBox(height: 18),
        LayoutBuilder(builder: (context, box) {
          final wide = box.maxWidth > 1050;
          final sourceCard = Card(
            child: SizedBox(
              height: 310,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const SectionHeader('Messaggi per sorgente', icon: FluentIcons.group),
                const SizedBox(height: 12),
                Expanded(child: _SourceChart(sources: sources)),
              ]),
            ),
          );
          final eventCard = Card(
            child: SizedBox(
              height: 310,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const SectionHeader('Eventi recenti', icon: FluentIcons.event),
                const SizedBox(height: 8),
                Expanded(
                  child: recentEvents.isEmpty
                      ? const EmptyState(title: 'Nessun evento')
                      : ListView.separated(
                          itemCount: recentEvents.length,
                          separatorBuilder: (_, __) => const Divider(),
                          itemBuilder: (context, i) {
                            final e = recentEvents[i];
                            return ListTile.selectable(
                              title: Text('${e['title'] ?? ''}', maxLines: 1, overflow: TextOverflow.ellipsis),
                              subtitle: Text('${e['start_ts'] ?? ''} • ${e['source_name'] ?? ''}'),
                              trailing: const Icon(FluentIcons.chevron_right, size: 12),
                              onPressed: () => showEventDetail(context, widget.api, '${e['event_id']}'),
                            );
                          },
                        ),
                ),
              ]),
            ),
          );
          if (wide) {
            return Row(children: [Expanded(child: sourceCard), const SizedBox(width: 12), Expanded(child: eventCard)]);
          }
          return Column(children: [sourceCard, const SizedBox(height: 12), eventCard]);
        }),
        const SizedBox(height: 18),
        Card(
          child: SizedBox(
            height: 380,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const SectionHeader('Ultimi messaggi Teams', icon: FluentIcons.chat),
              const SizedBox(height: 8),
              Expanded(
                child: recentMessages.isEmpty
                    ? const EmptyState(title: 'Nessun messaggio')
                    : ListView.separated(
                        itemCount: recentMessages.length,
                        separatorBuilder: (_, __) => const Divider(),
                        itemBuilder: (context, i) {
                          final m = recentMessages[i];
                          return ListTile.selectable(
                            leading: Container(
                              width: 5,
                              height: 42,
                              decoration: BoxDecoration(
                                color: scoreColor(context, m['operational_score']),
                                borderRadius: BorderRadius.circular(4),
                              ),
                            ),
                            title: Row(children: [
                              Expanded(child: Text('${m['author'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.w600))),
                              SourceBadge('${m['source_name'] ?? ''}'),
                            ]),
                            subtitle: Text('${m['created_ts'] ?? ''}\n${shortText(m['text'], 240)}'),
                            trailing: const Icon(FluentIcons.open_in_new_window),
                            onPressed: () => showMessageDetail(context, widget.api, '${m['message_id']}'),
                          );
                        },
                      ),
              ),
            ]),
          ),
        ),
      ],
    );
  }

  List<Map<String, dynamic>> _maps(dynamic value) =>
      List<Map<String, dynamic>>.from((value ?? []).map((e) => Map<String, dynamic>.from(e)));
}

class _SourceChart extends StatelessWidget {
  const _SourceChart({required this.sources});
  final List<Map<String, dynamic>> sources;
  @override
  Widget build(BuildContext context) {
    if (sources.isEmpty) return const EmptyState(title: 'Nessuna sorgente');
    final top = sources.take(8).toList();
    final max = top.fold<double>(1, (v, e) => ((e['count'] as num?)?.toDouble() ?? 0) > v ? (e['count'] as num).toDouble() : v);
    final accent = FluentTheme.of(context).accentColor.normal;
    return BarChart(
      BarChartData(
        maxY: max * 1.18,
        alignment: BarChartAlignment.spaceAround,
        gridData: const FlGridData(show: false),
        borderData: FlBorderData(show: false),
        titlesData: FlTitlesData(
          leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 54,
              getTitlesWidget: (value, meta) {
                final i = value.toInt();
                if (i < 0 || i >= top.length) return const SizedBox.shrink();
                return Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: SizedBox(width: 82, child: Text(shortText(top[i]['source_name'], 16), textAlign: TextAlign.center, maxLines: 2)),
                );
              },
            ),
          ),
        ),
        barGroups: [
          for (var i = 0; i < top.length; i++)
            BarChartGroupData(x: i, barRods: [
              BarChartRodData(
                toY: (top[i]['count'] as num?)?.toDouble() ?? 0,
                width: 24,
                borderRadius: BorderRadius.circular(6),
                color: accent,
              ),
            ]),
        ],
      ),
    );
  }
}

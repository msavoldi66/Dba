import 'package:fluent_ui/fluent_ui.dart';
import '../services/api_service.dart';
import '../widgets/common_widgets.dart';
import '../widgets/event_detail_dialog.dart';

class EventsPage extends StatefulWidget {
  const EventsPage({super.key, required this.api});
  final ApiService api;
  @override
  State<EventsPage> createState() => _EventsPageState();
}

class _EventsPageState extends State<EventsPage> {
  final search = TextEditingController();
  String source = '';
  String eventType = '';
  List<String> sources = [];
  List<String> types = [];
  List<Map<String, dynamic>> items = [];
  int total = 0;
  bool loading = false;
  Object? error;

  @override
  void initState() {
    super.initState();
    _loadSources();
    _load();
  }

  Future<void> _loadSources() async {
    try {
      final d = await widget.api.getJson('/sources');
      final rows = List<Map<String, dynamic>>.from((d['items'] ?? []).map((e) => Map<String, dynamic>.from(e)));
      if (mounted) setState(() => sources = rows.map((e) => '${e['source_name']}').where((s) => s.isNotEmpty).toList());
    } catch (_) {}
  }

  Future<void> _load() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final d = await widget.api.getJson('/events', params: {
        'q': search.text.trim(),
        'source': source,
        'event_type': eventType,
        'limit': 300,
      });
      final rows = List<Map<String, dynamic>>.from((d['items'] ?? []).map((e) => Map<String, dynamic>.from(e)));
      if (mounted) {
        setState(() {
          items = rows;
          total = d['total'] ?? rows.length;
          final newTypes = rows.map((e) => '${e['event_type'] ?? ''}').where((e) => e.isNotEmpty).toSet().toList()..sort();
          types = {...types, ...newTypes}.toList()..sort();
        });
      }
    } catch (e) {
      if (mounted) setState(() => error = e);
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ScaffoldPage(
      header: PageHeader(
        title: const Text('Eventi e timeline'),
        commandBar: Text('${fmtNumber(total)} eventi'),
      ),
      content: Column(children: [
        Card(
          child: Row(children: [
            Expanded(flex: 3, child: TextBox(controller: search, placeholder: 'Titolo, entità, partecipante, INC/PTASK…', onSubmitted: (_) => _load())),
            const SizedBox(width: 8),
            Expanded(
              flex: 2,
              child: ComboBox<String>(
                isExpanded: true,
                value: source,
                items: [const ComboBoxItem(value: '', child: Text('Tutte le sorgenti')), ...sources.map((s) => ComboBoxItem(value: s, child: Text(s)))],
                onChanged: (v) => setState(() => source = v ?? ''),
              ),
            ),
            const SizedBox(width: 8),
            SizedBox(
              width: 190,
              child: ComboBox<String>(
                isExpanded: true,
                value: eventType,
                items: [const ComboBoxItem(value: '', child: Text('Tutti i tipi')), ...types.map((s) => ComboBoxItem(value: s, child: Text(s)))],
                onChanged: (v) => setState(() => eventType = v ?? ''),
              ),
            ),
            const SizedBox(width: 8),
            FilledButton(onPressed: loading ? null : _load, child: const Text('Filtra')),
          ]),
        ),
        const SizedBox(height: 10),
        if (error != null) InfoBar(title: const Text('Errore'), content: Text(error.toString()), severity: InfoBarSeverity.error),
        Expanded(
          child: loading && items.isEmpty
              ? const LoadingPane()
              : items.isEmpty
                  ? const EmptyState(title: 'Nessun evento')
                  : ListView.builder(
                      itemCount: items.length,
                      itemBuilder: (context, i) {
                        final e = items[i];
                        return Container(
                          margin: const EdgeInsets.only(bottom: 8),
                          child: Card(
                            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Container(
                                width: 48,
                                height: 48,
                                decoration: BoxDecoration(
                                  color: FluentTheme.of(context).accentColor.normal.withValues(alpha: .12),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: const Icon(FluentIcons.timeline),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  Row(children: [
                                    Expanded(child: Text('${e['title'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.w600))),
                                    SourceBadge('${e['source_name'] ?? ''}'),
                                  ]),
                                  const SizedBox(height: 4),
                                  Text('${e['start_ts'] ?? ''} → ${e['end_ts'] ?? ''} • ${e['event_type'] ?? ''}', style: FluentTheme.of(context).typography.caption),
                                  const SizedBox(height: 6),
                                  Text(shortText(e['summary'], 500)),
                                  if ((e['main_entity'] ?? '').toString().isNotEmpty) ...[
                                    const SizedBox(height: 5),
                                    Text('Entità principale: ${e['main_entity']}', style: FluentTheme.of(context).typography.caption),
                                  ],
                                ]),
                              ),
                              IconButton(icon: const Icon(FluentIcons.open_in_new_window), onPressed: () => showEventDetail(context, widget.api, '${e['event_id']}')),
                            ]),
                          ),
                        );
                      },
                    ),
        ),
      ]),
    );
  }
}

import 'package:fluent_ui/fluent_ui.dart';
import '../services/api_service.dart';
import '../widgets/common_widgets.dart';

class HistoryPage extends StatefulWidget {
  const HistoryPage({super.key, required this.api});
  final ApiService api;
  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  List<Map<String, dynamic>> items = [];
  bool loading = true;
  Object? error;
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final d = await widget.api.getJson('/history', params: {'limit': 200});
      if (mounted) setState(() => items = List<Map<String, dynamic>>.from((d['items'] ?? []).map((e) => Map<String, dynamic>.from(e))));
    } catch (e) {
      if (mounted) setState(() => error = e);
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ScaffoldPage(
      header: PageHeader(title: const Text('Cronologia domande RAG'), commandBar: IconButton(icon: const Icon(FluentIcons.refresh), onPressed: _load)),
      content: error != null
          ? EmptyState(title: 'Errore', description: error.toString())
          : loading && items.isEmpty
              ? const LoadingPane()
              : items.isEmpty
                  ? const EmptyState(title: 'Nessuna domanda ancora eseguita')
                  : ListView.separated(
                      itemCount: items.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 7),
                      itemBuilder: (context, i) {
                        final h = items[i];
                        return Card(
                          child: ListTile.selectable(
                            title: Text('${h['question'] ?? ''}', maxLines: 2, overflow: TextOverflow.ellipsis),
                            subtitle: Text('${h['created_at'] ?? ''} • ${h['model'] ?? ''} • ${h['elapsed_ms'] ?? 0} ms'),
                            trailing: const Icon(FluentIcons.chevron_right),
                            onPressed: () => showDialog<void>(
                              context: context,
                              builder: (context) => ContentDialog(
                                constraints: const BoxConstraints(maxWidth: 900, maxHeight: 700),
                                title: Text('${h['question'] ?? ''}'),
                                content: SingleChildScrollView(child: SelectionArea(child: Text('${h['answer'] ?? ''}', style: const TextStyle(height: 1.5)))),
                                actions: [FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Chiudi'))],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
    );
  }
}

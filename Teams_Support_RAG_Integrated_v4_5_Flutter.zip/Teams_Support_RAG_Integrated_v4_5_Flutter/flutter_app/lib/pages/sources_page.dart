import 'package:fluent_ui/fluent_ui.dart';
import '../services/api_service.dart';
import '../widgets/common_widgets.dart';

class SourcesPage extends StatefulWidget {
  const SourcesPage({super.key, required this.api});
  final ApiService api;
  @override
  State<SourcesPage> createState() => _SourcesPageState();
}

class _SourcesPageState extends State<SourcesPage> {
  List<Map<String, dynamic>> items = [];
  bool loading = true;
  Object? error;
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final d = await widget.api.getJson('/sources');
      if (mounted) setState(() => items = List<Map<String, dynamic>>.from((d['items'] ?? []).map((e) => Map<String, dynamic>.from(e))));
    } catch (e) {
      if (mounted) setState(() => error = e);
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ScaffoldPage.scrollable(
      header: PageHeader(title: const Text('Sorgenti Teams'), commandBar: IconButton(icon: const Icon(FluentIcons.refresh), onPressed: _load)),
      children: [
        if (error != null) InfoBar(title: const Text('Errore'), content: Text(error.toString()), severity: InfoBarSeverity.error),
        if (loading && items.isEmpty)
          const SizedBox(height: 300, child: LoadingPane())
        else
          ...items.map((s) => Card(
                margin: const EdgeInsets.only(bottom: 10),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: FluentTheme.of(context).accentColor.normal.withValues(alpha: .12),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(s['mode'] == 'channel' ? FluentIcons.open_source : FluentIcons.chat),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        Expanded(child: Text('${s['source_name']}', style: FluentTheme.of(context).typography.subtitle)),
                        InfoBadge(
                          color: s['enabled'] == 1 ? Colors.green.normal : Colors.grey[100],
                          source: Text(s['enabled'] == 1 ? 'abilitata' : 'disabilitata'),
                        ),
                      ]),
                      const SizedBox(height: 5),
                      SelectableText('Signature: ${s['source_signature']}'),
                      if ((s['chat_id'] ?? '').toString().isNotEmpty) SelectableText('Chat ID: ${s['chat_id']}'),
                      if ((s['team_id'] ?? '').toString().isNotEmpty) SelectableText('Team ID: ${s['team_id']}'),
                      if ((s['channel_id'] ?? '').toString().isNotEmpty) SelectableText('Channel ID: ${s['channel_id']}'),
                      const SizedBox(height: 6),
                      Text('${fmtNumber(s['message_count'])} messaggi • overlap ${s['overlap_hours'] ?? ''} h', style: FluentTheme.of(context).typography.caption),
                    ]),
                  ),
                ]),
              )),
      ],
    );
  }
}

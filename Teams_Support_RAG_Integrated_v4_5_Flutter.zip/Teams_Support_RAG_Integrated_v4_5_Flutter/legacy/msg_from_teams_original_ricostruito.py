#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
msg_from_teams_original_ricostruito.py

ATTENZIONE:
Questo NON è garantito come file originale byte-per-byte.
È una ricostruzione della vecchia versione del programma emersa dal progetto:
- legge access_token.txt
- usa un chat_id impostato nel codice
- legge i messaggi da Microsoft Graph: /chats/{chat_id}/messages
- gestisce @odata.nextLink
- pulisce l'HTML dei messaggi Teams
- genera:
    - messaggi_chat.txt
    - report_messaggi.xlsx
    - distribuzione_cluster.png
    - messaggi_per_utente.pdf

Dipendenze:
    pip install requests pandas openpyxl beautifulsoup4 matplotlib fpdf2

Uso:
    1) creare access_token.txt nella stessa directory
    2) impostare CHAT_ID sotto
    3) eseguire:
       python msg_from_teams_original_ricostruito.py
"""

import json
import re
from pathlib import Path
from typing import Any, Dict, List

import requests
import pandas as pd

try:
    from bs4 import BeautifulSoup
except ImportError:
    BeautifulSoup = None

try:
    import matplotlib.pyplot as plt
except ImportError:
    plt = None

try:
    from fpdf import FPDF
except ImportError:
    FPDF = None


# =============================================================================
# PARAMETRI PRINCIPALI
# =============================================================================

BASE_DIR = Path(__file__).resolve().parent

ACCESS_TOKEN_FILE = BASE_DIR / "access_token.txt"

# Chat ID storico citato nel progetto. Sostituire se necessario.
CHAT_ID = "19:meeting_NTc0OTlmZDAtZTUzMy00ZTBiLWI3MWItMjM4YmQ4ZjExZDZm@thread.v2"

GRAPH_URL = f"https://graph.microsoft.com/v1.0/chats/{CHAT_ID}/messages?$top=50"

OUTPUT_TXT = BASE_DIR / "messaggi_chat.txt"
OUTPUT_XLSX = BASE_DIR / "report_messaggi.xlsx"
OUTPUT_JSON = BASE_DIR / "messages.json"
OUTPUT_PNG = BASE_DIR / "distribuzione_cluster.png"
OUTPUT_PDF = BASE_DIR / "messaggi_per_utente.pdf"


# =============================================================================
# UTILITY
# =============================================================================

def read_access_token() -> str:
    """
    Legge il token OAuth 2.0 dal file access_token.txt.
    """
    if not ACCESS_TOKEN_FILE.exists():
        raise FileNotFoundError(
            f"File token non trovato: {ACCESS_TOKEN_FILE}\n"
            "Crea access_token.txt nella stessa directory del programma."
        )

    token = ACCESS_TOKEN_FILE.read_text(encoding="utf-8").strip()

    if not token:
        raise ValueError("access_token.txt è vuoto.")

    return token


def clean_html(html: Any) -> str:
    """
    Converte HTML Teams in testo semplice.
    """
    if html is None:
        return ""

    html = str(html)

    if BeautifulSoup is not None:
        soup = BeautifulSoup(html, "html.parser")
        text = soup.get_text(separator=" ", strip=True)
    else:
        text = re.sub(r"<br\s*/?>", "\n", html, flags=re.IGNORECASE)
        text = re.sub(r"</p\s*>", "\n", text, flags=re.IGNORECASE)
        text = re.sub(r"<[^>]+>", " ", text)
        text = re.sub(r"\s+", " ", text)

    return text.strip()


def get_nested(data: Dict[str, Any], path: str, default: str = "") -> Any:
    """
    Estrae un campo annidato da un dizionario.
    Esempio:
        get_nested(msg, "from.user.displayName")
    """
    current: Any = data

    for key in path.split("."):
        if not isinstance(current, dict):
            return default

        current = current.get(key)

        if current is None:
            return default

    return current


def get_user(message: Dict[str, Any]) -> str:
    """
    Estrae il nome utente del mittente.
    """
    user = get_nested(message, "from.user.displayName")
    email = get_nested(message, "from.user.email")
    app = get_nested(message, "from.application.displayName")

    if user and email:
        return f"{user} <{email}>"

    if user:
        return user

    if email:
        return email

    if app:
        return f"Application: {app}"

    return "Sconosciuto"


def graph_get(url: str, token: str) -> Dict[str, Any]:
    """
    Esegue una GET verso Microsoft Graph.
    """
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
    }

    response = requests.get(url, headers=headers, timeout=60)

    if response.status_code >= 400:
        raise RuntimeError(
            f"Errore Graph API {response.status_code}\n"
            f"URL: {url}\n"
            f"Risposta: {response.text}"
        )

    return response.json()


def download_messages(token: str) -> List[Dict[str, Any]]:
    """
    Scarica tutti i messaggi della chat gestendo @odata.nextLink.
    """
    all_messages: List[Dict[str, Any]] = []
    url = GRAPH_URL
    page = 1

    while url:
        print(f"Scarico pagina {page}: {url}")

        data = graph_get(url, token)
        messages = data.get("value", [])

        if isinstance(messages, list):
            all_messages.extend(messages)

        url = data.get("@odata.nextLink")
        page += 1

    return all_messages


def normalize_messages(messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Trasforma i messaggi Graph in record semplici.
    """
    clean_messages: List[Dict[str, Any]] = []

    for message in messages:
        sent_time = message.get("createdDateTime", "")
        user = get_user(message)
        html = get_nested(message, "body.content")
        text = clean_html(html)

        record = {
            "datetime": sent_time,
            "user": user,
            "text": text,
            "message_id": message.get("id", ""),
            "importance": message.get("importance", ""),
            "subject": message.get("subject", ""),
            "replyToId": message.get("replyToId", ""),
            "etag": message.get("etag", ""),
            "raw_html": html or "",
        }

        clean_messages.append(record)

    return clean_messages


# =============================================================================
# OUTPUT
# =============================================================================

def save_raw_json(messages: List[Dict[str, Any]]) -> None:
    OUTPUT_JSON.write_text(
        json.dumps(messages, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"Creato: {OUTPUT_JSON}")


def save_text(clean_messages: List[Dict[str, Any]]) -> None:
    """
    Scrive un TXT leggibile.
    """
    with OUTPUT_TXT.open("w", encoding="utf-8") as f:
        for msg in clean_messages:
            f.write(f"[{msg['datetime']}] {msg['user']}: {msg['text']}\n")
            f.write("-" * 120 + "\n")

    print(f"Creato: {OUTPUT_TXT}")


def save_excel(clean_messages: List[Dict[str, Any]]) -> pd.DataFrame:
    """
    Scrive report_messaggi.xlsx.
    """
    df = pd.DataFrame(clean_messages)

    if not df.empty and "datetime" in df.columns:
        df["datetime"] = pd.to_datetime(df["datetime"], errors="coerce")
        df.sort_values("datetime", inplace=True)

    with pd.ExcelWriter(OUTPUT_XLSX, engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name="Messaggi", index=False)

        if not df.empty and "user" in df.columns:
            per_utente = (
                df.groupby("user")
                .size()
                .reset_index(name="numero_messaggi")
                .sort_values("numero_messaggi", ascending=False)
            )
            per_utente.to_excel(writer, sheet_name="Messaggi per utente", index=False)

    print(f"Creato: {OUTPUT_XLSX}")

    return df


def save_chart(df: pd.DataFrame) -> None:
    """
    Crea distribuzione_cluster.png con messaggi per utente.
    """
    if plt is None:
        print("matplotlib non installato: salto creazione PNG.")
        return

    if df.empty or "user" not in df.columns:
        print("Nessun dato utile per generare il grafico.")
        return

    counts = df["user"].value_counts().head(20)

    if counts.empty:
        print("Nessun conteggio utile per generare il grafico.")
        return

    plt.figure(figsize=(12, 7))
    counts.sort_values().plot(kind="barh")
    plt.title("Messaggi per utente - Top 20")
    plt.xlabel("Numero messaggi")
    plt.ylabel("Utente")
    plt.tight_layout()
    plt.savefig(OUTPUT_PNG)
    plt.close()

    print(f"Creato: {OUTPUT_PNG}")


def save_pdf(df: pd.DataFrame) -> None:
    """
    Crea PDF riepilogativo messaggi per utente.
    """
    if FPDF is None:
        print("fpdf2 non installato: salto creazione PDF.")
        return

    if df.empty or "user" not in df.columns:
        print("Nessun dato utile per generare il PDF.")
        return

    counts = df["user"].value_counts()

    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", "B", 14)
    pdf.cell(0, 10, "Messaggi Teams per utente", ln=True)

    pdf.set_font("Arial", "", 10)
    pdf.ln(4)

    for user, count in counts.items():
        # evita caratteri non gestibili dal font base Latin-1
        safe_user = str(user).encode("latin-1", errors="replace").decode("latin-1")
        pdf.cell(0, 8, f"{safe_user}: {count}", ln=True)

    pdf.output(str(OUTPUT_PDF))

    print(f"Creato: {OUTPUT_PDF}")


# =============================================================================
# MAIN
# =============================================================================

def main() -> None:
    print("Lettura token da access_token.txt...")
    token = read_access_token()

    print("Download messaggi Teams da Microsoft Graph...")
    raw_messages = download_messages(token)

    print(f"Messaggi scaricati: {len(raw_messages)}")

    save_raw_json(raw_messages)

    clean_messages = normalize_messages(raw_messages)

    save_text(clean_messages)
    df = save_excel(clean_messages)
    save_chart(df)
    save_pdf(df)

    print("Elaborazione completata.")


if __name__ == "__main__":
    main()

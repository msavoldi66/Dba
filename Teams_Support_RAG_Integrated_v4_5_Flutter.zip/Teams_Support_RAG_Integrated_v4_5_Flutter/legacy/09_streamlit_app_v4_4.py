from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from typing import Any, Dict, List

import pandas as pd
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import load_config, connect_db

APP_VERSION = "v4.4-rome-timezone-2026-08-27"


def load_rag_module():
    path = Path(__file__).resolve().parent / "08_rag_query_engine.py"
    module_name = "rag_engine_dynamic_exact_first"
    if module_name in sys.modules:
        del sys.modules[module_name]
    spec = importlib.util.spec_from_file_location(module_name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def rows_to_df(rows) -> pd.DataFrame:
    return pd.DataFrame([dict(r) for r in rows])


def message_items_to_df(items: List[Dict[str, Any]]) -> pd.DataFrame:
    rows = []
    for item in items:
        msg = item.get("message") or {}
        rows.append({
            "source": item.get("source"),
            "matched_term": item.get("matched_term"),
            "score": item.get("score"),
            "source_name": msg.get("source_name"),
            "created_ts": msg.get("created_ts"),
            "author": msg.get("author"),
            "text": msg.get("text"),
            "reply_to_author": msg.get("reply_to_author"),
            "reply_to_text": msg.get("reply_to_text"),
            "reactions": msg.get("reaction_summary"),
            "message_id": msg.get("message_id"),
        })
    return pd.DataFrame(rows)


def chunks_to_df(chunks: List[Dict[str, Any]]) -> pd.DataFrame:
    rows = []
    for ch in chunks:
        p = ch.get("payload") or {}
        rows.append({
            "source": ch.get("source", "qdrant"),
            "score": ch.get("score"),
            "chunk_id": ch.get("id") or p.get("chunk_id"),
            "chunk_type": p.get("chunk_type"),
            "start_ts": p.get("start_ts"),
            "end_ts": p.get("end_ts"),
            "entities": p.get("entities"),
            "participants": p.get("participants"),
            "text": (p.get("text") or "")[:1200],
        })
    return pd.DataFrame(rows)


def main():
    st.set_page_config(page_title="Support DB2 Teams RAG", layout="wide")
    cfg = load_config("config/config.ini")
    con = connect_db(cfg["paths"]["sqlite_db"])
    rag = load_rag_module()

    st.title("Support DB2 Teams RAG Assistant")
    st.caption("SQLite exact/FTS + Qdrant + DeepInfra/Qwen embeddings per chat operative Teams")
    st.caption(f"App {APP_VERSION} | Engine {getattr(rag, 'ENGINE_VERSION', 'n/d')}")

    with st.sidebar:
        st.header("Parametri")
        st.caption(f"Timezone messaggi: {cfg.get('time', 'local_timezone', fallback='Europe/Rome')}")
        top_k = st.slider("Top K Qdrant", 1, 30, cfg.getint("rag", "top_k", fallback=8))
        threshold = st.slider("Score threshold Qdrant", 0.0, 1.0, cfg.getfloat("rag", "score_threshold", fallback=0.20), 0.05)
        st.metric("Messaggi", con.execute("SELECT COUNT(*) c FROM messages").fetchone()["c"])
        st.metric("Chunk RAG", con.execute("SELECT COUNT(*) c FROM rag_chunks").fetchone()["c"])
        st.metric("Eventi", con.execute("SELECT COUNT(*) c FROM conversation_events").fetchone()["c"])
        src_rows = con.execute("SELECT COALESCE(NULLIF(source_name,''), source_signature, 'legacy') source, COUNT(*) c FROM messages GROUP BY 1 ORDER BY c DESC").fetchall()
        if src_rows:
            st.caption("Messaggi per sorgente")
            st.dataframe(rows_to_df(src_rows), use_container_width=True, hide_index=True)
        try:
            fts_count = con.execute("SELECT COUNT(*) c FROM messages_fts").fetchone()["c"]
            st.metric("FTS records", fts_count)
        except Exception:
            st.metric("FTS records", "errore")

    tab1, tab2, tab3, tab4, tab5 = st.tabs(["Domande RAG", "Cerca SQLite", "Eventi", "Diagnostica", "Storico Q&A"])

    with tab1:
        q = st.text_area("Domanda", height=100, placeholder="Esempio: trova riferimenti per Z7AJA000")
        if st.button("Esegui domanda") and q.strip():
            with st.spinner("Ricerca ibrida SQLite exact/FTS + RAG..."):
                try:
                    result = rag.ask_detailed(q, "config/config.ini", top_k=top_k, threshold=threshold)
                except Exception as e:
                    st.error(str(e))
                    return

            if result.get("exact_terms"):
                st.info("Termini tecnici estratti: " + ", ".join(f"`{x}`" for x in result["exact_terms"]))
            if result.get("qdrant_error"):
                st.warning("Qdrant non disponibile o non allineato: " + result["qdrant_error"])

            st.markdown(result["answer"])

            with st.expander("Fonti SQLite exact/FTS usate", expanded=True):
                df = message_items_to_df(result.get("messages", []))
                if df.empty:
                    st.write("Nessuna fonte SQLite exact/FTS.")
                else:
                    st.dataframe(df, use_container_width=True)

            with st.expander("Contesto messaggi prima/dopo"):
                ctx = result.get("context_messages", [])
                if ctx:
                    st.dataframe(pd.DataFrame(ctx), use_container_width=True)
                else:
                    st.write("Nessun contesto disponibile.")

            with st.expander("Chunk RAG/Qdrant o chunk LIKE"):
                dfc = chunks_to_df(result.get("chunks", []))
                if dfc.empty:
                    st.write("Nessun chunk pertinente.")
                else:
                    st.dataframe(dfc, use_container_width=True)

    with tab2:
        term = st.text_input("Testo/entità da cercare")
        if term:
            like = f"%{term}%"
            rows = con.execute(
                """
                SELECT source_name, created_ts, author, text, reply_to_author, reply_to_text, reaction_summary, operational_score, message_id
                FROM messages
                WHERE text LIKE ? OR author LIKE ? OR reply_to_text LIKE ? OR raw_block LIKE ?
                ORDER BY COALESCE(NULLIF(created_ts_utc,''), created_ts)
                LIMIT 300
                """,
                (like, like, like, like),
            ).fetchall()
            st.dataframe(rows_to_df(rows), use_container_width=True)

    with tab3:
        rows = con.execute(
            "SELECT source_name, event_type, title, start_ts, end_ts, participants, summary FROM conversation_events ORDER BY start_ts DESC LIMIT 300"
        ).fetchall()
        st.dataframe(rows_to_df(rows), use_container_width=True)

    with tab4:
        st.subheader("Diagnostica ricerca tecnica")
        diag_term = st.text_input("Codice tecnico da diagnosticare", value="Z7AJA000")
        if st.button("Esegui diagnostica") and diag_term:
            like = f"%{diag_term}%"
            c1 = con.execute("SELECT COUNT(*) c FROM messages WHERE UPPER(text) LIKE UPPER(?) OR UPPER(raw_block) LIKE UPPER(?)", (like, like)).fetchone()["c"]
            c2 = con.execute("SELECT COUNT(*) c FROM message_entities WHERE UPPER(entity_value) LIKE UPPER(?)", (like,)).fetchone()["c"]
            c3 = con.execute("SELECT COUNT(*) c FROM rag_chunks WHERE UPPER(text) LIKE UPPER(?) OR UPPER(entities) LIKE UPPER(?)", (like, like)).fetchone()["c"]
            try:
                c4 = con.execute("SELECT COUNT(*) c FROM messages_fts WHERE messages_fts MATCH ?", (f'"{diag_term}"',)).fetchone()["c"]
            except Exception as e:
                c4 = f"errore FTS: {e}"
            st.write({"messages_like": c1, "message_entities": c2, "rag_chunks_like": c3, "messages_fts": c4})

            rows = con.execute(
                """
                SELECT source_name, created_ts, author, text, message_id
                FROM messages
                WHERE UPPER(text) LIKE UPPER(?) OR UPPER(raw_block) LIKE UPPER(?)
                ORDER BY COALESCE(NULLIF(created_ts_utc,''), created_ts)
                LIMIT 50
                """,
                (like, like),
            ).fetchall()
            st.dataframe(rows_to_df(rows), use_container_width=True)

    with tab5:
        rows = con.execute(
            "SELECT created_at, question, answer, elapsed_ms FROM qa_history ORDER BY qa_id DESC LIMIT 100"
        ).fetchall()
        st.dataframe(rows_to_df(rows), use_container_width=True)


if __name__ == "__main__":
    main()

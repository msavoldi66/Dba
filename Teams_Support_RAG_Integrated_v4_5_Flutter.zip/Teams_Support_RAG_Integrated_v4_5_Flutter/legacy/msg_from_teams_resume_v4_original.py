#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
msg_from_teams_resume_v4.py

Scarica messaggi Microsoft Teams tramite Microsoft Graph con resume/checkpoint.

Supporta:
- --mode chat    -> /chats/{chat-id}/messages
- --mode channel -> /teams/{team-id}/channels/{channel-id}/messages
- --team-id e --channel-id per i canali Teams
- --from-datetime e --to-datetime
- --list-channels per recuperare gli ID dei canali di un Team
- resume tramite download_state.json
- output TXT compatibile con il parser RAG: messaggi_chat.txt
- ricostruzione risposte tramite replyToId e citazioni HTML Teams

Esempio canale:
  python msg_from_teams_resume_v4.py ^
    --mode channel ^
    --team-id "bfa8e0cb-df13-4261-bf0b-36ea24021fe5" ^
    --channel-id "19:862c35e429614d0f856117baacfa990c@thread.tacv2" ^
    --out-dir out_teams_2026 ^
    --from-datetime "2026-05-26T00:00:00Z" ^
    --restart
"""

from __future__ import annotations

import argparse
import datetime as dt
import html
import json
import os
import re
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

import requests


GRAPH_BASE = "https://graph.microsoft.com/v1.0"
DEFAULT_TOP = 50


def utc_now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def log(msg: str) -> None:
    print(f"[{utc_now_iso()}] {msg}", flush=True)


def normalize_dt_text(value: str) -> str:
    value = value.strip()
    if value.endswith("Z"):
        return value[:-1] + "+00:00"
    return value


def parse_datetime(value: Optional[str]) -> Optional[dt.datetime]:
    if not value:
        return None

    v = value.strip()
    if not v:
        return None

    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", v):
        v = v + "T00:00:00+00:00"
    else:
        v = v.replace(" ", "T")
        v = normalize_dt_text(v)

    parsed = dt.datetime.fromisoformat(v)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=dt.timezone.utc)
    else:
        parsed = parsed.astimezone(dt.timezone.utc)
    return parsed


def message_datetime(m: Dict[str, Any]) -> Optional[dt.datetime]:
    return parse_datetime(m.get("createdDateTime") or m.get("lastModifiedDateTime"))


def load_token(args: argparse.Namespace) -> str:
    if args.token:
        return args.token.strip()

    if args.token_file:
        p = Path(args.token_file)
        if not p.exists():
            raise FileNotFoundError(f"Token file non trovato: {p}")
        token = p.read_text(encoding="utf-8").strip()
        if token:
            return token

    token = os.environ.get(args.token_env, "").strip()
    if token:
        return token

    raise RuntimeError(
        "Access token Graph non trovato. Usa --token, --token-file oppure "
        f"variabile ambiente {args.token_env}."
    )


def state_path(out_dir: Path) -> Path:
    return out_dir / "download_state.json"


def checkpoint_path(out_dir: Path) -> Path:
    return out_dir / "messages_checkpoint.jsonl"


def final_jsonl_path(out_dir: Path) -> Path:
    return out_dir / "messages_final.jsonl"


def txt_path(out_dir: Path) -> Path:
    return out_dir / "messaggi_chat.txt"


def load_state(out_dir: Path) -> Dict[str, Any]:
    p = state_path(out_dir)
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        backup = p.with_suffix(".json.corrupt")
        p.replace(backup)
        log(f"ATTENZIONE: stato corrotto spostato in {backup}")
        return {}


def save_state(out_dir: Path, state: Dict[str, Any]) -> None:
    p = state_path(out_dir)
    tmp = p.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(p)


def strip_html_to_text(value: Optional[str]) -> str:
    if not value:
        return ""

    text = value
    text = re.sub(r"(?is)<(script|style).*?>.*?</\1>", " ", text)
    text = re.sub(r"(?i)<br\s*/?>", "\n", text)
    text = re.sub(r"(?i)</p\s*>", "\n", text)
    text = re.sub(r"(?s)<[^>]+>", " ", text)
    text = html.unescape(text)
    text = text.replace("\xa0", " ")
    text = re.sub(r"[ \t\r\f\v]+", " ", text)
    text = re.sub(r"\n\s+", "\n", text)
    return text.strip()


def remove_blockquotes_from_html(value: Optional[str]) -> str:
    """Rimuove i blocchi quote dal body HTML, quando presenti."""
    if not value:
        return ""
    return re.sub(r"(?is)<blockquote.*?>.*?</blockquote>", " ", value)


def extract_quoted_reply_from_html(value: Optional[str]) -> Optional[Dict[str, str]]:
    """
    Teams a volte inserisce il messaggio citato dentro un <blockquote>.
    Questa funzione prova a estrarlo, in modo tollerante rispetto ai vari HTML prodotti da Teams.
    """
    if not value:
        return None

    m = re.search(r"(?is)<blockquote.*?>(.*?)</blockquote>", value)
    if not m:
        return None

    quote_html = m.group(1)
    quote_text = strip_html_to_text(quote_html)
    if not quote_text:
        return None

    quoted_author = ""
    quoted_datetime = ""

    # Esempio tipico: "DRAGOS GEORGE ANDREAS 27/05/2026 18:15"
    m2 = re.search(
        r"(?im)^([A-ZÀ-Ü][A-ZÀ-Ü' .-]{2,80})\s+(\d{1,2}/\d{1,2}/\d{4}\s+\d{1,2}:\d{2})",
        quote_text,
    )
    if m2:
        quoted_author = m2.group(1).strip()
        quoted_datetime = m2.group(2).strip()

    return {
        "quoted_text": quote_text,
        "quoted_author": quoted_author,
        "quoted_datetime": quoted_datetime,
    }


def normalize_message(
    m: Dict[str, Any],
    source_mode: str,
    team_id: Optional[str],
    channel_id: Optional[str],
) -> Dict[str, Any]:
    body = m.get("body") or {}
    from_obj = m.get("from") or {}
    user = from_obj.get("user") or {}
    app = from_obj.get("application") or {}

    author = (
        user.get("displayName")
        or app.get("displayName")
        or m.get("fromDisplayName")
        or "Sconosciuto"
    )

    content_html = body.get("content") or ""
    quote = extract_quoted_reply_from_html(content_html)
    html_without_quote = remove_blockquotes_from_html(content_html)

    content_text = strip_html_to_text(html_without_quote or content_html)
    full_text = strip_html_to_text(content_html)

    reply_to_id = (
        m.get("replyToId")
        or m.get("replyToMessageId")
        or m.get("parentMessageId")
    )

    return {
        "id": m.get("id") or "",
        "createdDateTime": m.get("createdDateTime") or m.get("lastModifiedDateTime") or "",
        "lastModifiedDateTime": m.get("lastModifiedDateTime"),
        "deletedDateTime": m.get("deletedDateTime"),
        "importance": m.get("importance"),
        "messageType": m.get("messageType"),
        "subject": m.get("subject"),
        "summary": m.get("summary"),
        "chatId": m.get("chatId"),
        "replyToId": reply_to_id,
        "etag": m.get("etag"),
        "author": author,
        "from": from_obj,
        "body_content_type": body.get("contentType"),
        "body_html": content_html,
        "text": content_text,
        "full_text_with_quote": full_text,
        "quoted_reply": quote,
        "is_reply": bool(reply_to_id or quote),
        "reply_context": None,
        "attachments": m.get("attachments") or [],
        "mentions": m.get("mentions") or [],
        "reactions": m.get("reactions") or [],
        "source_mode": source_mode,
        "team_id": team_id,
        "channel_id": channel_id,
        "raw": m,
    }


def read_existing_ids(out_dir: Path) -> Set[str]:
    ids: Set[str] = set()
    p = checkpoint_path(out_dir)
    if not p.exists():
        return ids

    with p.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
                mid = obj.get("id")
                if mid:
                    ids.add(mid)
            except Exception:
                continue
    return ids


def append_messages(out_dir: Path, messages: Iterable[Dict[str, Any]]) -> int:
    p = checkpoint_path(out_dir)
    count = 0
    with p.open("a", encoding="utf-8") as f:
        for m in messages:
            f.write(json.dumps(m, ensure_ascii=False) + "\n")
            count += 1
    return count


def graph_get_json(
    url: str,
    token: str,
    timeout: int,
    max_retries: int,
    verify_ssl: bool,
) -> Dict[str, Any]:
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
    }

    last_exc: Optional[BaseException] = None

    for attempt in range(1, max_retries + 1):
        try:
            r = requests.get(url, headers=headers, timeout=timeout, verify=verify_ssl)

            if r.status_code == 429:
                retry_after = r.headers.get("Retry-After")
                sleep_s = int(retry_after) if retry_after and retry_after.isdigit() else min(60, 2 ** attempt)
                log(f"HTTP 429 throttling. Attendo {sleep_s}s e riprovo...")
                time.sleep(sleep_s)
                continue

            if 500 <= r.status_code <= 599:
                sleep_s = min(60, 2 ** attempt)
                log(f"HTTP {r.status_code}. Attendo {sleep_s}s e riprovo...")
                time.sleep(sleep_s)
                continue

            if r.status_code >= 400:
                body = r.text[:4000]
                raise RuntimeError(f"Errore Graph HTTP {r.status_code}: {body}")

            return r.json()

        except requests.RequestException as exc:
            last_exc = exc
            sleep_s = min(60, 2 ** attempt)
            log(f"Errore rete: {exc}. Attendo {sleep_s}s e riprovo...")
            time.sleep(sleep_s)

    if last_exc:
        raise RuntimeError(f"Errore Graph dopo {max_retries} tentativi: {last_exc}") from last_exc
    raise RuntimeError(f"Errore Graph dopo {max_retries} tentativi")


def build_initial_url(args: argparse.Namespace) -> str:
    if args.mode == "chat":
        if not args.chat_id:
            raise ValueError("Con --mode chat devi indicare --chat-id")
        return f"{GRAPH_BASE}/chats/{args.chat_id}/messages?$top={args.top}"

    if args.mode == "channel":
        if not args.team_id:
            raise ValueError("Con --mode channel devi indicare --team-id")
        if not args.channel_id:
            raise ValueError("Con --mode channel devi indicare --channel-id")
        return f"{GRAPH_BASE}/teams/{args.team_id}/channels/{args.channel_id}/messages?$top={args.top}"

    raise ValueError(f"Modalità non supportata: {args.mode}")


def filter_by_datetime(
    messages: List[Dict[str, Any]],
    from_dt: Optional[dt.datetime],
    to_dt: Optional[dt.datetime],
) -> Tuple[List[Dict[str, Any]], bool]:
    accepted: List[Dict[str, Any]] = []
    stop_for_from_dt = False

    for m in messages:
        mts = message_datetime(m)
        if mts is None:
            if from_dt is None and to_dt is None:
                accepted.append(m)
            continue

        if to_dt is not None and mts > to_dt:
            continue

        if from_dt is not None and mts < from_dt:
            stop_for_from_dt = True
            continue

        accepted.append(m)

    return accepted, stop_for_from_dt


def build_source_signature(args: argparse.Namespace) -> str:
    if args.mode == "chat":
        return f"chat:{args.chat_id}"
    return f"channel:{args.team_id}:{args.channel_id}"


def download_messages(args: argparse.Namespace) -> None:
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    from_dt = parse_datetime(args.from_datetime)
    to_dt = parse_datetime(args.to_datetime)

    if from_dt:
        log(f"Filtro from-datetime attivo: {from_dt.isoformat()}")
    if to_dt:
        log(f"Filtro to-datetime attivo: {to_dt.isoformat()}")
    if from_dt and to_dt and from_dt > to_dt:
        raise ValueError("--from-datetime non può essere maggiore di --to-datetime")

    token = load_token(args)
    state = load_state(out_dir)

    existing_ids = read_existing_ids(out_dir)
    log(f"Messaggi già presenti nel checkpoint: {len(existing_ids)}")

    if args.restart:
        log("Opzione --restart attiva: ignoro download_state.json e riparto dall'inizio.")
        state = {}

    if state.get("completed") and not args.force_if_completed:
        log("Download già marcato completed. Usa --force-if-completed per continuare comunque.")
        return

    current_signature = build_source_signature(args)
    previous_signature = state.get("source_signature")

    if state and not args.restart and previous_signature and previous_signature != current_signature:
        log("ATTENZIONE: sorgente Graph diversa da quella salvata nello stato.")
        log("Consiglio: usa --restart oppure una nuova --out-dir.")

    previous_from = state.get("from_datetime")
    previous_to = state.get("to_datetime")
    current_from = args.from_datetime or ""
    current_to = args.to_datetime or ""

    if state and not args.restart and (previous_from != current_from or previous_to != current_to):
        log("ATTENZIONE: filtri temporali diversi da quelli salvati nello stato.")
        log("Consiglio: usa --restart oppure una nuova --out-dir.")

    next_link = state.get("next_link")
    if next_link:
        log("Ripartenza da nextLink salvato.")
        url = next_link
    else:
        url = build_initial_url(args)
        log("Partenza dall'endpoint iniziale Graph.")

    fetched_total = int(state.get("fetched_total", 0))
    inserted_total = int(state.get("inserted_total", len(existing_ids)))
    skipped_by_date_total = int(state.get("skipped_by_date_total", 0))
    page_no = int(state.get("page_no", 0))

    verify_ssl = not args.no_verify_ssl

    while url:
        page_no += 1
        log(f"Scarico pagina {page_no}: {url[:180]}...")

        data = graph_get_json(
            url=url,
            token=token,
            timeout=args.timeout,
            max_retries=args.max_retries,
            verify_ssl=verify_ssl,
        )

        values = data.get("value") or []
        fetched_total += len(values)

        normalized_all: List[Dict[str, Any]] = [
            normalize_message(
                m,
                source_mode=args.mode,
                team_id=args.team_id,
                channel_id=args.channel_id,
            )
            for m in values
        ]

        normalized_in_range, stop_for_from_dt = filter_by_datetime(normalized_all, from_dt, to_dt)
        skipped_by_date = len(normalized_all) - len(normalized_in_range)
        skipped_by_date_total += skipped_by_date

        normalized_to_write: List[Dict[str, Any]] = []
        duplicate_count = 0

        for m in normalized_in_range:
            mid = m.get("id")
            if mid and mid in existing_ids:
                duplicate_count += 1
                continue
            if mid:
                existing_ids.add(mid)
            normalized_to_write.append(m)

        inserted = append_messages(out_dir, normalized_to_write)
        inserted_total += inserted

        next_link = data.get("@odata.nextLink")
        should_stop = bool(stop_for_from_dt and args.stop_when_older_than_from)

        state = {
            "source_signature": current_signature,
            "mode": args.mode,
            "chat_id": args.chat_id,
            "team_id": args.team_id,
            "channel_id": args.channel_id,
            "next_link": None if should_stop else next_link,
            "completed": bool((not next_link) or should_stop),
            "stop_reason": "older_than_from_datetime" if should_stop else ("graph_completed" if not next_link else ""),
            "from_datetime": args.from_datetime or "",
            "to_datetime": args.to_datetime or "",
            "page_no": page_no,
            "fetched_total": fetched_total,
            "inserted_total": inserted_total,
            "duplicates_skipped_total": max(0, fetched_total - inserted_total - skipped_by_date_total),
            "skipped_by_date_total": skipped_by_date_total,
            "last_page_fetched": len(values),
            "last_page_in_range": len(normalized_in_range),
            "last_page_inserted": inserted,
            "last_page_duplicates": duplicate_count,
            "last_page_skipped_by_date": skipped_by_date,
            "last_update": utc_now_iso(),
            "checkpoint_file": str(checkpoint_path(out_dir)),
        }
        save_state(out_dir, state)

        log(
            f"Pagina {page_no}: ricevuti={len(values)}, in_range={len(normalized_in_range)}, "
            f"inseriti={inserted}, duplicati={duplicate_count}, scartati_data={skipped_by_date}, "
            f"totale_inseriti={inserted_total}"
        )

        if should_stop:
            log("Trovati messaggi più vecchi di --from-datetime: stop anticipato.")
            break

        if args.max_pages and page_no >= args.max_pages:
            log(f"Raggiunto limite --max-pages={args.max_pages}. Stato salvato per resume.")
            break

        url = next_link

        if args.sleep_between_pages > 0:
            time.sleep(args.sleep_between_pages)

    if not url or state.get("completed"):
        log("Download completato o fermato per filtro temporale. Creo output finali...")
        create_final_outputs(out_dir, from_dt=from_dt, to_dt=to_dt)
        state = load_state(out_dir)
        state["completed"] = True
        state["completed_at"] = utc_now_iso()
        save_state(out_dir, state)
        log(f"Completato. File TXT: {txt_path(out_dir)}")


def iter_checkpoint_messages(out_dir: Path) -> Iterable[Dict[str, Any]]:
    p = checkpoint_path(out_dir)
    if not p.exists():
        return

    with p.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                yield json.loads(line)
            except Exception:
                continue


def enrich_reply_context(messages: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Arricchisce i messaggi con reply_context usando:
    1. replyToId, se Graph lo valorizza e il messaggio originale è nel checkpoint.
    2. quoted_reply, se Teams ha incorporato la citazione nel body HTML.
    """
    by_id: Dict[str, Dict[str, Any]] = {}
    for m in messages:
        mid = m.get("id")
        if mid:
            by_id[mid] = m

    enriched: List[Dict[str, Any]] = []

    for m in messages:
        reply_context = None

        reply_to_id = m.get("replyToId")
        if reply_to_id and reply_to_id in by_id:
            parent = by_id[reply_to_id]
            reply_context = {
                "source": "replyToId",
                "id": parent.get("id"),
                "createdDateTime": parent.get("createdDateTime"),
                "author": parent.get("author"),
                "text": parent.get("text") or parent.get("full_text_with_quote") or "",
            }

        if reply_context is None and m.get("quoted_reply"):
            q = m.get("quoted_reply") or {}
            reply_context = {
                "source": "quoted_reply_html",
                "id": None,
                "createdDateTime": q.get("quoted_datetime") or "",
                "author": q.get("quoted_author") or "",
                "text": q.get("quoted_text") or "",
            }

        m = dict(m)
        m["reply_context"] = reply_context
        m["is_reply"] = bool(reply_context or m.get("replyToId") or m.get("quoted_reply"))
        enriched.append(m)

    return enriched


def create_final_outputs(
    out_dir: Path,
    from_dt: Optional[dt.datetime] = None,
    to_dt: Optional[dt.datetime] = None,
) -> None:
    messages = list(iter_checkpoint_messages(out_dir))

    filtered: List[Dict[str, Any]] = []
    seen: Set[str] = set()

    for m in messages:
        mid = m.get("id")
        if mid and mid in seen:
            continue
        if mid:
            seen.add(mid)

        mts = message_datetime(m)
        if mts is not None:
            if from_dt is not None and mts < from_dt:
                continue
            if to_dt is not None and mts > to_dt:
                continue

        filtered.append(m)

    messages_asc = sorted(filtered, key=lambda x: x.get("createdDateTime") or "")
    messages_asc = enrich_reply_context(messages_asc)
    messages_desc = list(reversed(messages_asc))

    with final_jsonl_path(out_dir).open("w", encoding="utf-8") as f:
        for m in messages_asc:
            f.write(json.dumps(m, ensure_ascii=False) + "\n")

    sep = "-" * 120
    with txt_path(out_dir).open("w", encoding="utf-8") as f:
        for m in messages_desc:
            ts = m.get("createdDateTime") or ""
            author = m.get("author") or "Sconosciuto"
            text = (m.get("text") or "").strip()
            reply_context = m.get("reply_context")

            if reply_context:
                f.write(f"[{ts}] {author}:\n")
                f.write("  >>> IN RISPOSTA A")
                source = reply_context.get("source") or ""
                if source:
                    f.write(f" ({source})")
                f.write(":\n")

                rts = reply_context.get("createdDateTime") or ""
                rauthor = reply_context.get("author") or "Autore non disponibile"
                rtext = (reply_context.get("text") or "").strip()

                if rts or rauthor:
                    f.write(f"  >>> [{rts}] {rauthor}:\n")
                if rtext:
                    for line in rtext.splitlines():
                        f.write(f"  >>> {line}\n")
                f.write("  >>>\n")
                f.write(f"{text}\n")
            else:
                f.write(f"[{ts}] {author}: {text}\n")

            f.write(sep + "\n")


def rebuild_outputs(args: argparse.Namespace) -> None:
    out_dir = Path(args.out_dir)
    if not checkpoint_path(out_dir).exists():
        raise FileNotFoundError(f"Checkpoint non trovato: {checkpoint_path(out_dir)}")

    from_dt = parse_datetime(args.from_datetime)
    to_dt = parse_datetime(args.to_datetime)

    create_final_outputs(out_dir, from_dt=from_dt, to_dt=to_dt)
    log(f"Rigenerati: {final_jsonl_path(out_dir)} e {txt_path(out_dir)}")


def print_status(args: argparse.Namespace) -> None:
    out_dir = Path(args.out_dir)
    state = load_state(out_dir)
    ids = read_existing_ids(out_dir)

    print(json.dumps({
        "out_dir": str(out_dir),
        "state_file": str(state_path(out_dir)),
        "checkpoint_file": str(checkpoint_path(out_dir)),
        "checkpoint_messages_unique": len(ids),
        "state": state,
    }, ensure_ascii=False, indent=2))


def list_channels(args: argparse.Namespace) -> None:
    if not args.team_id:
        raise ValueError("Per --list-channels devi indicare --team-id")

    token = load_token(args)
    verify_ssl = not args.no_verify_ssl

    url = f"{GRAPH_BASE}/teams/{args.team_id}/channels"
    all_channels: List[Dict[str, Any]] = []

    while url:
        data = graph_get_json(
            url=url,
            token=token,
            timeout=args.timeout,
            max_retries=args.max_retries,
            verify_ssl=verify_ssl,
        )
        all_channels.extend(data.get("value") or [])
        url = data.get("@odata.nextLink")

    print(json.dumps(all_channels, ensure_ascii=False, indent=2))

    print("\nCanali trovati:")
    for c in all_channels:
        print(f"- {c.get('displayName')} | {c.get('id')}")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Scarica messaggi Teams da Microsoft Graph con resume/checkpoint, chat o canale."
    )

    p.add_argument("--mode", choices=["chat", "channel"], default="chat", help="Sorgente: chat oppure channel")
    p.add_argument("--chat-id", help="ID chat Teams, es. 19:xxxx@thread.v2")
    p.add_argument("--team-id", help="ID Team Teams, es. bfa8e0cb-df13-4261-bf0b-36ea24021fe5")
    p.add_argument("--channel-id", help="ID canale Teams, es. 19:xxxx@thread.tacv2")
    p.add_argument("--list-channels", action="store_true", help="Elenca i canali del team indicato con --team-id")

    p.add_argument("--out-dir", default="out_teams", help="Directory output/checkpoint")
    p.add_argument("--top", type=int, default=DEFAULT_TOP, help="Page size Graph")
    p.add_argument("--token", help="Access token Graph passato direttamente")
    p.add_argument("--token-file", help="File contenente access token Graph")
    p.add_argument("--token-env", default="GRAPH_ACCESS_TOKEN", help="Nome variabile ambiente token")
    p.add_argument("--timeout", type=int, default=60)
    p.add_argument("--max-retries", type=int, default=6)
    p.add_argument("--sleep-between-pages", type=float, default=0.0)
    p.add_argument("--max-pages", type=int, default=0, help="Limite pagine per test; 0 = nessun limite")
    p.add_argument("--restart", action="store_true", help="Ignora nextLink salvato e riparte dall'inizio")
    p.add_argument("--force-if-completed", action="store_true", help="Continua anche se stato completed")
    p.add_argument("--no-verify-ssl", action="store_true", help="Disabilita verifica SSL; usare solo se necessario")
    p.add_argument("--rebuild-outputs", action="store_true", help="Rigenera JSONL finale e TXT da checkpoint")
    p.add_argument("--status", action="store_true", help="Mostra stato download")

    p.add_argument("--from-datetime", help="Data/ora minima messaggi, es. 2026-05-26T00:00:00Z oppure 2026-05-26")
    p.add_argument("--to-datetime", help="Data/ora massima messaggi, es. 2026-05-26T23:59:59Z")
    p.add_argument(
        "--stop-when-older-than-from",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Ferma il download quando trova messaggi più vecchi di --from-datetime. Default: true",
    )

    return p


def validate_args(args: argparse.Namespace) -> None:
    if args.status or args.rebuild_outputs:
        return

    if args.list_channels:
        if not args.team_id:
            raise ValueError("--list-channels richiede --team-id")
        return

    if args.mode == "chat":
        if not args.chat_id:
            raise ValueError("--mode chat richiede --chat-id")

    if args.mode == "channel":
        if not args.team_id:
            raise ValueError("--mode channel richiede --team-id")
        if not args.channel_id:
            raise ValueError("--mode channel richiede --channel-id")


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    try:
        validate_args(args)

        if args.status:
            print_status(args)
            return 0

        if args.list_channels:
            list_channels(args)
            return 0

        if args.rebuild_outputs:
            rebuild_outputs(args)
            return 0

        download_messages(args)
        return 0

    except KeyboardInterrupt:
        log("Interrotto da tastiera. Lo stato è stato salvato all'ultima pagina completata.")
        return 130
    except Exception as exc:
        log(f"ERRORE: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
msg_from_teams.py

Scarica messaggi da Microsoft Teams usando Microsoft Graph API.

Funzionalità principali:
- Recupero token automatico con MSAL Device Code Flow.
- Cache token locale in msal_token_cache.bin.
- Lettura configurazione da config.ini.
- Download messaggi da:
    1) chat Teams: /me/chats e /chats/{chat-id}/messages
    2) canali Teams: /teams/{team-id}/channels e /teams/{team-id}/channels/{channel-id}/messages
- Gestione paginazione Graph tramite @odata.nextLink.
- Salvataggio output in JSON.
- Salvataggio opzionale in TXT leggibile.

Dipendenze:
    pip install msal requests beautifulsoup4

Esempi:
    python msg_from_teams.py --mode chats
    python msg_from_teams.py --mode team --team-id "ID_DEL_TEAM"
    python msg_from_teams.py --mode channel --team-id "ID_DEL_TEAM" --channel-id "ID_DEL_CANALE"
    python msg_from_teams.py --mode chats --output messages.json --txt messaggi_chat.txt

File config.ini atteso nella stessa cartella:

[azure]
tenant_id = INSERISCI_TENANT_ID
client_id = INSERISCI_CLIENT_ID
authority = https://login.microsoftonline.com/INSERISCI_TENANT_ID

[graph]
scopes = User.Read Chat.Read Chat.ReadBasic ChannelMessage.Read.All
base_url = https://graph.microsoft.com/v1.0

[default]
team_id =
channel_id =
output_json = messages.json
output_txt = messaggi_chat.txt
"""

import argparse
import configparser
import json
import re
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import requests

try:
    import msal
except ImportError:
    msal = None

try:
    from bs4 import BeautifulSoup
except ImportError:
    BeautifulSoup = None


BASE_DIR = Path(__file__).resolve().parent
CONFIG_FILE = BASE_DIR / "config.ini"
TOKEN_CACHE_FILE = BASE_DIR / "msal_token_cache.bin"
ACCESS_TOKEN_FILE = BASE_DIR / "access_token.txt"


# =============================================================================
# Configurazione
# =============================================================================

def create_sample_config_if_missing() -> None:
    """
    Crea un config.ini di esempio se non esiste.
    """
    if CONFIG_FILE.exists():
        return

    sample = """[azure]
tenant_id = INSERISCI_TENANT_ID
client_id = INSERISCI_CLIENT_ID
authority = https://login.microsoftonline.com/INSERISCI_TENANT_ID

[graph]
scopes = User.Read Chat.Read Chat.ReadBasic ChannelMessage.Read.All
base_url = https://graph.microsoft.com/v1.0

[default]
team_id =
channel_id =
output_json = messages.json
output_txt = messaggi_chat.txt
"""
    CONFIG_FILE.write_text(sample, encoding="utf-8")
    print(f"[INFO] Creato file di esempio: {CONFIG_FILE}")
    print("[INFO] Compila tenant_id e client_id prima di rieseguire il programma.")


def load_config() -> configparser.ConfigParser:
    """
    Carica config.ini.
    """
    create_sample_config_if_missing()

    cfg = configparser.ConfigParser()
    cfg.read(CONFIG_FILE, encoding="utf-8")

    return cfg


def get_cfg_value(
    cfg: configparser.ConfigParser,
    section: str,
    key: str,
    default: str = "",
) -> str:
    if cfg.has_section(section) and cfg.has_option(section, key):
        return cfg.get(section, key).strip()
    return default


# =============================================================================
# Autenticazione MSAL / token
# =============================================================================

def load_token_cache():
    """
    Carica la cache MSAL.
    """
    if msal is None:
        raise RuntimeError("Modulo msal non installato. Esegui: pip install msal")

    cache = msal.SerializableTokenCache()

    if TOKEN_CACHE_FILE.exists():
        try:
            cache.deserialize(TOKEN_CACHE_FILE.read_text(encoding="utf-8"))
        except Exception as exc:
            print(f"[WARN] Cache token non leggibile, verrà rigenerata: {exc}")

    return cache


def save_token_cache(cache) -> None:
    """
    Salva la cache MSAL se modificata.
    """
    if cache.has_state_changed:
        TOKEN_CACHE_FILE.write_text(cache.serialize(), encoding="utf-8")


def get_access_token_from_file() -> Optional[str]:
    """
    Fallback: legge access_token.txt se esiste.
    Utile se l'azienda non consente MSAL o se vuoi testare rapidamente.
    """
    if ACCESS_TOKEN_FILE.exists():
        token = ACCESS_TOKEN_FILE.read_text(encoding="utf-8").strip()
        if token:
            print(f"[INFO] Uso token da {ACCESS_TOKEN_FILE}")
            return token
    return None


def get_access_token_msal(cfg: configparser.ConfigParser) -> str:
    """
    Recupera access token Graph con MSAL Device Code Flow.
    Alla prima esecuzione mostra un codice da inserire nel browser.
    Le esecuzioni successive usano la cache.
    """
    if msal is None:
        raise RuntimeError("Modulo msal non installato. Esegui: pip install msal")

    tenant_id = get_cfg_value(cfg, "azure", "tenant_id")
    client_id = get_cfg_value(cfg, "azure", "client_id")
    authority = get_cfg_value(
        cfg,
        "azure",
        "authority",
        f"https://login.microsoftonline.com/{tenant_id}",
    )

    scopes_text = get_cfg_value(
        cfg,
        "graph",
        "scopes",
        "User.Read Chat.Read ChannelMessage.Read.All",
    )
    scopes = scopes_text.split()

    if not tenant_id or tenant_id == "INSERISCI_TENANT_ID":
        raise RuntimeError("tenant_id non configurato in config.ini")

    if not client_id or client_id == "INSERISCI_CLIENT_ID":
        raise RuntimeError("client_id non configurato in config.ini")

    cache = load_token_cache()

    app = msal.PublicClientApplication(
        client_id=client_id,
        authority=authority,
        token_cache=cache,
    )

    result = None
    accounts = app.get_accounts()

    if accounts:
        print("[INFO] Provo recupero token da cache MSAL...")
        result = app.acquire_token_silent(scopes=scopes, account=accounts[0])

    if not result:
        print("[INFO] Token non trovato in cache. Avvio Device Code Flow...")
        flow = app.initiate_device_flow(scopes=scopes)

        if "user_code" not in flow:
            raise RuntimeError(
                "Errore nella creazione del device flow:\n"
                + json.dumps(flow, indent=2)
            )

        print("")
        print(flow["message"])
        print("")

        result = app.acquire_token_by_device_flow(flow)

    save_token_cache(cache)

    if not result or "access_token" not in result:
        raise RuntimeError(
            "Impossibile ottenere access token.\n"
            f"Errore: {result.get('error') if result else 'N/A'}\n"
            f"Descrizione: {result.get('error_description') if result else 'N/A'}"
        )

    return result["access_token"]


def get_access_token(cfg: configparser.ConfigParser, prefer_file_token: bool = False) -> str:
    """
    Recupera access token.
    Default: MSAL automatico.
    Se prefer_file_token=True, prova prima access_token.txt.
    """
    if prefer_file_token:
        token = get_access_token_from_file()
        if token:
            return token

    try:
        return get_access_token_msal(cfg)
    except Exception as exc:
        print(f"[WARN] Recupero token MSAL fallito: {exc}")

        token = get_access_token_from_file()
        if token:
            return token

        raise


# =============================================================================
# Utility Graph API
# =============================================================================

def graph_get(
    url: str,
    token: str,
    timeout: int = 60,
    max_retries: int = 3,
) -> Dict[str, Any]:
    """
    Esegue GET su Microsoft Graph con gestione base di retry e throttling.
    """
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
    }

    for attempt in range(1, max_retries + 1):
        response = requests.get(url, headers=headers, timeout=timeout)

        if response.status_code == 429:
            retry_after = response.headers.get("Retry-After")
            wait_seconds = int(retry_after) if retry_after and retry_after.isdigit() else 10
            print(f"[WARN] Throttling Graph 429. Attendo {wait_seconds}s...")
            time.sleep(wait_seconds)
            continue

        if 500 <= response.status_code < 600:
            print(f"[WARN] Errore server Graph {response.status_code}, tentativo {attempt}/{max_retries}")
            time.sleep(3 * attempt)
            continue

        if response.status_code >= 400:
            raise RuntimeError(
                f"Errore Graph API {response.status_code}\n"
                f"URL: {url}\n"
                f"Risposta: {response.text}"
            )

        return response.json()

    raise RuntimeError(f"Chiamata Graph fallita dopo {max_retries} tentativi: {url}")


def graph_get_all_pages(url: str, token: str) -> List[Dict[str, Any]]:
    """
    Recupera tutte le pagine di un endpoint Graph che ritorna value + @odata.nextLink.
    """
    items: List[Dict[str, Any]] = []
    page = 1

    while url:
        print(f"[INFO] Scarico pagina {page}: {url}")
        data = graph_get(url, token)

        value = data.get("value", [])
        if isinstance(value, list):
            items.extend(value)

        url = data.get("@odata.nextLink")
        page += 1

    return items


def build_url(base_url: str, path: str) -> str:
    """
    Compone URL Graph.
    """
    return base_url.rstrip("/") + "/" + path.lstrip("/")


# =============================================================================
# Download Teams
# =============================================================================

def list_my_chats(base_url: str, token: str) -> List[Dict[str, Any]]:
    url = build_url(base_url, "/me/chats?$top=50")
    return graph_get_all_pages(url, token)


def list_chat_messages(base_url: str, token: str, chat_id: str) -> List[Dict[str, Any]]:
    url = build_url(base_url, f"/chats/{chat_id}/messages?$top=50")
    messages = graph_get_all_pages(url, token)

    for m in messages:
        m["_source_type"] = "chat"
        m["_chat_id"] = chat_id

    return messages


def list_team_channels(base_url: str, token: str, team_id: str) -> List[Dict[str, Any]]:
    url = build_url(base_url, f"/teams/{team_id}/channels?$top=50")
    return graph_get_all_pages(url, token)


def list_channel_messages(
    base_url: str,
    token: str,
    team_id: str,
    channel_id: str,
) -> List[Dict[str, Any]]:
    url = build_url(
        base_url,
        f"/teams/{team_id}/channels/{channel_id}/messages?$top=50",
    )

    messages = graph_get_all_pages(url, token)

    for m in messages:
        m["_source_type"] = "channel"
        m["_team_id"] = team_id
        m["_channel_id"] = channel_id

    return messages


def download_all_my_chat_messages(base_url: str, token: str) -> List[Dict[str, Any]]:
    """
    Scarica i messaggi da tutte le chat visibili all'utente.
    """
    chats = list_my_chats(base_url, token)
    print(f"[INFO] Chat trovate: {len(chats)}")

    all_messages: List[Dict[str, Any]] = []

    for idx, chat in enumerate(chats, start=1):
        chat_id = chat.get("id")
        topic = chat.get("topic") or chat.get("chatType") or ""

        if not chat_id:
            continue

        print(f"[INFO] Chat {idx}/{len(chats)} - {topic} - {chat_id}")

        try:
            messages = list_chat_messages(base_url, token, chat_id)
            for m in messages:
                m["_chat"] = chat
            all_messages.extend(messages)
        except Exception as exc:
            print(f"[WARN] Errore scaricando chat {chat_id}: {exc}")

    return all_messages


def download_team_channel_messages(
    base_url: str,
    token: str,
    team_id: str,
) -> List[Dict[str, Any]]:
    """
    Scarica i messaggi da tutti i canali di un Team.
    """
    channels = list_team_channels(base_url, token, team_id)
    print(f"[INFO] Canali trovati nel Team {team_id}: {len(channels)}")

    all_messages: List[Dict[str, Any]] = []

    for idx, channel in enumerate(channels, start=1):
        channel_id = channel.get("id")
        name = channel.get("displayName") or ""

        if not channel_id:
            continue

        print(f"[INFO] Canale {idx}/{len(channels)} - {name} - {channel_id}")

        try:
            messages = list_channel_messages(base_url, token, team_id, channel_id)
            for m in messages:
                m["_channel"] = channel
            all_messages.extend(messages)
        except Exception as exc:
            print(f"[WARN] Errore scaricando canale {channel_id}: {exc}")

    return all_messages


# =============================================================================
# Normalizzazione output TXT
# =============================================================================

def html_to_text(value: Any) -> str:
    if value is None:
        return ""

    text = str(value)

    if BeautifulSoup is not None:
        soup = BeautifulSoup(text, "html.parser")
        return soup.get_text(separator=" ", strip=True)

    text = re.sub(r"<br\s*/?>", "\n", text, flags=re.IGNORECASE)
    text = re.sub(r"</p\s*>", "\n", text, flags=re.IGNORECASE)
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def safe_get(data: Dict[str, Any], path: str, default: Any = "") -> Any:
    current: Any = data

    for part in path.split("."):
        if not isinstance(current, dict):
            return default

        current = current.get(part)

        if current is None:
            return default

    return current


def get_sender_name(message: Dict[str, Any]) -> str:
    name = safe_get(message, "from.user.displayName")
    email = safe_get(message, "from.user.email")
    app = safe_get(message, "from.application.displayName")

    if name and email:
        return f"{name} <{email}>"
    if name:
        return name
    if email:
        return email
    if app:
        return f"Application: {app}"

    return "Mittente non disponibile"


def message_to_text_line(message: Dict[str, Any]) -> str:
    created = message.get("createdDateTime") or ""
    sender = get_sender_name(message)
    body_html = safe_get(message, "body.content")
    body_text = html_to_text(body_html)

    source_type = message.get("_source_type", "")
    chat_id = message.get("_chat_id", "") or message.get("chatId", "")
    team_id = message.get("_team_id", "") or message.get("teamId", "")
    channel_id = message.get("_channel_id", "") or message.get("channelId", "")

    source_parts = []
    if source_type:
        source_parts.append(f"type={source_type}")
    if chat_id:
        source_parts.append(f"chat={chat_id}")
    if team_id:
        source_parts.append(f"team={team_id}")
    if channel_id:
        source_parts.append(f"channel={channel_id}")

    source = " | ".join(source_parts)

    return (
        f"[{created}] {sender}\n"
        f"{body_text}\n"
        f"{source}\n"
        f"{'-' * 100}\n"
    )


def save_json(messages: List[Dict[str, Any]], output_file: Path) -> None:
    output_file.parent.mkdir(parents=True, exist_ok=True)
    output_file.write_text(
        json.dumps(messages, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"[OK] File JSON creato: {output_file}")


def save_txt(messages: List[Dict[str, Any]], output_file: Path) -> None:
    output_file.parent.mkdir(parents=True, exist_ok=True)

    lines = [message_to_text_line(m) for m in messages]
    output_file.write_text("\n".join(lines), encoding="utf-8")

    print(f"[OK] File TXT creato: {output_file}")


# =============================================================================
# CLI
# =============================================================================

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Scarica messaggi Teams tramite Microsoft Graph."
    )

    parser.add_argument(
        "--mode",
        choices=["chats", "team", "channel"],
        default="chats",
        help=(
            "chats = scarica messaggi dalle chat dell'utente; "
            "team = scarica messaggi da tutti i canali del Team; "
            "channel = scarica messaggi da un singolo canale."
        ),
    )

    parser.add_argument(
        "--team-id",
        default="",
        help="ID del Team. Necessario per --mode team o --mode channel.",
    )

    parser.add_argument(
        "--channel-id",
        default="",
        help="ID del canale. Necessario per --mode channel.",
    )

    parser.add_argument(
        "--output",
        default="",
        help="File JSON output. Default letto da config.ini o messages.json.",
    )

    parser.add_argument(
        "--txt",
        default="",
        help="File TXT output opzionale. Se omesso usa config.ini; usa --no-txt per disabilitare.",
    )

    parser.add_argument(
        "--no-txt",
        action="store_true",
        help="Non genera file TXT.",
    )

    parser.add_argument(
        "--prefer-file-token",
        action="store_true",
        help="Prova prima access_token.txt invece del recupero automatico MSAL.",
    )

    return parser.parse_args()


def main() -> int:
    args = parse_args()
    cfg = load_config()

    base_url = get_cfg_value(
        cfg,
        "graph",
        "base_url",
        "https://graph.microsoft.com/v1.0",
    )

    default_team_id = get_cfg_value(cfg, "default", "team_id")
    default_channel_id = get_cfg_value(cfg, "default", "channel_id")
    default_output_json = get_cfg_value(cfg, "default", "output_json", "messages.json")
    default_output_txt = get_cfg_value(cfg, "default", "output_txt", "messaggi_chat.txt")

    team_id = args.team_id or default_team_id
    channel_id = args.channel_id or default_channel_id

    output_json = Path(args.output or default_output_json).resolve()

    if args.no_txt:
        output_txt = None
    else:
        output_txt = Path(args.txt or default_output_txt).resolve()

    token = get_access_token(cfg, prefer_file_token=args.prefer_file_token)

    if args.mode == "chats":
        messages = download_all_my_chat_messages(base_url, token)

    elif args.mode == "team":
        if not team_id:
            raise RuntimeError("Per --mode team devi indicare --team-id o default.team_id in config.ini")
        messages = download_team_channel_messages(base_url, token, team_id)

    elif args.mode == "channel":
        if not team_id:
            raise RuntimeError("Per --mode channel devi indicare --team-id o default.team_id in config.ini")
        if not channel_id:
            raise RuntimeError("Per --mode channel devi indicare --channel-id o default.channel_id in config.ini")
        messages = list_channel_messages(base_url, token, team_id, channel_id)

    else:
        raise RuntimeError(f"Mode non supportato: {args.mode}")

    print(f"[INFO] Messaggi totali scaricati: {len(messages)}")

    save_json(messages, output_json)

    if output_txt is not None:
        save_txt(messages, output_txt)

    print("[OK] Operazione completata.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("\n[WARN] Interrotto dall'utente.")
        raise SystemExit(130)
    except Exception as exc:
        print(f"[ERRORE] {exc}", file=sys.stderr)
        raise SystemExit(1)

@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" call SETUP_ONLY.cmd
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe tests\self_test.py
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe tests\test_incremental_watermark.py
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe tests\test_multi_source.py
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe tests\test_timezone_rome.py
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe -m py_compile src\flutter_api_server.py
if errorlevel 1 exit /b 1
echo FLUTTER API PYTHON COMPILE OK
endlocal

@echo off
cd /d "%~dp0"
call RUN_FLUTTER_APP.cmd

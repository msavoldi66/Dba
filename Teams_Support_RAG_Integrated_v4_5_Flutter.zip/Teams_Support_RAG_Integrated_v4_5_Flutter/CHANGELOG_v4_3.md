# Changelog v4.3.0

## Download multi-chat parametrizzato

La pipeline non usa piu una singola chat hardcoded in `RUN_ALL.cmd`.
Le sorgenti da scaricare sono definite in:

```text
config/teams_sources.csv
```

Colonne:

```text
enabled,source_name,mode,chat_id,team_id,channel_id,from_datetime,overlap_hours
```

Sono gia abilitate due chat:

1. `19:meeting_NTc0OTlmZDAtZTUzMy00ZTBiLWI3MWItMjM4YmQ4ZjExZDZm@thread.v2`
2. `19:meeting_N2M4M2FkNDItYzIxMS00NjA0LWFhZDMtZGM3YzQwMDcwYWU2@thread.v2` - `Canale diretto supporti DB - DC`

Per aggiungere una chat basta aggiungere una riga CSV con `enabled=1`.

## Stato separato per sorgente

Ogni chat/channel usa una directory stabile derivata dalla `source_signature`:

```text
data/teams_download/sources/chat_<hash>/
```

All'interno sono separati:

- `download_state.json`;
- `messages_checkpoint.jsonl`;
- `messages_current_run.jsonl`;
- `messages_final.jsonl`;
- `messaggi_chat.txt`.

Il watermark globale `state/teams_watermark.json` resta un unico file, ma contiene una voce indipendente per ciascuna `source_signature`.

Dopo che tutte le sorgenti sono state scaricate, viene creato:

```text
data/teams_download/messages_final.jsonl
```

che e l'aggregato del run e viene importato in SQLite con un unico step.

## Compatibilita v4.x

Al primo run viene effettuata una migrazione non distruttiva del vecchio checkpoint condiviso verso le nuove cartelle per sorgente. Il watermark gia committato della chat esistente viene riutilizzato.

## Modello dati multi-sorgente

Aggiunti:

- `messages.source_name`;
- tabella `teams_sources` sincronizzata dal CSV;
- `conversation_events.source_signature`;
- `conversation_events.source_name`.

I messaggi storici gia presenti vengono backfillati con `source_name` quando la loro `source_signature` corrisponde a una riga del CSV.

Contesti, eventi e finestre temporali RAG sono ora source-aware e non mescolano messaggi appartenenti a chat differenti.

call ISPEXEC "TBCREATE "tableName" NOWRITE"
do i = 1 to 3
  parse value i with .
  nome = "Mario"i
  cognome = "Rossi"i
  eta = 20 + i
  call ISPEXEC "TBADD "tableName" ,
   NOME("nome") COGNOME("cognome") ETA("eta")"
end
/* Mostra il pannello e permette selezione */
"DISPLAY PANEL("panelName")"
/* Visualizza la tabella in modalit� selezione */
"TBDISPL "tableName" PANEL("panelName")"
do while rc = 0
  /* Recupera la riga corrente */
  "TBGET "tableName
  say "Hai selezionato: " nome " " cognome " - Et{ " eta
  exit
end
crea_tab:
  "TbCreate " || TableName || " " ||,
  "Names(Y2fun Y2data y2ora y2db y2ts y2own y2name y2note) ",
  "Library(ISPTLIB) NoWRITE"
  If RC > 8 Then do
    Do
      SAY 'TBCREATE RC='RC
      Exit (rc)
    End
  End
return
call crea_tab
call aggiungi_righe_tab
MYM = '@z  �Y2DATA  �Y2ORA �Y2DB   �Y2TS '
panelName = "PANEL01"
"DISPLAY PANEL("panelName")"
exit
aggiungi_righe_tab:
  y2db='DBR000'
  y2ts='TSAQR000'
  "TbAdd " || TableName||" Mult("SQLROW + 1" )"
return
/* Cancella tabella temporanea */
"TBCLOSE "tableName

COMMIT;
DELETE FROM BMCACMC1.CM_BLPROFILE WHERE BLPOWNER='BLPNEW' AND
BLPNAME='DBR000';
COMMIT;
INSERT INTO BMCACMC1.CM_BLPROFILE (
  BLPOWNER,
  BLPNAME,
  "TYPE",
  SECURE,
  STATUS,
  CRAUTH,
  CRDATE,
  CRTIME,
  MODAUTH,
  MODDATE,
  MODTIME,
  BLAUTH,
  BLDATE,
  BLTIME,
  BLOWNER,
  BLNAME,
  MIOWNER,
  MINAME,
  TEMPLATE,
  REMS,
  DELETEAGE,
  RETAINMAX,
  SCTIMESTMP,
  VERSION,
  DL_VERSION,
  DB2_VERSION
) VALUES (
'BLPNEW'           , --CHAR(8)         BLPOWNER
'DBR000' , --VARCHAR(18)     BLPNAME
'C'                  , --CHAR(1)         "TYPE"
'N'                  , --CHAR(1)         SECURE
' '                  , --CHAR(1)         STATUS
'U447800'           , --CHAR(8)         CRAUTH
CURRENT DATE         , --DATE            CRDATE
CURRENT TIME         , --TIME            CRTIME
'U447800'           , --CHAR(8)         MODAUTH
CURRENT DATE         , --DATE            MODDATE
CURRENT TIME         , --TIME            MODTIME
'U447800'           , --CHAR(8)         BLAUTH
CURRENT DATE         , --DATE            BLDATE
CURRENT TIME         , --TIME            BLTIME
'BLNEW'           , --CHAR(8)         BLOWNER
'DBR000', --VARCHAR(18)     BLNAME
'        '           , --CHAR(8)         MIOWNER
'' , --VARCHAR(18)     MINAME
'' , --VARCHAR(18)     TEMPLATE
'BLP CREATA PER ANALISI DIFFERENZE DBR000' ,
2                    , --SMALLINT        DELETEAGE
0                    , --SMALLINT        RETAINMAX
CURRENT TIMESTAMP    , --TIMESTMP        SCTIMESTMP
'12.01.04'           , --CHAR(8)         VERSION
'12.01.01'           , --CHAR(8)         DL_VERSION
'12.1.506'             --CHAR(8)         DB2_VERSION
) ;
COMMIT;
DELETE FROM BMCACMC1.CM_SCOPE WHERE SCOWNER='BLPNEW'
AND SCNAME='DBR000';
COMMIT;
INSERT INTO BMCACMC1.CM_SCOPE (
  SCOWNER,
  SCNAME,
  "TYPE",
  ACTION,
  OBJECT,
  NAME_PART1,
  NAME_PART2,
  NAME_PART3,
  MIGDT,
  MIGTS,
  MIGTB,
  MIGCK,
  MIGFK,
  MIGIX,
  MIGVW,
  MIGAU,
  MIGSY,
  MIGAL,
  MIGRO,
  MIGTR,
  MIGUC,
  MIGAX,
  MIGDB,
  MIGMK,
  MIGRP
) VALUES (
'BLPNEW'           , --CHAR(8)         SCOWNER
'DBR000' , --VARCHAR(18)     SCNAME
'B'                  , --CHAR(1)         "TYPE"
'I'                  , --CHAR(1)         ACTION
'TS'                 , --CHAR(2)         OBJECT
'DBR000', --VARCHAR(128)    NAME_PART1
@TSNAME@
'', --VARCHAR(128)    NAME_PART3
'Y'                  , --CHAR(1)         MIGDT
'Y'                  , --CHAR(1)         MIGTS
'Y'                  , --CHAR(1)         MIGTB
'Y'                  , --CHAR(1)         MIGCK
'Y'                  , --CHAR(1)         MIGFK
'Y'                  , --CHAR(1)         MIGIX
'Y'                  , --CHAR(1)         MIGVW
'N'                  , --CHAR(1)         MIGAU
'Y'                  , --CHAR(1)         MIGSY
'Y'                  , --CHAR(1)         MIGAL
'Y'                  , --CHAR(1)         MIGRO
'Y'                  , --CHAR(1)         MIGTR
'Y'                  , --CHAR(1)         MIGUC
'Y'                  , --CHAR(1)         MIGAX
''  , --CHAR(1)         MIGDB
'N'                  , --CHAR(1)         MIGMK
'N'                    --CHAR(1)         MIGRP
) ;
UPDATE BMCACMC1.CM_WORKID SET
STATUS=' '
WHERE
WKOWNER='UDBR000Y' ;

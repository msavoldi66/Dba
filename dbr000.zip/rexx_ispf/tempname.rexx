/* rexx */
 parse source . . xvPGM . xvRxLib .

 "ex '"xvrxlib"(tempnam2)' '"xvRxLib"' ex "

 exit

/* rexx */
/* */
/* Clist principale per allocazione librerie e display pannello start */
/* */

xvRC=0; xvRC2=0;
xvVarList = ''

parse upper arg dcrvar_par
parse var dcrvar_par 'MODE<'par_MODE'>'.
parse source a b xvPGM c xvRxLib d
if xvrxlib = '?'
then do
     address ispexec 'vget xvRxLib shared'
     if rc <> 0
     then call xAbend 'Errore var xvRxLib non trovata. Impossibile',
                      'ricavare la libreria di runtimme.'
end

address tso 'newstack'

cen  = MVSVAR('SYMDEF',cen )
cenn = MVSVAR('SYMDEF',cenn)
SYSNAME = MVSVAR('SYMDEF',SYSNAME)
ivDB2ID='DB2F'

call make 'cen',cen
call make 'cenn',cenn
call make 'sysname',sysname
call make 'ivDB2ID',ivDB2ID


/* DSNLOAD */
Alias4 = "DB2"
AliasY = "Y"mvsvar(SYMDEF,AMBOF)"00"Alias4
AliasX = "X"mvsvar(SYMDEF,AMBOF)"00"Alias4
Versione = ""
if Versione = "" then Versione = ""

DsnPreY = AliasY".PE000"Versione
DsnPreX = AliasX".PE000"Versione
ivDSNLOAD= "DSNLOAD"
if ivDSNLOAD= "" then ivDSNLOAD= "LOADLIB"
ivDSNLOAD= DsnPreY"."ivDSNLOAD
/*
call make 'ivDSNLOAD',ivDSNLOAD

/* SYSPROc */
ivSYSPROC = "L"cen"P00.SYSTEM.INPUT"
call make 'ivSYSPROC',ivSYSPROC

/*  allocazione dataset ??? servono ???  */

IVtempPr=userid()'.TW000.INC'
call make 'IVtempPr',IVtempPr

IVUsrPre=userid()'.INC'
call make 'IVUsrPre',IVUsrPre

*/

/*
     tabella tipi di incidenti gestiti e descrizioni
*/
call make 'INF01DSN' , xvRxLib'(listtype)'

/***
     Dataset contenente gli skeletri delle mail
***/
call make 'INF02DSN' , xvRxLib

Fine:
 if xvRc <> 0
 then xvStat = 'xvRc = 12; address tso delstack; signal Fine;'
 else xvStat = "do queued();parse pull varbuf;interpret varbuf;end;"||,
               "address tso delstack;"
 exit xvStat

Make: procedure
 arg varname,varValue,delim
 if delim = '' then delim = '"'
 queue varname'='delim||varValue||delim';'
 return 0
xAbend:
 parse arg xAbend_msg,xAbend_rc
 call xprint (xAbend_msg)
 call xprint ('Fine anomala')
 if xAbend_rc =  '' then xAbend_rc = 16
 xvrc = xAbend_rc

 address tso 'pipe rexxvars | terminal'
 signal fine

XPrint:
 parse arg xprint_msg
 parse source . . xvpgm .
 say date('s') time() xvpgm xprint_msg
 return 0


syntax:
 say  'REXX error 'rc' in line 'sigl':' "ERRORTEXT"(rc)
 say "SOURCELINE"(sigl)
 signal off syntax
 call xAbend 'syntax Error'

Error:
 say  'REXX error 'rc' in line 'sigl':' "ERRORTEXT"(rc)
 say "SOURCELINE"(sigl)
 signal off error
 call xAbend 'ON Error'


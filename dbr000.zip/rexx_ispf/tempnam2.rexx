/* rexx */
call RemoveDs
 parse source . . xvPGM . . .
 arg xvrxlib
 CENN    = MVSVAR('SYMDEF',CENN)
 CEN    = MVSVAR('SYMDEF',CEN)
 xvRC = 0
 ADDRESS TSO

"ALTLIB ACTIVATE APPLICATION(EXEC) DS(" ,
                                    " '"xvrxlib"' " ,
                                    " 'L"CEN"P00.SYSTEM.INPUT' " ,
                                    " ) "
 address ispexec
 'LIBDEF ISPPLIB DATASET ID('xvRxlib') stack'
 if rc <> 0 then do
    xvRC = rc
    say Zerrsm' 'Zerrlm
    signal fine
 end

 /* alloca libreria db2 su questa lpar */


 DSNSTPLB='Y'CENN'00DB2.PE000.DSNLOAD'
 x = outtrap('TSO.')
 address tso "STEPLIBD STACK DSN('"dsnSTPLB"')"
 if rc <> 0 THEN do
    say "errore allocazione DSNLOAD RC="rc zerrsm zerrlm
    signal Fine
 end
 y = outtrap(off)


 'LIBDEF ISPMLIB DATASET ID('xvRxlib') stack'
 if rc <> 0 then do
    xvRC = rc
    say Zerrsm' 'Zerrlm
    signal fine
 end

 'VPUT XVrXlIB shared'

 /* richiama modulo per definizione variabili */

 interpret allocVar()

 /*
 address tso
 "ALTLIB",
 "ACTIVATE APPLICATION(EXEC) Dsname('"ivSYSPROC"')"
 if rc <> 0 then do
    xvRC = rc
    signal fine
 end
 */

 call alloca_keys

 Address ISPEXEC
 "SELECT CMD(EX '"xvRxlib"(rexx01)') NEWAPPL(D2RC) PASSLIB"

 /*
 x = recov()
 */
 /*  esco per fine procedura */
 /*
 say 'FINE rexx01  Eseguo remove dataset allocati'
 pull finerx
 */

exit 0
Fine:
 " STEPLIBD remove DATASETS( " ,
         " '"DSNSTPLB"' ",
         ") nomsg"
 address ispexec
 'LIBDEF ISPPLIB DATASET'
 'LIBDEF ISPMLIB DATASET'
 'LIBDEF ISPTLIB DATASET'
 ADDRESS TSO
     'ALTLIB DEACTIVATE APPLICATION(EXEC) '
 exit xvRC
RemoveDs:
 " STEPLIBD remove DATASETS( " ,
         " '"DSNSTPLB"' ",
         ") nomsg"
 address ispexec
 'LIBDEF ISPPLIB DATASET'
 'LIBDEF ISPMLIB DATASET'
 'LIBDEF ISPTLIB DATASET'
 ADDRESS TSO
     'ALTLIB DEACTIVATE APPLICATION(EXEC) '
return

alloca_keys:

 ADDRESS ISPEXEC
 'VGET (ZUSER)'
 'VGET (ZSYSID)'

 ADDRESS TSO
 'ALTLIB RESET'
 ISPEXEC LIBDEF ISPPLIB
 ISPEXEC LIBDEF ISPMLIB
 ISPEXEC LIBDEF ISPTLIB


 SYSNAME = MVSVAR('SYMDEF','SYSNAME')

 fideuram = 0
 if left(SYSNAME,3) = 'SYS' then
   fideuram=1
 ivsysprc = 'L'CEN'P00.SYSTEM.INPUT'
 address tso
 "ALTLIB",
 "ACTIVATE APPLICATION(clist) DA(" ,
                            "'"xvRxlib"'"    ,
                            "'"ivsysprc"'"   ,
                            ")"

 /* sm x too many allocation */
 /*
 DSNSTPLB='Y'CENN'00DB2.PE000.DSNLOAD'
 x = outtrap('TSO.')
 if fideuram then
   address tso "STEPLIB STACK DSN('"dsnSTPLB"')"
 else
   address tso "STEPLIBD STACK DSN('"dsnSTPLB"')"
 if rc <> 0 THEN do
    say "errore allocazione DSNLOAD RC="rc zerrsm zerrlm
    signal Fine
 end
 */

 Address IspExec
 "Libdef ISPPLIB Dataset Id('"xvRxlib"')"
 Address IspExec
 "Libdef ISPTLIB Dataset Id('"xvRxlib"')"

 DsnMlib = "Y"CENN"00DB2.PE000.DSNSPFM"
 address ispexec "LIBDEF ISPMLIB DATASET ID('"DsnMlib"')"
 if rc <> 0 THEN do
    say "errore allocazione ISPMLIB RC="rc zerrsm zerrlm
    signal Fine
 end


return

finefine:
    ADDRESS TSO
      'ALTLIB DEACTIVATE APPLICATION(CLIST)'
 /* signal dispan01 */
/*-----------------------------------------------------------*/

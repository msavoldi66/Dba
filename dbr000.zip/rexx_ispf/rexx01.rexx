/* REXX: esempio uso TBDISPL per selezione riga */
ADDRESS ISPEXEC
   'VGET (ZSYSID,ZUSER)'
   LACPU=ZSYSID
   LUTENTE = ZUSER
CPU = MVSVAR('SYMDEF','SYSNAME')
CEN = MVSVAR('SYMDEF','CEN')
CENN= MVSVAR('SYMDEF','CENN')
IF SUBSTR(CPU,1,3)<>'SYA' THEN do
  say 'Clist da eseguire in ambiente di system test '
  pull fine
  exit 0
end
Address ISPEXEC
tableName = "TABRIGHE"
panelName = "PANEL00"
dbname='DBR000'
SQLROW=1
xvCSR='d'
db2source=''
tsname000=''
flag_tb=0
inizio:
y=''
righe_ts=0
righe_tb=0
call dispan01
if d=1 then do
  db2source='DB0Y'
  db2locat='DB2YTOSG'
end
if d=2 then do
  db2source='SDSA'
  db2locat='SDSAM00S'
end
tsname000=strip(tsname)
if y='Y' then signal ok
if y='y' then signal ok
if y='F' then signal ok
if d<1 then signal inizio
if d>2 then signal inizio
call select_tsname
call select_tbname
if y='F' then signal ok
if y='N' then exit
if y='n' then exit
if y<>'Y' then if y<>'y' then signal inizio
if strip(errore)<>'' then signal inizio
if db2source='' then signal inizio
if tsname000='' then signal inizio
ok:
if flag_tb=0 then do
  errore='Dare invio per controllare nome tabella prima di dare Y'
  signal inizio
end
call select_tsname
if strip(errore)<>'' then do
  errore=''
  signal inizio
end
call modify_baseline
call crea_job
call write_job
ADDRESS TSO
'ALTLIB DEACTIVATE APPLICATION(CLIST)'
exit
DISPAN01:
  xvMSGID=''
  ADDRESS ISPEXEC
  ZCMD = ''
  "DISPLAY PANEL(PANEL00) MSG("xvMSGID") CURSOR("xvCSR") "
  IF RC = 8 THEN
     CALL USCITA '0'
  if zcmd <> '' then do
     if zcmd = 'DEBUG' then do
        call showdebug
        signal DISPAN01
     end
     xvMSGID = 'CHGM028I' /* se passo di qui non ho immesso */
     xvCSR = 'ZCMD'       /* un comando valido */
     savecmd = zcmd
     signal DISPAN01
  end
return
showdebug:
return
uscita:
exit 0
select_tsname:
  errore=''
  db2con='SDEA'
  qdbname="'"dbname"'"
  qtsname="'"tsname000"'"
  stmtx= ,
  "SELECT name as nomets,dbname as vdbname, instance as instts",
  " FROM "db2locat".SYSIBM.SYSTABLESPACE A",
  " Where strip(upper(a.dbname))="qdbname" ",
  " and strip(upper(a.name))="qtsname" "
  if debugga=1 then do
    say stmtx
    pull finerx
  end
  INTERPRET REXSQL(db2con,STMTX)
  IF SQLCODE < 0  THEN DO
    say 'errore sql ' sQLCODE SQLSTATE SQLERRMC STMTX
    exit
  END
  righe_ts=sqlrows
  if righe_ts=0 then do
    errore='Il tsname non esiste|'
  end
return
select_tbname:
  flag_tb=1
  errore=''
  tbname=''
  db2con='SDEA'
  qdbname="'"dbname"'"
  qtsname="'"tsname000"'"
  stmtx= ,
  "SELECT creator, name , datacapture",
  " FROM "db2locat".SYSIBM.SYSTABLES A",
  " Where type in ('T','M') ",
  " and strip(upper(a.dbname))="qdbname" ",
  " and strip(upper(a.tsname))="qtsname" "
  if debugga=1 then do
    say stmtx
    pull finerx
  end
  INTERPRET REXSQL(db2con,STMTX)
  IF SQLCODE < 0  THEN DO
    say 'errore sql ' sQLCODE SQLSTATE SQLERRMC STMTX
    exit
  END
  righe_tb=sqlrows
  if righe_tb=0 then do
    errore='Nessuna tabella presente nel ts 'tsname
    flag_tb=0
  end
  if righe_tb>0 then do
    tbname='Tabella : 'creator.1'.'name.1
    xvCSR='y'
  end
return
crea_job:
  /*  legge schede job del processo allineamento */
  if d=1 then do
    schedajob='//DB0Y000X JOB &SYSUID,DBA,MSGCLASS=Y,CLASS=G,'
    queue schedajob
    schedajob='//          SCHENV=SCDB2F'
    queue schedajob
    dataset='X400DB2.PE000.DBR000.EXEC(DB0Y)'
  end
  if d=2 then do
    schedajob='//SDSA000X JOB &SYSUID,DBA,MSGCLASS=Y,CLASS=G,'
    queue schedajob
    schedajob='//          SCHENV=SCDB2F'
    queue schedajob
    dataset='X400DB2.PE000.DBR000.EXEC(SDSA)'
  end
  schedajob='//*******************************************************'
  queue schedajob
  schedajob='//**  creato in data ' date()
  queue schedajob
  schedajob='//**            ora  ' time()
  queue schedajob
  ADDRESS TSO "ALLOCATE DA('"dataset"') F(sckdjob) SHR"
  address tso "EXECIO * DISKR sckdjob (STEM skjob. FINIS"
  address tso "FREE FILE(sckdjob)"
  if rc=20 then exit   20
  cfrts='TS DBR000.@TSNAME@ S'
  do i=1 to skjob.0
    if strip(skjob.i)=strip(cfrts) then do
      skjob.i='TS DBR000.'tsname000' S'
    end
    if strip(skjob.i)='//*  @TSNAME@' then do
      skjob.i='//*   DBR000.'tsname000
    end
    queue skjob.i
  end
return
modify_baseline:
  cfrts1='@TSNAME@'
  baseline='X400DB2.PE000.DBR000.EXEC(BASELINE)'
  ADDRESS TSO  "ALLOCATE DA('"baseline"') F(baselin) SHR"
  ADDRESS TSO  "EXECIO * DISKR baselin (STEM basel. FINIS"
  ADDRESS TSO  "FREE FILE(baselin)"
  if rc=20 then exit   20
  do j=1 to basel.0
    if strip(basel.j)=strip(cfrts1) then do
      basel.j="'"tsname000"',"
    end
    queue basel.j
  end
  baselin2='X000DB2.PE000.DB0Y.DBR000.SQL'
  say 'scrivo file : ' baselin2
  say 'invio per continuare'
  ADDRESS TSO "ALLOCATE DA('"baselin2"') F(baselin2) SHR"
  ADDRESS TSO "EXECIO * DISKW baselin2 (FINIS"
  ADDRESS TSO "FREE FILE(baselin2)"
return
write_job:
/* alloco lib. per jobs -------------------------------------*/

  lutente=ZUSER

  if d=1 then
    dataset='X000DB2.TS000.JOBS.'lutente'(SUBDB0Y)'
  if d=2 then
    dataset='X000DB2.TS000.JOBS.'lutente'(SUBSDSA)'
  say 'scrivo file : ' dataset
address tso "delete 'X000DB2.TS000.JOBS."lutente"'"
address tso,
"ALLOCATE DA("||dataset||") F(subjob) NEW SPACE(2,9) ",
  "DSORG(PO) DSNTYPE(LIBRARY) ",
  "TRACKS RECFM(F) LRECL(80) BLKSIZE(80) "

  say 'andare in produzione TSB* (ove presente DB2F) e sottomettere job'
  say 'invio per continuare'
  /*
  ADDRESS TSO "ALLOCATE DA('"dataset"') F(subjob) SHR"
  */
  ADDRESS TSO "EXECIO * DISKW subjob (FINIS"
  ADDRESS TSO "FREE FILE(subjob)"
return
